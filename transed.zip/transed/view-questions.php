<?php include('epariksa-transed-config.php');

if(isset($_GET['test_id'])) { 
$test_id  = $_GET['test_id'];                         
$batch_id  = $_GET['batch_id'];                         
        $test_frame_query = $mysqli->query("SELECT * FROM epariksa_test_frame WHERE test_active=1 AND test_id=$test_id");
$row = mysqli_fetch_array($test_frame_query);

$test_id         = $row['test_id']; 
$category_id      = $row['category_id'];
$select_maincategory = $mysqli->query("SELECT * FROM epariksa_category WHERE category_active=1 AND category_id = '$category_id'");
$maincategoryRow = mysqli_fetch_array($select_maincategory);
$category_name      = $maincategoryRow['category_name'];
$subject_id         = $row['subject_id'];
$test_image      = $row['test_image']; 
$test_title      = $row['test_title']; 
$no_of_questions = $row['no_of_questions']; 
$total_marks     = $row['total_marks']; 
$test_time       = $row['test_time']; 

    }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Transed</title>

    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="assets/css/fontawesome.rtl.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">
    <link type="text/css"  href="assets/css/toastr.min.css" rel="stylesheet">

     <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.css" rel="stylesheet">
</head>

<body class=" layout-fluid">

    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->
<?php include 'header.php';?>
<!-- // END Header -->
<!-- Header Layout Content -->
<div class="mdk-header-layout__content">
    <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
        <div class="mdk-drawer-layout__content page">
            <div class="container-fluid page__container">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                    <li class="breadcrumb-item"><?php echo $category_name; ?></li>
                    <li class="breadcrumb-item active">View Questions</li>
                </ol>





                    <div class="card card-sm">
                        <div class="card-body media padd-extra">
                            <div class="media-left">
                                <a href="" class="avatar avatar-lg avatar-4by3">
                                    <img src="test/<?php echo $test_image; ?>" alt="Card image cap" class="avatar-img rounded">
                                </a>
                            </div>
                            <div class="media-body">
                            <h3 class="card-title mb-0"><?php echo $test_title; ?> (<?php echo $category_name; ?>) </h3>

                            <input type="button" name="checked_box" class="checked_frame btn btn-success" data-id = "<?php echo $test_id; ?>"  data-batch-id = "<?php echo  $batch_id; ?>" value="Assign"style="float: right;">
                            <?php 
                            $sub_value = explode(',',$subject_id); 
                 $count_id = count($sub_value);

                  for($i=0; $i<$count_id; $i++) {

                  $selectQuery = $mysqli->query("SELECT * FROM epariksa_subjects WHERE subject_active=1 AND subject_id='$sub_value[$i]'");
              

                  $selectRow =  mysqli_fetch_array($selectQuery);
                    $sub_name = $selectRow['subject_name'];  ?>
                

                               <?php echo $sub_name,','; ?>

                               <?php } ?>
                            </div>
                           
                        </div>
                        <div class="card-footer text-center time-schedule">
                            <a href="#" class="btn btn-white btn-sm float-left text-size">Total No of Question <span class="badge badge-dark ml-2"><?php echo $no_of_questions; ?></span></a>

                              <?php 
                              
                                $explode_value =  explode(':', $test_time);
                                $hours =  $explode_value[0];
                                $min =  $explode_value[1];
                                  ?> 



                                    <a href="#" class="btn btn-default btn-sm float-right text-size">   <i class="material-icons text-muted-light">schedule</i> &nbsp; <?php echo $hours; ?>  &nbsp; <small class="text-muted">hrs</small> &nbsp; <?php echo $min; ?><small class="text-muted"> &nbsp;min</small> </a>


                            <div class="clearfix"></div>
                        </div>
                    </div>




                <h1 class="h2">View Questions</h1>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            
                            <div class="col-lg-12">

                                <div class="table-responsive border-bottom" data-toggle="lists" data-lists-values='["js-lists-values-employee-name"]'>

                                    <div class="search-form search-form--light mb-3">
                                        <input type="text" class="form-control search" placeholder="Search">
                                        <button class="btn" type="button" role="button"><i class="material-icons">search</i></button>
                                    </div>

                                    <table class="table mb-0">
                                        <thead>
                                            <tr>
                                                <th>Test Subject</th>
                                                <th>Test Topic</th>
                                                <th>Question</th>
                                                <th>Date</th>
                                            </tr>
                                        </thead>
                                        <tbody class="list" id="search">
                                         <?php       


 $test_frame_query = $mysqli->query("SELECT * FROM epariksa_test_frame WHERE test_active=1 AND test_id=$test_id");
                                            while($row = mysqli_fetch_array($test_frame_query)) {
                                                $category_id_arr_1     = explode(',', $row['category_id']);
                                                $subject_id_arr_1      = explode(',', $row['subject_id']);;
                                                $topic_id_arr_1        = explode(',', $row['topic_id']); 



                                                $question_id_arr_1     = explode(',', $row['question_id']); 
                                                $question_created_date  =getdate_formated ($row['test_created_date']);
                                                //print_r(count($subject_id));

                                                for($i=0; $i < count($subject_id_arr_1); $i++){
                                                    $category_id = $category_id_arr_1[$i];
                                                    $subject_id = $subject_id_arr_1[$i];
                                                    $topic_id = $topic_id_arr_1[$i];
                                                    $question_id = $topic_id_arr_1[$i];

                                                $category_query = $mysqli->query("SELECT category_name FROM epariksa_category WHERE category_active = 1 AND category_id = $category_id ");
                                                $category_arr = mysqli_fetch_array($category_query);

                                                $subject_query = $mysqli->query("SELECT subject_name FROM epariksa_subjects WHERE subject_active = 1 AND subject_id = $subject_id ");

                                                $subject_arr = mysqli_fetch_array($subject_query);

                                                $topic_query = $mysqli->query("SELECT topic_name FROM epariksa_topics WHERE topic_active = 1 AND topic_id = $subject_id "); 

                                                $topic_arr = mysqli_fetch_array($topic_query);

                                                $question_query =  $mysqli->query("SELECT question FROM epariksa_questions WHERE question_active = 1 AND question_id = $question_id "); 
                                                $question_arr = mysqli_fetch_array($question_query);

                                        ?> 
                                            <tr>
                                               
                                                <td>
                                                    <span class="js-lists-values-employee-name"><?php echo $subject_arr['subject_name']; ?></span>
                                                </td>
                                                <td>
                                                    <span class="js-lists-values-employee-name"><?php echo $topic_arr['topic_name']; ?></span>
                                                </td>
                                                <td> <span class="js-lists-values-employee-name"><?php echo $question_arr['question']; ?></span></td>
                                                <td><?php echo $question_created_date;?></td>
                                                 
                                              <!--   <td><a href="#" class="text-muted"><i class="material-icons">more_vert</i></a></td> -->
                                            </tr>

                                          <?php } } ?>

                                        </tbody>
                                    </table>
                                </div>


                            </div>
                        </div>
                    </div>
                    
                </div>

                
            </div>

        </div>




    <?php include 'sidebar.php';?>

    </div>

    
</div>
</div>



<!-- jQuery -->
<script src="assets/vendor/jquery.min.js"></script>

<!-- Bootstrap -->
<script src="assets/vendor/popper.min.js"></script>
<script src="assets/vendor/bootstrap.min.js"></script>

<!-- Perfect Scrollbar -->
<script src="assets/vendor/perfect-scrollbar.min.js"></script>

<!-- MDK -->
<script src="assets/vendor/dom-factory.js"></script>
<script src="assets/vendor/material-design-kit.js"></script>

<!-- App JS -->
<script src="assets/js/app.js"></script>

<!-- Highlight.js -->
<script src="assets/js/hljs.js"></script>

<!-- App Settings (safe to remove) -->
<script src="assets/js/app-settings.js"></script>






    <!-- List.js -->
    <script src="assets/vendor/list.min.js"></script>
    <script src="assets/js/list.js"></script>

    <!-- Tables -->
    <script src="assets/js/toggle-check-all.js"></script>
    <script src="assets/js/check-selected-row.js"></script>

<script type="text/javascript" src="assets/js/toastr.min.js"></script>
    <script type="text/javascript">
         $(document).on('click', '.checked_frame', function(){
 var assign_test_id = $(this).data("id");
 var assign_batch_id = $(this).data("batch-id");
 var favorite = [];
            $.each($(".checked_frame"), function(){            
                favorite.push($(this).data("id"));
            });
             var view_question_num =  favorite.join(", ");
 $.ajax({
  type:'POST',
  url:'ajax-file.php',
  data:{assign_test_id : assign_test_id,assign_batch_id : assign_batch_id},
  success:function(data){
    console.log(data);
    
  }

 })  

  $.ajax({
  type:'POST',
  url:'ajax-file.php',
  data:{assign_test_id1 : assign_test_id,assign_batch_id1 : assign_batch_id},
  success:function(data){
    var obj = jQuery.parseJSON(data);
    //console.log(obj.success);
     if (obj.success === '1') {
                      toastr.success('Assigned Batch Success.', 'Success Alert', {timeOut: 5000})
                      $(".checked_frame").val("Assigned");
                      $(".checked_frame").val("Assigned");
                       $(".checked_frame").addClass("btn btn-danger");
                       $(".checked_frame").removeClass("btn btn-success");

                  }


    
  }

 })          
});
    </script>>

</body>

</html>