<?php include('epariksa-transed-config.php');
$a =='';
if(isset($_POST['batch_submit'])) {
               
           $batch_name            = trim(ucfirst($_POST['batch_name'])); 


            $valid_from            = $_POST['valid_from']; 

             $valid_to            = $_POST['valid_to']; 
           $batch_created_by          = $session_login_id;           
           $batch_created_date  = date('Y-m-d');
           $batch_modified_date = date('Y-m-d H:i:s');
           $batch_active          = 1; 
 $insert_batch = $mysqli->query("INSERT INTO epariksa_batch(batch_name, valid_from , valid_to, batch_created_by, batch_created_date, batch_modified_date) VALUES ('$batch_name','$valid_from','$valid_to','$batch_created_by','$batch_created_date','$batch_modified_date')");



 if($insert_batch == true) {
        $response["success"] = "1";
        $a = json_encode($response);
      }
}
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Transed</title>

    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="assets/css/fontawesome.rtl.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">
    <link href="assets/css/toastr.min.css" rel="stylesheet">
<!-- Flatpickr -->
    <link type="text/css" href="assets/css/flatpickr.css" rel="stylesheet">
    <link type="text/css" href="assets/css/flatpickr.rtl.css" rel="stylesheet">
    <link type="text/css" href="assets/css/flatpickr-airbnb.css" rel="stylesheet">
    <link type="text/css" href="assets/css/flatpickr-airbnb.rtl.css" rel="stylesheet">

 <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.css" rel="stylesheet">

</head>

<body class=" layout-fluid">


    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->

      <?php include 'header.php';?>

        <!-- // END Header -->

        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content">

            <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
                <div class="mdk-drawer-layout__content page">

                    <div class="container-fluid page__container">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>

                            <li class="breadcrumb-item">batch</li>
                              <li class="breadcrumb-item active">Add batch</li>
                        </ol>
                        <h1 class="h2">Add Batch</h1>

                        <div class="card">
                            
                            <div class="tab-content card-body">
                                <div class="tab-pane active" id="first">
                                    <form action="" method="POST" class="form-horizontal" enctype="multipart/form-data" onsubmit="return addsubmitvalidation()">
                                     
                                          <div class="form-group row">
                                                <label for="password" class="col-sm-3 col-form-label form-label"> batch Name</label>
                                            <div class="col-sm-6 col-md-6">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">class</i>
                                                           
                                                        </div>
                                                    </div>
                                                    <input type="text" id="batch_name"  name="batch_name" class="form-control" placeholder="Enter batch Name" onkeyup="hideErrorbatch();">
														
                                                </div>
												<span style="color: red;" id="add_batch"></span>
                                            </div>
                                        </div>




                                         <div class="form-group row">
                                                <label for="password" class="col-sm-3 col-form-label form-label"> Valid From</label>
                                            <div class="col-sm-6 col-md-6">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">class</i>
                                                           
                                                        </div>
                                                    </div>
                                                     <input id="flatpickrSample01" name="valid_from" type="text" class="form-control" placeholder="Valid From" data-toggle="flatpickr" value="" onchange="hideErrorfromdate();">
                                                        
                                                </div>
                                                <span style="color: red;" id="add_fromdate"></span>
                                            </div>
                                        </div>

                                         <div class="form-group row">
                                                <label for="password" class="col-sm-3 col-form-label form-label"> Valid To</label>
                                            <div class="col-sm-6 col-md-6">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">class</i>
                                                           
                                                        </div>
                                                    </div>
                                                     <input id="flatpickrSample02" name="valid_to" type="text" class="form-control" placeholder="Valid To" data-toggle="flatpickr" value="" onchange="hideErrortodate();">
                                                        
                                                </div>
                                                <span style="color: red;" id="add_todate"></span>
                                            </div>
                                        </div>




                                          
                                        <div class="form-group row">
                                            <div class="col-sm-8 offset-sm-3">
                                                <div class="media align-items-center">
                                                    <div class="media-left">
                                                        <button type="submit" id="batch_submit" name="batch_submit" class="btn btn-success">Save </button>
                                                    </div>
                                                   <!--  <div class="media-body pl-1">
                                                        <div class="custom-control custom-checkbox">
                                                            <input id="subscribe" type="checkbox" class="custom-control-input" checked>
                                                            <label for="subscribe" class="custom-control-label">Subscribe to Newsletter</label>
                                                        </div>
                                                    </div> -->
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                            
                            </div>
                        </div>
                    </div>

                </div>




                     <?php include 'sidebar.php';?>

            </div>

          

        </div>
    </div>



    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/dom-factory.js"></script>
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- App Settings (safe to remove) -->
    <script src="assets/js/app-settings.js"></script>

     <!-- Flatpickr -->
    <script src="assets/vendor/flatpickr/flatpickr.min.js"></script>
    <script src="assets/js/flatpickr.js"></script>


<script src="assets/js/select2.min.js"></script>
<!--  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script> -->





<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#profile-img-tag').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#profile-img").change(function(){
        readURL(this);
    });
</script>

     <script type="text/javascript">
document.addEventListener("DOMContentLoaded", function() {
    $(".s2-multiple").select2();
});

</script>

<!--<script type="text/javascript">
$(document).ready(function(){
  $("form").submit(function(event) {
   var student_batch = $("#batch_name").val();
   if (student_batch === "") {
      event.preventDefault();
      $('#batches').html('Please Select the Batch');
	    $("#batches").show();
   }
  
});


});
</script> -->
<script type="text/javascript">
function hideErrorbatch(){
		 document.getElementById("add_batch").innerHTML= " ";
		}
function hideErrorfromdate(){
		 document.getElementById("add_fromdate").innerHTML= " ";
		}
function hideErrortodate(){
		 document.getElementById("add_todate").innerHTML= " ";
		}
function addsubmitvalidation()
			{
var stud_batch = document.getElementById("batch_name").value;
                    if(stud_batch == "")
					{
                            document.getElementById("add_batch").innerHTML="Please Enter the Batch...!";
                            document.getElementById("batch_name").focus();
							return false;
                                
                    }	
var from_date = document.getElementById("flatpickrSample01").value;
                    if(from_date == "")
					{
                            document.getElementById("add_fromdate").innerHTML="Please Select the From Date...!";
                            document.getElementById("flatpickrSample01").focus();
							return false;
                                
                    }						
var to_date = document.getElementById("flatpickrSample02").value;
                    if(to_date == "")
					{
                            document.getElementById("add_todate").innerHTML="Please Select the To Date...!";
                            document.getElementById("flatpickrSample02").focus();
							return false;
                                
                    }					
									
return true;
			}





</script>
<script type="text/javascript" src="assets/js/toastr.min.js"></script>
<script>

var a = '<?php echo  $a ;?>';
var obj = JSON.parse(a);
if (obj.success == 1){
toastr.success('Success', 'Batch Added Successfully..')
setTimeout(function(){  window.location.href = "view-batch.php" }, 1000);
}
</script>

</body>


</html>