<?php
include('epariksa-transed-config.php');
$login_id = $session_login_id ;
 if(isset($_POST['category'])){

    $query = "SELECT category_name,category_id FROM epariksa_category Group BY category_name ORDER BY category_name ASC";

    $run_query = mysqli_query($mysqli, $query);
    
    //Count total number of rows
    $count = mysqli_num_rows($run_query);
    
    //Display states list
    if($count > 0){
        echo '<option value="">Select Category</option>';
        while($row = mysqli_fetch_array($run_query)){
    $category_id=$row['category_id'];
    $category_name=$row['category_name'];
        echo "<option value='$category_id'>$category_name</option>";
        }
    }else{
        echo '<option value="">Catrory not available</option>';
    }
  }

/*  Subject Select*/

/*Sub Category option select*/

 if(isset($_POST['subject_id'])){
    $category_id  = $_POST['subject_id'];
    $query = "SELECT subject_name,category_id,subject_id FROM epariksa_subjects Where category_id ='$category_id'  Group BY subject_name ORDER BY subject_name ASC";
    $run_query = mysqli_query($mysqli, $query);
    //Count total number of rows
    $count = mysqli_num_rows($run_query);
    //Display states list
    if($count > 0){
        echo '<option value="">Select Subject</option>';
        while($row = mysqli_fetch_array($run_query)){
    $subject_id=$row['subject_id'];
    $subject_name=$row['subject_name'];
        echo "<option value='$subject_id'>$subject_name</option>";
        }
    }else{
        echo '<option value="">Subject not available</option>';
    }
  }
  if(isset($_POST['subject_arry_id'])){
    $subject_arry_id = $_POST['subject_arry_id'];
    $category_id =      $_POST['category_array_id'];
    $ar = json_decode($subject_arry_id);
    $subject_id = trim(implode(',',$ar));
      
        $query = "SELECT topic_name,category_id,subject_id,topic_id FROM epariksa_topics Where category_id ='$category_id' AND  subject_id IN($subject_id)  Group BY topic_name ORDER BY topic_name ASC";

    $run_query = mysqli_query($mysqli, $query);
    
    //Count total number of rows
    $count = mysqli_num_rows($run_query);

    if($count > 0){
        echo '<option value="">Select Topic</option>';
        while($row = mysqli_fetch_array($run_query)){
    $topic_id=$row['topic_id'];
    $topic_name=$row['topic_name'];
        echo "<option value='$topic_id'>$topic_name</option>";
        }
    }else{
        echo '<option value="">Topic not available</option>';
    }

   
  }



  if(isset($_POST['subject_question_count'])){
    $subject_arry_id = $_POST['subject_question_count'];
    $category_id =      $_POST['category_question_count'];
    $ar = json_decode($subject_arry_id);
    $subject_id = trim(implode(',',$ar));

        $query = "SELECT question_id,category_id,subject_id,topic_id FROM epariksa_questions Where category_id ='$category_id' AND  subject_id IN($subject_id)  ORDER BY question_id ASC";

    $run_query = mysqli_query($mysqli, $query);
    
    //Count total number of rows
    $count = mysqli_num_rows($run_query);

     $response['count'] = $count;
     echo json_encode($response);

    
   
  }


  if(isset($_POST['topic_question_count'])){
    $subject_arry_id    =        $_POST['subject_question_topic_count'];
    $category_id        =        $_POST['category_question_topic_count'];
    $topic_id           =        $_POST['topic_question_count'];
    $ar = json_decode($subject_arry_id);
    $subject_id = trim(implode(',',$ar));
    $ar_topic_id =  json_decode($topic_id);
    $topic_id   = trim(implode(',',$ar_topic_id));

        $query = "SELECT question_id,category_id,subject_id,topic_id FROM epariksa_questions Where category_id ='$category_id' AND  subject_id IN($subject_id) AND  topic_id IN ($topic_id)  ORDER BY question_id ASC";

    $run_query = mysqli_query($mysqli, $query);
    
    //Count total number of rows
    $count = mysqli_num_rows($run_query);

     $response['count'] = $count;
     echo json_encode($response);

    
   
  }
  if(isset($_POST['test_id'])){
    $test_id = $_POST['test_id'];
     $test_frame_query_2 = $mysqli->query("SELECT * FROM epariksa_test_frame WHERE test_active=1 AND test_id=$test_id");

                               $question_row_count = mysqli_num_rows($test_frame_query_2);
                                $row = mysqli_fetch_array($test_frame_query_2); 
                                                        $k=1;
                                                        $category_id_arr_1     = explode(',', $row['category_id']);
                                                        $subject_id_arr_1      = explode(',', $row['subject_id']);;
                                                        $topic_id_arr_1        = explode(',', $row['topic_id']); 
                                                        $question_id_arr_1     = explode(',', $row['question_id']); 
                                                        $question_created_date  =getdate_formated ($row['test_created_date']);

                                                   
                                                        if(count($question_id_arr_1) > 0){

                                                        for($i=0; $i < count($question_id_arr_1); $i++){
                                                             $sno = $i+1;
                                                            $category_id = $category_id_arr_1[$i];
                                                            $subject_id = $subject_id_arr_1[$i];
                                                            $topic_id = $topic_id_arr_1[$i];
                                                            $question_id = $question_id_arr_1[$i];

                                                        $question_query =  $mysqli->query("SELECT * FROM epariksa_questions WHERE question_active = 1 AND question_id = $question_id");
                                                        $question_arr = mysqli_fetch_array($question_query);

                                                        $ans_find_question =  $question_arr['question_id'];
                                                        $question_skip   =$question_arr['question'];
                                                        $question_skip_remove   =strip_tags($question_skip, '<p>');

                                                        $select_temp =  $mysqli->query("SELECT * FROM epariksa_temp_ans WHERE login_id = $login_id AND question_id = $question_id ");

                                                        $temp_arr = mysqli_fetch_array($select_temp);
                                                        $count_temp = mysqli_num_rows($select_temp);
                                                        if($count_temp == 0){
                                                            $inset_tempory_ans = $mysqli->query("INSERT INTO epariksa_temp_ans(login_id,test_id,question_id,  skip_question) VALUES ('$login_id','$test_id','$ans_find_question','0')");
                                                        }
                                                        $select_skip =  $mysqli->query("SELECT * FROM epariksa_temp_ans WHERE login_id = $login_id AND question_id = $question_id And skip_question = '0'");

                                                        $skip_arr = mysqli_fetch_array($select_skip);
                                                        $skip_temp = mysqli_num_rows($select_skip);
                                                        if($skip_temp > 0){
                                                            echo'<li class="list-group-item ">
                                                                <a href="#" data-button = button_'.$i.'  data-id= panel_question_id_'.$ans_find_question.' id = '.$sno.' onClick = "openSolution(this);" class= "left_skip_question" >
                                                                    <span class="media align-items-center">
                                                                        <span class="media-left">
                                                                             <span class="btn btn-white btn-circle">#'.$sno.'</span>
                                                                             </span> <span class="media-body">
                                                   '.get_description($question_skip).'
                                                </span>
                                            </span>
                                        </a>
                                    </li>';

                                                        }


                                                        

                                                         
                                                        }


                                                    }
                                                }

 if(isset($_POST['ans_question'])){
    $ans_question   = $_POST['ans_question'];
    $update_question_id = $mysqli->query("UPDATE epariksa_temp_ans SET skip_question='1' WHERE login_id = $login_id And question_id = $ans_question");
    if($update_question_id == true) {
        $response["success"] = "1";
        $a = json_encode($response);
      }


 }



 /*START TEST  INSTRACTION*/
 if(isset($_POST['start_test_id'])){
    $test_id = $_POST['start_test_id'];
    $test_frame_query_2 = $mysqli->query("SELECT * FROM epariksa_test_frame WHERE test_active=1 AND test_id=$test_id");
    $question_row_count = mysqli_num_rows($test_frame_query_2);
    $row = mysqli_fetch_array($test_frame_query_2); 
    $k=1;
    $category_id_arr_1     = explode(',', $row['category_id']);
    $subject_id_arr_1      = explode(',', $row['subject_id']);;
    $topic_id_arr_1        = explode(',', $row['topic_id']); 
    $question_id_arr_1     = explode(',', $row['question_id']); 
    $question_created_date = getdate_formated ($row['test_created_date']);
    $test_description      = $row['test_description'] ;
    $total_mark          =   $row['total_marks'];
     $no_of_question     =   $row['no_of_questions'];
    if(count($question_id_arr_1) > 0){
        for($i=0; $i < count($question_id_arr_1); $i++){
            $sno = $i+1;
            $category_id = $category_id_arr_1[$i];
            $subject_id = $subject_id_arr_1[$i];
            $topic_id = $topic_id_arr_1[$i];
            $question_id = $question_id_arr_1[$i];

            $question_query =  $mysqli->query("SELECT eq.*,eqc.category_name,eqs.subject_name,eqt.topic_name FROM epariksa_questions eq LEFT JOIN epariksa_category eqc ON eqc.category_id = eq.category_id LEFT JOIN epariksa_subjects eqs ON eqs.subject_id = eq.subject_id  LEFT JOIN epariksa_topics eqt ON eqt.topic_id = eq.topic_id  WHERE question_active = 1 AND question_id = $question_id");

            $question_arr = mysqli_fetch_array($question_query);
            $ans_find_question   =  $question_arr['question_id'];
            $question_skip      =   $question_arr['question'];
            $category_name      =   $question_arr['category_name'];
            $subject_name       =   $question_arr['subject_name'];
            $topic_name         =   $question_arr['topic_name'];
           
            $test_time          =   $question_arr['test_time'];

            $subject_array[]  =  $subject_name;
            $topic_array[]    = $topic_name;
            
        }
        $unique_subject = array_unique($subject_array);
        $unique_topic = array_unique($topic_array);
        $subject_name = implode(',', $unique_subject);
        $topic_name = implode(',', $unique_topic);

        echo '<form action="" method = "POST">
                         <div class="card-design">
                       
                        <div class="row design-view">
                            <label for="type" class="col-form-label form-label col-md-4 table-design">Exam for</label>
                           <div class="col-md-8">
                              <p>'.$category_name.'</p>
                            </div>
                        </div>
                        <div class="row design-view">
                            <label for="type" class="col-form-label form-label col-md-4 table-design">Subject</label>
                           <div class="col-md-8">
                              <p>'.$subject_name.'</p>
                            </div>
                        </div>
                        <div class="row design-view">
                            <label class="col-form-label form-label col-md-4 table-design">Topics</label>
                            <div class="col-md-8">
                              <p>'.$topic_name.'</p>
                            </div>
                        </div>
                        <div class="row design-view">
                            <label for="touch-spin-2" class="col-form-label form-label col-md-4 table-design">No of Questions</label>
                            <div class="col-md-8">
                             <p>'.$no_of_question.'</p>
                            </div>
                        </div>
                        <div class="row design-view">
                            <label for="touch-spin-2" class="col-form-label form-label col-md-4 table-design">No of Mark</label>
                            <div class="col-md-8">
                             <p>'.$total_mark.'</p>
                            </div>
                        </div>
                        <div class="row design-view">
                            <label for="touch-spin-2" class="col-form-label form-label col-md-4 table-design">Timeframe</label>
                            <div class="col-md-8 card-footer time-schedule border-top-0">
                              <a href="#" class="text-size">   <i class="material-icons text-muted-light">schedule</i> &nbsp;  2 &nbsp; <small class="text-muted">hrs</small> &nbsp; 26 <small class="text-muted"> &nbsp;min</small> </a>
                            </div>
                        </div>
                        </div>
                         <div class="row">
                            <div class="instructions">
                             <div class="col-sm-12">
                                <h4 class="modal-title text-black">Instructions</h4>
                                <ul>

                    <li>Close all programs, including email</li>
                    <li>Click on the Click here to open the exam link provided in the email from The College.</li>
                    <li>Click "Log In For Your Exam Here" at the bottom of the screen.</li>
                    <li>Have your Proctor enter the Username and Password provided in the email from The College and click enter.</li>
                    <li>To begin the exam, click on the link to the appropriate exam listed under Online Assessments.</li>
                </ul>
                '.$test_description.'
            </div>
                    </div>
                    </div>
                    <div class="form-group terms">
                                            <div class="custom-control custom-checkbox">
                                                <input class="custom-control-input" type="checkbox" value="" id="invalidCheck01" required="">
                                                <label class="custom-control-label" for="invalidCheck01">
                                                    Agree to terms and conditions
                                                </label>
                                            </div>
                                        </div>
                        <div class="form-group row mb-0 text-center margin-bottom-20">
                            <div class="col-md-12">

                                <button type="submit" class="btn btn-success" data-id ='.$test_id.' onclick="javascript:Full_W_P(this);">Start a Test</button>

                        
                            </div>
                        </div>
                        
                    </form>';

    }


 }

 if(isset($_POST['assign_test_id'])){

    $test_id             = $_POST['assign_test_id'];
    $assign_batch_id     = $_POST['assign_batch_id'];
    $view_question_num  =  $_POST['view_question_num'];
     $question_array =  explode(",",$view_question_num);
     $arr = array_diff($question_array, array($test_id));
    $col_test_id =implode(",",$arr);

    $test_frame_query_2 = $mysqli->query("SELECT * FROM epariksa_test_frame WHERE test_active=1 AND test_id=$test_id");
    $question_row_count     = mysqli_num_rows($test_frame_query_2);
    $batch_find             = mysqli_fetch_array($test_frame_query_2);

    $batch_id               = $batch_find['batch_id'];
    if($batch_id  == ''){
        $update_question_id = $mysqli->query("UPDATE epariksa_test_frame SET batch_id='$assign_batch_id' WHERE test_id = $test_id");
    }
    else{
       $batch_array =  explode(",",$batch_id);
       if (!in_array($assign_batch_id, $batch_array))
      {
         $batch_str=  implode(",",$batch_array);
         $assign_batch_id = $batch_str.','.$assign_batch_id;
      $update_question_id = $mysqli->query("UPDATE epariksa_test_frame SET batch_id='$assign_batch_id' WHERE test_id = $test_id");
      } 
    }
    $select_test_frame = $mysqli->query("SELECT * FROM epariksa_test_frame WHERE test_active=1 and test_id IN ($col_test_id)");


                                            while($row = mysqli_fetch_array($select_test_frame)) {

                                            
                                              $test_id       = $row['test_id']; //exit;
                                                  $test_image        = $row['test_image']; 
                                                   $test_title        = $row['test_title']; 
                                                    $no_of_questions        = $row['no_of_questions']; 
                                                     $total_marks        = $row['total_marks']; 
                                                      $test_time        = $row['test_time']; $question_id_arr_1     = explode(',', $row['question_id']); 
                                                $question_created_date  =getdate_formated ($row['test_created_date']);
                                                $category_id_arr_1     = $row['category_id'];
                                                $batch_row_id               = $row['batch_id'];
                                                $batch_array =  explode(",",$batch_row_id);
                                                if(!in_array($question_array, $test_id)){
                                                $category_query = $mysqli->query("SELECT category_name FROM epariksa_category WHERE category_active = 1 AND category_id IN ($category_id_arr_1)");
                                                $category_arr = mysqli_fetch_array($category_query);
                                                $category_name = $category_arr['category_name'];
                                                $question_query =  $mysqli->query("SELECT question FROM epariksa_questions WHERE question_active = 1 AND question_id = $question_id "); 
                                                $question_arr = mysqli_fetch_array($question_query);

                                                echo '<div class="col-md-6">
                            <div class="card">
                                <div class="card-body">

                                    <div class="d-flex flex-column flex-sm-row">
                                        <a href="fixed-instructor-course-edit.html" class="avatar avatar-lg avatar-4by3 mb-3 w-xs-plus-down-100 mr-sm-3">
                                            <img src="test/'.$test_image.'" alt="Card image cap" class="avatar-img rounded">
                                        </a>
                                        <div class="flex" style="min-width: 200px;">
                                            <!-- <h5 class="card-title text-base m-0"><a href="fixed-instructor-course-edit.html"><strong>Learn Vue.js</strong></a></h5> -->
                                           <h4 class="card-title mb-1"><a href="view-questions.php?test_id="'.$test_id.'"</a>'.$test_title.'</h4><p>'.$category_name.'</p> 
                                           <p class="text-black-70">';
                                           

                                  echo '</p>

                                   <div class="d-flex align-items-end">
                                                <div class="d-flex flex flex-column mr-3">
                                                    <div class="d-flex align-items-center py-1 border-bottom">
                                                        <small class="text-black-70 mr-2">No of Questions: '.$no_of_questions.'</small> <small class="text-black-50">Time:'.$test_time.'</small> </div><div class="d-flex align-items-center py-1">
                                                       
                                                        <small class="text-muted">Total Marks: '.$total_marks.'</small> </div>
                                                </div>
                                                <div class="text-center">
                                                    <a href="view-questions.php?test_id="'.$test_id.'"class="btn btn-sm btn-white">View</a> </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="card__options dropdown right-0 pr-2"><input type="button" name="checked_box" class="checked_frame" data-id = '.$test_id.'  data-batch-id = 1  value="Assign"></div>
                            </div>
                        </div>';
                    } 
                }
 }


 if((isset($_POST['assign_test_id1'])) && (isset($_POST['assign_batch_id1']))){

    $response["success"] = "1";
     echo json_encode($response);
    
 }
  ?>