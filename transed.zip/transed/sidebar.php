



<?php if($session_role_id == 1) { ?>
                <div class="mdk-drawer js-mdk-drawer" id="default-drawer">
                    <div class="mdk-drawer__content ">
                        <div class="sidebar sidebar-left sidebar-dark bg-dark o-hidden" data-perfect-scrollbar>
                            <div class="sidebar-p-y">
                                <div class="sidebar-heading">NAVIGATION</div>
                               
                        
                                <ul class="sidebar-menu sm-active-button-bg">
                                    <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="questionpanel/dashboard.php">
                                           <i class="fas fa-question"></i>Question Panel
                                        </a>
                                    </li>

                              
                                     <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" data-toggle="collapse" href="#student_menu">
                                            <i class="fas fa-user-graduate"></i>Student
                                            <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                        </a>
                                        <ul class="sidebar-submenu sm-indent collapse" id="student_menu">
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="add-student.php">
                                                    <span class="sidebar-menu-text">Add Student</span>
                                                   
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="view-student.php">
                                                    <span class="sidebar-menu-text">View Student</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>

                                      <li class="sidebar-menu-item"> 
                                        <a class="sidebar-menu-button" data-toggle="collapse" href="#Tutors_menu">
                                            <i class="fas fa-user-tie"></i>Tutor
                                            <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                        </a>
                                        <ul class="sidebar-submenu sm-indent collapse" id="Tutors_menu">
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="add-tutor.php">
                                                    <span class="sidebar-menu-text">Add Tutors</span>
                                                   
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="view-tutor.php">
                                                    <span class="sidebar-menu-text">View Tutors</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>


                                     <li class="sidebar-menu-item"> 
                                    <a class="sidebar-menu-button" data-toggle="collapse" href="#batch_menu">
                                          <i class="fas fa-users"></i>Batch
                                            <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                        </a>
                                        <ul class="sidebar-submenu sm-indent collapse" id="batch_menu">
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="add-batch.php">
                                                    <span class="sidebar-menu-text">Add Batch</span>
                                                   
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="view-batches.php">
                                                    <span class="sidebar-menu-text">View Batch</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>




                                    <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" data-toggle="collapse" href="#Test_menu">
                                           <i class="fas fa-laptop-code"></i>Test Creation
                                            <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                        </a>
                                        <ul class="sidebar-submenu sm-indent collapse" id="Test_menu">
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="add-random-test.php">
                                                    <span class="sidebar-menu-text">Random Questions</span>
                                                   
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="manual-test.php">
                                                    <span class="sidebar-menu-text">Manual Questions</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>


                                    <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="view-test-frame.php">
                                             <i class="fas fa-laptop-code"></i>Test Frame
                                        </a>
                                    </li>



                                    <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="test-panel.php">
                                              <i class="fas fa-laptop-code"></i>Test Panel
                                        </a>
                                    </li>

                                 
                                    <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="">
                                           <i class="fas fa-chart-line"></i>Reports
                                        </a>
                                    </li>
                                  


                                    
                                </ul>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>






<?php if($session_role_id == 2) { ?>
                <div class="mdk-drawer js-mdk-drawer" id="default-drawer">
                    <div class="mdk-drawer__content ">
                        <div class="sidebar sidebar-left sidebar-dark bg-dark o-hidden" data-perfect-scrollbar>
                            <div class="sidebar-p-y">
                                <div class="sidebar-heading">NAVIGATION</div>
                               
                            
                                <ul class="sidebar-menu sm-active-button-bg">
                                   
                                 <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" data-toggle="collapse" href="#question_menu">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">help</i>Questions
                                            <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                        </a>
                                        <ul class="sidebar-submenu sm-indent collapse" id="question_menu">
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="">
                                                    <span class="sidebar-menu-text">Category</span>
                                                    
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="">
                                                    <span class="sidebar-menu-text">Subject</span>
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="">
                                                    <span class="sidebar-menu-text">Topics</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>

                                     <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" data-toggle="collapse" href="#student_menu">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">account_box</i>Student
                                            <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                        </a>
                                        <ul class="sidebar-submenu sm-indent collapse" id="student_menu">
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="add-student.php">
                                                    <span class="sidebar-menu-text">Add Student</span>
                                                   
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="view-student.php">
                                                    <span class="sidebar-menu-text">View Student</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>

                                     <!--  <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" data-toggle="collapse" href="#Tutors_menu">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">account_box</i> Tutors
                                            <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                        </a>
                                        <ul class="sidebar-submenu sm-indent collapse" id="Tutors_menu">
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="add-tutor.php">
                                                    <span class="sidebar-menu-text">Add Tutors</span>
                                                   
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="tutor-view.php">
                                                    <span class="sidebar-menu-text">View Tutors</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li> -->
                                    <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="add-test.php">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">dvr</i> Add a test
                                        </a>
                                    </li>
                                    <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">tune</i> Report
                                        </a>
                                    </li>
                                  


                                    
                                </ul>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>






<?php if($session_role_id == 3) { ?>
                <div class="mdk-drawer js-mdk-drawer" id="default-drawer">
                    <div class="mdk-drawer__content ">
                        <div class="sidebar sidebar-left sidebar-dark bg-dark o-hidden" data-perfect-scrollbar>
                            <div class="sidebar-p-y">
                                <div class="sidebar-heading">NAVIGATION</div>
                               
                            
                                <ul class="sidebar-menu sm-active-button-bg">
                          
                                    <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="dashboard.php">
                                           <i class="fas fa-tachometer-alt"></i>Dashboard
                                        </a>
                                    </li>
                                


                                    <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="student-profile.php">
                                              <i class="fas fa-user-graduate"></i>Profile
                                        </a>
                                    </li>
                                  



                                    <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="view-test-frame.php">
                                             <i class="fas fa-laptop-code"></i>Take a Test
                                        </a>
                                    </li>
                                  


                                     <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="test-result.php">
                                            <i class="fas fa-poll-h"></i>View Results
                                        </a>
                                    </li>



                                       <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="student-report.php">
                                             <i class="fas fa-chart-line"></i>Reports
                                        </a>
                                    </li>



                                    
                                </ul>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>









