<?php include('epariksa-transed-config.php'); 
$response["success"] = "0";
        $a = json_encode($response);
$question_id_arr_1 ='0';
$login_id = $session_login_id ;
$test_id  = $_GET['test_id'];  

if(isset($_GET['test_id'])) { 

$test_id  = $_GET['test_id'];                         
        $test_frame_query = $mysqli->query("SELECT * FROM epariksa_test_frame WHERE test_active=1 AND test_id=$test_id");
$query_row = mysqli_fetch_array($test_frame_query);
$test_image      = $query_row['test_image']; 
$test_title      = $query_row['test_title']; 
$no_of_questions = $query_row['no_of_questions']; 
$total_marks     = $query_row['total_marks']; 
$test_time       = $query_row['test_time']; 

    }
/*SUBMIT ANS*/


if(isset($_POST['Submit_ans'])){

    $question_id     = $_POST['question_id'];
    $total_mark      = $_POST['total_marks'];
    $total_question  = count($question_id);
    $ans_question    = $_POST['answer_question'];
    $skip_question   = '0';
    $complete_time   = '0';
    $test_id         = $_POST['test_id'];
    for($i = 0; count($question_id) > $i; $i++) {
        $ans_find_question      = $question_id[$i];
          $question_ans_query   =  $mysqli->query("SELECT * FROM epariksa_questions WHERE question_active = 1 AND question_id   = $ans_find_question");
          $question_ans_arr     = mysqli_fetch_array($question_ans_query);
          $question_ans         = $question_ans_arr['answer'];
          $user_question_ans    = $_POST['question_ans_'.$ans_find_question];
          $ans                  = trim(implode(",",$user_question_ans));
          if($question_ans_arr['answer'] == $ans){
            $answer = '1';
          }
          else{
            $answer = '0';
          }
         
          if(empty($_POST['question_ans_'.$ans_find_question] )){
            $skip_question =$ans_find_question ;

          }
          

		  $update_tempory_ans=$mysqli->query("UPDATE epariksa_temp_ans SET  test_id='$test_id',question_ans ='$answer', question_total_mark ='$total_mark', total_question ='$total_question', total_time ='$complete_time', skip_question ='$skip_question' WHERE login_id = '$login_id' And question_id = '$ans_find_question'");
           






          $question_temp_ans_query   =  $mysqli->query("SELECT * FROM epariksa_temp_ans WHERE login_id = $login_id AND question_id   = $ans_find_question");
          while($question_tmp_ans_arr     = mysqli_fetch_array($question_temp_ans_query)){
            $question_id_temp[]      =  $question_tmp_ans_arr['question_id'] ;
            $question_ans_temp[]     =  $question_tmp_ans_arr['question_ans'] ;
            $skip_question_id_temp[] =  $question_tmp_ans_arr['skip_question'];
          }

      }




           $question_temp_ans_count  =  $mysqli->query("SELECT count(question_ans) AS right_question FROM epariksa_temp_ans WHERE login_id = '$login_id' And  question_ans ='1'" );

            $right_question_count   =mysqli_fetch_array($question_temp_ans_count) ; 
            $question_temp_wrong_ans_count  =  $mysqli->query("SELECT count(question_ans) AS question_wrong_ans FROM epariksa_temp_ans WHERE login_id = '$login_id' And  question_ans ='0'" );
            $wrong_question_count   =mysqli_fetch_array($question_temp_wrong_ans_count) ;

            $test_created_date      =  date('Y-m-d');



            $question_right_ans      = trim($right_question_count['right_question']);
            $question_wrong_ans      = trim($wrong_question_count['question_wrong_ans']);
            $result_question_id      = trim(implode(",",$question_id_temp));
            $result_ans              = trim(implode(",",$question_ans_temp));
            $result_skip_question    = trim(implode(",",$skip_question_id_temp));

             $insert_question_ans = $mysqli->query( "INSERT INTO epariksa_test_result(login_id, test_id, question_id, question_ans, question_skip_id,question_total, question_right_ans, question_wrong_ans, question_complete_time, test_created_date) VALUES ('$login_id','$test_id','$result_question_id','$result_ans','$result_skip_question','$total_mark','$question_right_ans','$question_wrong_ans','$complete_time','$test_created_date')");



            $deletequery = $mysqli->query("DELETE FROM epariksa_temp_ans WHERE login_id=$login_id");
     

               if($deletequery == true){
                    $response["success"] = "1";
                    $a = json_encode($response);
               }
		

             

           

/*echo "INSERT INTO epariksa_temp_ans(login_id,test_id,question_id, question_ans, question_total_mark, total_question, total_time, skip_question) VALUES ('$login_id','$test_id','$ans_find_question','$answer','$total_mark','$total_question','$complete_time','$skip_question')";*/
        //echo $question_id[$i];



 


}



?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Student - Take quiz</title>

    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="assets/css/fontawesome.rtl.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">
     <link href="assets/css/toastr.min.css" rel="stylesheet">
 <style>
   

/*#timer{float:right;}
.panel{width:200px;min-height:100px;background:#542;display:inline-block;float:left;outline:1px solid green}*/
#qContainer{min-height:250px;}
.qPanel{display:none;
    padding: 10px;
}
.options label {
    padding-left: 7px;
}
.active{display:block;background:#FFF}
.active,.current{transition:1s ease-out; -moz-transition:1s ease-out; -webkit-transition:1s ease-out;-0-transition:1s ease-out;}
#nav{text-align:center;margin:30px;}
a.qButton,a.navbutton{background: none repeat scroll 0 0 #ECEEF5;
    border: 1px solid #CAD4E7;
    border-radius: 5px;
    color: #3B5998;
    font-size: 1em;
    font-weight: 700;
    margin: 0 10px 0 0;
    padding: 5px 10px;
    
    text-decoration: none;}
.hidden{display:none}
a.qButton:hover,a.navbutton:hover{cursor:pointer; border-color: #3B5998;}
a.qButton.current{background:#3B5998;color:#FFF}
.options{padding:10px;}
#txt {
  border:none;
  font-family:verdana;
  font-size:16pt;
  font-weight:bold;
  border-right-color:#FFFFFF;
  width:80px;
}
/*****************Results***********/
div#results{text-align:center}
table#resultstats td{text-align:left;}
div#results{background:#FBFDB3; border-radius:10px; border:1px solid #FF8000;padding:10px;margin:10px;width:500px;margin:10px auto;}
div.score,div.result{font-size:2em;color:blue;margin-bottom:10px;font-weight:bold;text-shadow:1px 1px #555}
div.result{color:blue}
.green{color:#85F420}
#initiallyhide
{
    display:none;
}
.sidebar-heading.bg-change{
    background: #fff;
}




    </style>


</head>

<body class=" layout-fluid">


    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->

        <div id="header" data-fixed class="mdk-header js-mdk-header mb-0">
            <div class="mdk-header__content">

                <!-- Navbar -->
                <nav id="default-navbar" class="navbar navbar-expand navbar-dark bg-primary m-0">
                    <div class="container-fluid">
                        <!-- Toggle sidebar -->
                        <a href="dashboard.php" class="navbar-brand">
                            <img src="assets/images/logo/white.svg" class="mr-2" alt="TransEd" />
                            <span class="d-none d-xs-md-block">Epariksa</span>
                        </a>

                        <div class="flex"></div>
                        <!-- Menu -->
                        <ul class="nav navbar-nav flex-nowrap">

                            <!-- Notifications dropdown -->
                        
                            <!-- // END Notifications dropdown -->
                            <!-- User dropdown -->
                            <li class="nav-item dropdown ml-1 ml-md-3">
                                <a class="nav-link  dropdown-toggle" data-toggle="dropdown" href="#" role="button"><img src="assets/images/people/50/guy-6.jpg" alt="Avatar" class="rounded-circle" width="40"></a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="login.php">
                                        <i class="material-icons">lock</i> Logout
                                    </a>
                                </div>
                            </li>
                            <!-- // END User dropdown -->

                        </ul>
                        <!-- // END Menu -->
                    </div>
                </nav>
                <!-- // END Navbar -->

            </div>
        </div>

        <!-- // END Header -->


        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content">

            <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
                <div class="mdk-drawer-layout__content page">

                    <div class="container-fluid page__container">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                            <li class="breadcrumb-item ">Quiz</li>
                        </ol>
                        <div class="card-group">
                            <div class="card extra-card">
                                <div class="card-body text-center">
                                    <h4 class="mb-0"><strong><span class = "total_marks"><?php echo $total_marks; ?></span></strong></h4>
                                    <small class="text-muted-light">TOTAL Mark</small>
                                </div>
                            </div>
                            <div class="card extra-card">
                                <div class="card-body text-center">
                                    <h4 class="text-success mb-0"><strong><span class= "total_question"></span></strong></h4>
                                    <small class="text-muted-light">Total Question</small>
                                </div>
                            </div>
                            <div class="card extra-card">
                                <div class="card-body text-center">
                                    <h4 class="text-danger mb-0"><strong>5</strong></h4>
                                    <small class="text-muted-light">WRONG</small>
                                </div>
                            </div>
                            <div class="card extra-card">
                                <div class="card-body text-center">
                                    <h4 class="text-primary mb-0"><strong>17</strong></h4>
                                    <small class="text-muted-light">LEFT</small>
                                </div>
                            </div>
                        </div>
                        <form method="POST" name="answers" id="answers" action="">

                            <input type="hidden" class = "answer_question" name = "answer_question">

                     
                         <?php   
                               $test_frame_query_2 = $mysqli->query("SELECT * FROM epariksa_test_frame WHERE test_active=1 AND test_id=$test_id");
                               $question_row_count = mysqli_num_rows($test_frame_query_2);
                                $row = mysqli_fetch_array($test_frame_query_2); 
                                                        $k=1;
                                                        $category_id_arr_1     = explode(',', $row['category_id']);
                                                        $subject_id_arr_1      = explode(',', $row['subject_id']);;
                                                        $topic_id_arr_1        = explode(',', $row['topic_id']); 
                                                        $question_id_arr_1     = explode(',', $row['question_id']); 
                                                        $question_created_date  =getdate_formated ($row['test_created_date']);
                                                   
                                                        if(count($question_id_arr_1) > 0){
                                                        for($i=0; $i < count($question_id_arr_1); $i++){
                                                            $category_id = $category_id_arr_1[$i];
                                                            $subject_id = $subject_id_arr_1[$i];
                                                            $topic_id = $topic_id_arr_1[$i];
                                                            $question_id = $question_id_arr_1[$i];

                                                        $question_query =  $mysqli->query("SELECT * FROM epariksa_questions WHERE question_active = 1 AND question_id = $question_id"); 

                                                        $question_arr = mysqli_fetch_array($question_query);

                                                ?> 
                  
                
                   
                    <div class='qPanel' id= 'panel_question_id_<?php echo $question_arr['question_id'];?>'>
                               
                                <div class='qText' data-class= "un_answered_question">
                                 <h4 class="mb-0"><strong>#<?php echo $sno = $i+1;')'; ?></strong><?php echo( $question_arr['question']); ?>  </h4>
                                </div>
                                    <input type = "hidden" name = "question_id[]" value = "<?php echo $question_arr['question_id'];?>">
                                     <input type = "hidden" name = "total_question" value = "<?php echo count($question_id_arr_1);?>"> 
                                     <input type = "hidden" name = "total_marks" value = "<?php echo $row['total_marks'] ;?>">
                                      <input type = "hidden" name = "test_time" value = "<?php echo $row['test_time'] ;?>">
                                      <input type = "hidden" name = "test_id" value = "<?php echo $test_id  ;?>">
                                <div class='options' data-question-id = "<?php echo $question_arr['question_id'] ?>">

                <!--Choice Question -->
                                     <?php if($question_arr['question_type']== 'choice') {?>
                                    <input type='radio' name='question_ans_<?php echo $question_arr['question_id']; ?>[]' value='A' id='op-1-1'><label for='op-1-1'>  <?php echo $question_arr['optionA']; ?></label><br>
                                    <input type='radio' name='question_ans_<?php echo $question_arr['question_id']; ?>[]' value='B' id='op-1-2'><label for='op-1-2'>  <?php echo $question_arr['optionB']; ?></label><br>
                                    <input type='radio' name='question_ans_<?php echo $question_arr['question_id']; ?>[]' value='C' id='op-1-3'><label for='op-1-3'> <?php echo $question_arr['optionC']; ?></label><br>
                                    <input type='radio'name='question_ans_<?php echo $question_arr['question_id']; ?>[]' value='D' id='op-1-4'><label for='op-1-4'>  <?php echo $question_arr['optionD']; ?></label><br>
                                    <?php  } ?>
                    <!-- Multiple Choice-->

                                    <?php if($question_arr['question_type']== 'multiple') {?>
                                    <input type='checkbox' name='question_ans_<?php echo $question_arr['question_id']; ?>[]' value='A' id='op-1-1'><label for='op-1-1'>  <?php echo $question_arr['optionA']; ?></label><br>
                                    <input type='checkbox' name='question_ans_<?php echo $question_arr['question_id']; ?>[]' value='B' id='op-1-2'><label for='op-1-2'>  <?php echo $question_arr['optionB']; ?></label><br>
                                    <input type='checkbox' name='question_ans_<?php echo $question_arr['question_id']; ?>[]' value='C' id='op-1-3'><label for='op-1-3'> <?php echo $question_arr['optionC']; ?></label><br>
                                    <input type='checkbox'name='question_ans_<?php echo $question_arr['question_id']; ?>[]' value='D' id='op-1-4'><label for='op-1-4'>  <?php echo $question_arr['optionD']; ?></label><br>
                                    <?php  } ?>
                    <!--              TRUE OR FALES -->


                                     <?php if($question_arr['question_type']== 'true') {?>
                                    <input type='radio' name='question_ans_<?php echo $question_arr['question_id']; ?>[]' value='True' id='op-1-1'><label for='op-1-1'>True</label><br>
                                    <input type='radio' name='question_ans_<?php echo $question_arr['question_id']; ?>[]' value='False' id='op-1-2'><label for='op-1-2'>False</label><br>
                                    <?php  } ?>

                <!--  IMAGE TYPE -->


                                <?php if($question_arr['question_type']== 'image-type') {?>
                                    <input type='radio' name='question_ans_<?php echo $question_arr['question_id']; ?>[]' value='A' id='op-1-1'><label for='op-1-1'>  <?php echo $question_arr['optionA']; ?></label><br>
                                    <input type='radio' name='question_ans_<?php echo $question_arr['question_id']; ?>[]' value='B' id='op-1-2'><label for='op-1-2'>  <?php echo $question_arr['optionB']; ?></label><br>
                                    <input type='radio' name='question_ans_<?php echo $question_arr['question_id']; ?>[]' value='C' id='op-1-3'><label for='op-1-3'> <?php echo $question_arr['optionC']; ?></label><br>
                                    <input type='radio'name='question_ans_<?php echo $question_arr['question_id']; ?>[]' value='D' id='op-1-4'><label for='op-1-4'>  <?php echo $question_arr['optionD']; ?></label><br>
                                    <?php  } ?>


                              


                                </div>

                               
                            </div>
 <?php  }  }?>
                <div id='nav'><a class='navbutton' onclick='nav(-1)'>&laquo; Previous Question</a> <a class='navbutton' onclick='nav(1)'>Next Question &raquo;</a>

                    <?php for($show = 0; count($question_id_arr_1) > $show;$show++){?>

                    <a class='qButton' id= "button_<?php echo $show; ?>"  onclick='show(<?php echo $show; ?>)' style="display: none;"><?php echo  $show+1;?></a>
                    <?php } ?>
                </div>               

                    <center><button type="button" class="btn btn-primary btn-rounded" name="Submit_ans">Submit Answer</button></center>


                   
                </form>


                    </div>

                </div>




                <div class="mdk-drawer js-mdk-drawer" data-align="end">
                    <div class="mdk-drawer__content ">
                        <div class="sidebar sidebar-right sidebar-light bg-white o-hidden" data-perfect-scrollbar>
                            <div class="sidebar-p-y solTitle ">
                                <div class="sidebar-heading bg-change">Time left</div>
                                <div class="countdown sidebar-p-x" data-value="4" data-unit="hour"></div>

                                <div class="sidebar-heading bg-change">Pending</div>
                                <ul class="list-group list-group-fit" id="skiped_question">
                                   
                                   
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

           

        </div>
    </div>





    <div class="mdk-drawer js-mdk-drawer" id="default-drawer">
        <div class="mdk-drawer__content ">
            <div class="sidebar sidebar-left sidebar-dark bg-dark o-hidden" data-perfect-scrollbar>
                <div class="sidebar-p-y">
                    <div class="sidebar-heading">NAVIGATION</div>
                    <!-- Components menu -->
                    
                   
                            <ul class="sidebar-menu sm-active-button-bg">
                                   
                                 <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" data-toggle="collapse" href="#question_menu">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">help</i> Questions
                                            <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                        </a>
                                        <ul class="sidebar-submenu sm-indent collapse" id="question_menu">
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="">
                                                    <span class="sidebar-menu-text">Category</span>
                                                    
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="">
                                                    <span class="sidebar-menu-text">Subject</span>
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="">
                                                    <span class="sidebar-menu-text">Topics</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>

                                     <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" data-toggle="collapse" href="#student_menu">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">account_box</i> Student
                                            <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                        </a>
                                        <ul class="sidebar-submenu sm-indent collapse" id="student_menu">
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="add-student.php">
                                                    <span class="sidebar-menu-text">Add Student</span>
                                                   
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="student-view.php">
                                                    <span class="sidebar-menu-text">View Student</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>

                                      <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" data-toggle="collapse" href="#Tutors_menu">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">school</i> Tutors
                                            <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                        </a>
                                        <ul class="sidebar-submenu sm-indent collapse" id="Tutors_menu">
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="add-tutor.php">
                                                    <span class="sidebar-menu-text">Add Tutors</span>
                                                   
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="tutor-view.php">
                                                    <span class="sidebar-menu-text">View Tutors</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>


                                    <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" data-toggle="collapse" href="#Test_menu">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">dvr</i> Test Creation
                                            <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                        </a>
                                        <ul class="sidebar-submenu sm-indent collapse" id="Test_menu">
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="add-random-test.php">
                                                    <span class="sidebar-menu-text">Random Test</span>
                                                   
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="add-manual-test.php">
                                                    <span class="sidebar-menu-text">Manual Test</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>





                                    <!-- <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="add-test.php">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">dvr</i> Add a test
                                        </a>
                                    </li> -->
                                    <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">tune</i> Report
                                        </a>
                                    </li>
                                  


                                    
                                </ul>
                    <!-- // END Components Menu -->

                   
                </div>
            </div>
        </div>
    </div>



    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/dom-factory.js"></script>
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- App Settings (safe to remove) -->
    <script src="assets/js/app-settings.js"></script>


    <!-- Required by countdown -->
    <script src="assets/vendor/moment.min.js"></script>
    <!-- Easy Countdown -->
    <script src="assets/vendor/jquery.countdown.min.js"></script>



    <!-- Init -->
    <script src="assets/js/countdown.js"></script>
<script type="text/javascript" src="assets/js/toastr.min.js"></script>

<script type="text/javascript">

/*Skip Question Find*/
$('.options').click(function(){
    var question_id =$(this).data("question-id") ;
    var answer_question = $('.answer_question').val();
    $.ajax
({
  type: "POST",
  url: "ajax-file.php",
  data: {ans_question:question_id},
  success: function(response)
  {
     //alert(response);
  }
});

var test_id = "<?php echo $test_id;?>";

$.ajax
({
  type: "POST",
  url: "ajax-file.php",
  data: {test_id:test_id},
  success: function(response)
  {
     $("#skiped_question").html(response);
     //alert(response);
  }
});


       
})

var test_id = "<?php echo $test_id;?>";

$.ajax
({
  type: "POST",
  url: "ajax-file.php",
  data: {test_id:test_id},
  success: function(response)
  {
     $("#skiped_question").html(response);
     //alert(response);
  }
});


/*Skiped question cliked active panel*/
function openSolution(elem){


    var panel_id = $(elem).data("id");
     var panel_button = $(elem).data("button");
     console.log(panel_button);
     //alert(panel_button);
      $('.qPanel').removeClass('active');
      $('.qButton').removeClass('current');
     $('#'+ panel_id).addClass( 'active' );
     $('#'+ panel_button).addClass( 'current' );

}







$('.total_question').text('<?php echo count($question_id_arr_1); ?>');
$('.total_marks').text('<?php echo $total_marks; ?>');
    
var mins
var secs;

function cd() {
    mins = 1 * m("2"); // change minutes here
    secs = 0 + s(":52"); // change seconds here (always add an additional second to your total)
    redo();
}
function ud_cd(){
    obj.minis = 1 * m("2");
    obj.secs  = 0 +s(":90");
    redo();
}


function m(obj) {
    for(var i = 0; i < obj.length; i++) {
        if(obj.substring(i, i + 1) == ":")
        break;
    }
    return(obj.substring(0, i));
}

function s(obj) {
    for(var i = 0; i < obj.length; i++) {
        if(obj.substring(i, i + 1) == ":")
        break;
    }
    return(obj.substring(i + 1, obj.length));
}

function dis(mins,secs) {
    var disp;
    if(mins <= 9) {
        disp = " 0";
    } else {
        disp = " ";
    }
    disp += mins + ":";
    if(secs <= 9) {
        disp += "0" + secs;
    } else {
        disp += secs;
    }
    return(disp);
}

function redo() {
    secs--;
    if(secs == -1) {
        secs = 59;
        mins--;
    }
//  document.cd.disp.value = dis(mins,secs); 
    if((mins ==1) && (secs == 0)) 
        window.alert("Only 1 minute remains...\nSpeed Up"); 
    
    if((mins == 0) && (secs == 0)) {
        window.alert("Time is up. Press OK to continue."); 
        answers.submit();
        console.log("submitted");
    } else {
        cd = setTimeout("redo()",1000);
    }
}

var numQuestions,
    navs;
function init() {
  cd();
  numQuestions = document.getElementsByClassName("qButton").length;
  navs = document.getElementsByClassName('navbutton');
  show(0);
}
window.onload = init;
var currentQuestion = 0;


                        document.getElementsByClassName("qPanel")[0].className+=" active";
                        document.getElementsByClassName("qButton")[0].className+=" current";

function show(i)
{ 
    document.getElementsByClassName("current")[0].className="qButton";
    document.getElementsByClassName("active")[0].className="qPanel";
    
    document.getElementsByClassName("qPanel")[i].className+=" active";
    document.getElementsByClassName("qButton")[i].className+=" current";
    
    navs[0].style.display = i===0 ? 'none' : '';
    navs[1].style.display = i===numQuestions-1 ? 'none' : '';
    
    currentQuestion=i;
    
}
function nav(offset)
{
    var targetQuestion = currentQuestion + offset;
    if ( targetQuestion>=0 && targetQuestion< document.getElementsByClassName("qButton").length)
        show(targetQuestion);
    }
</script>

<script>

     var a = '<?php echo  $a ;?>';
      var obj = JSON.parse(a);
      if (obj.success == 1){
  toastr.success('Success', 'Deleted Successfully', {
                  timeOut: 5000})
}
</script>

</body>

</html>