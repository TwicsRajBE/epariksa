<?php
 include('epariksa-transed-config.php'); 


  
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Transed</title>

    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="assets/css/fontawesome.rtl.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">

<link rel="stylesheet" href="//code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css">
 <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.css" rel="stylesheet">
</head>

<body class=" layout-fluid">

    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->
<?php include 'header.php';?>
        <!-- // END Header -->
<!-- Header Layout Content -->
<div class="mdk-header-layout__content">
    <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
        <div class="mdk-drawer-layout__content page">
            <div class="container-fluid page__container">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                    <!-- <li class="breadcrumb-item">Student</li> -->
                    <li class="breadcrumb-item active">View Batches</li>
                </ol>

                    <div class="d-flex flex-column flex-sm-row flex-wrap mb-headings align-items-start align-items-sm-center">
                        <div class="flex mb-2 mb-sm-0">
                            <h1 class="h2">View Batches</h1>
                        </div>
                      
                    </div>

                    

                 <!--    <div class="alert alert-light alert-dismissible border-1 border-left-3 border-left-warning" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <div class="text-black-70">Ohh no! No courses to display. Add some courses.</div>
                    </div>
 -->
                    <div class="row">

                        <?php 

                        $batches_query = $mysqli->query("SELECT * FROM epariksa_batch Where batch_active = '1'");
                        //$batches_Row    = mysqli_fetch_array($batches_query);
                        While($row =  mysqli_fetch_array($batches_query)){
                             $id =  urlencode( base64_encode( $row['batch_id']) );
                             
                        ?>


                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">

                                    <div class="d-flex flex-column flex-sm-row">
                                        
                                        <div class="flex" style="min-width: 200px;">
                                            <!-- <h5 class="card-title text-base m-0"><a href="fixed-instructor-course-edit.html"><strong>Learn Vue.js</strong></a></h5> -->
                                            <h4 class="card-title mb-1"><!-- <a href="fixed-instructor-course-edit.html">Batch Name</a> -->
                                                <span><?php echo  $row['batch_name'] ?></span>
                                                


                                            </h4>
                                            
                                            
                                         <p>No of Students</p>
                                            <div class="d-flex align-items-end">
                                                <div class="d-flex flex flex-column mr-3">
                                                    <div class="d-flex align-items-center py-1 border-bottom dis-inline">
                                                        <small class="text-black-70 mr-2">validity Period: Period</small>
                                                    </div>
                                                    <div class="d-flex align-items-center py-1 dis-inline">
                                                       <!--  <small class="text-muted mr-2">GULP</small> -->
                                                        <small class="text-muted">No of Test frame :  Test frame</small>
                                                    </div>
                                                </div>
                                                <div class="text-center">
                                                    <a href="assign-test.php?id=<?php echo  $id;?>" class="btn btn-sm btn-white">View</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            
                            </div>
                        </div>
                      
                     <?php } ?>

                    </div>





              
                
            </div>

        </div>




    <?php include 'sidebar.php';?>

    </div>

    
</div>
</div>

    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/dom-factory.js"></script>
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- App Settings (safe to remove) -->
    <script src="assets/js/app-settings.js"></script>






    <!-- List.js -->
    <script src="assets/vendor/list.min.js"></script>
    <script src="assets/js/list.js"></script>

    <!-- Tables -->
    <script src="assets/js/toggle-check-all.js"></script>
    <script src="assets/js/check-selected-row.js"></script>



  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script src="https://loopj.com/jquery-tokeninput/src/jquery.tokeninput.js"></script>


<script>
  $( function() {
    var availableTags = [<?php echo $arraytitle; ?>];
    
    $("#test_title").autocomplete({
      source: availableTags
    });
  } );
</script>


</body>

</html>