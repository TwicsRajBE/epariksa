-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2019 at 01:09 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epariksa_transed`
--

-- --------------------------------------------------------

--
-- Table structure for table `epariksa_batch`
--

CREATE TABLE `epariksa_batch` (
  `batch_id` int(12) NOT NULL,
  `batch_name` varchar(50) NOT NULL,
  `valid_from` date NOT NULL,
  `valid_to` date NOT NULL,
  `batch_created_by` int(5) NOT NULL,
  `batch_created_date` date NOT NULL,
  `batch_modified_date` datetime NOT NULL,
  `batch_active` bit(1) NOT NULL DEFAULT b'1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `epariksa_batch`
--

INSERT INTO `epariksa_batch` (`batch_id`, `batch_name`, `valid_from`, `valid_to`, `batch_created_by`, `batch_created_date`, `batch_modified_date`, `batch_active`) VALUES
(1, 'Batch 1', '0000-00-00', '0000-00-00', 1, '2019-03-23', '2019-03-23 18:15:12', b'1'),
(2, 'Batch 2', '0000-00-00', '0000-00-00', 1, '0000-00-00', '2019-03-23 08:15:29', b'1'),
(3, 'Batch 3', '0000-00-00', '0000-00-00', 1, '2019-03-23', '2019-03-23 18:25:14', b'1'),
(4, 'Batch 4', '0000-00-00', '0000-00-00', 1, '2019-03-23', '2019-03-23 18:27:26', b'1'),
(5, 'Test', '2019-03-05', '2019-03-29', 1, '2019-03-28', '2019-03-28 11:34:06', b'1'),
(6, 'Test1', '2019-03-01', '2019-03-31', 1, '2019-03-28', '2019-03-28 11:34:27', b'1'),
(7, 'Test1t', '2019-03-01', '2019-03-30', 1, '2019-03-28', '2019-03-28 11:35:04', b'1'),
(8, 'Testfgdfgfdg', '2019-03-05', '2019-03-30', 1, '2019-03-28', '2019-03-28 15:33:58', b'1');

-- --------------------------------------------------------

--
-- Table structure for table `epariksa_category`
--

CREATE TABLE `epariksa_category` (
  `category_id` int(5) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `category_description` text NOT NULL,
  `category_date` date NOT NULL,
  `category_created_date` date NOT NULL,
  `category_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `category_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `epariksa_category`
--

INSERT INTO `epariksa_category` (`category_id`, `category_name`, `category_description`, `category_date`, `category_created_date`, `category_modified_date`, `category_active`) VALUES
(1, 'TNPSC', '', '2019-03-22', '2019-03-22', '2019-03-22 07:33:23', 1),
(2, 'UPSC', '', '2019-03-22', '2019-03-22', '2019-03-22 07:33:30', 1),
(3, 'IBBS', '', '2019-03-22', '2019-03-22', '2019-03-22 07:33:34', 1),
(4, 'IAS', '', '2019-03-22', '2019-03-22', '2019-03-22 07:33:38', 1);

-- --------------------------------------------------------

--
-- Table structure for table `epariksa_login`
--

CREATE TABLE `epariksa_login` (
  `login_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `mobile_number` varchar(10) NOT NULL,
  `user_image` varchar(255) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `login_created_date` date NOT NULL,
  `login_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `login_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `epariksa_login`
--

INSERT INTO `epariksa_login` (`login_id`, `role_id`, `username`, `email`, `password`, `mobile_number`, `user_image`, `created_by`, `batch_id`, `login_created_date`, `login_modified_date`, `login_active`) VALUES
(1, 1, 'admin', 'admin@gmail.com', '12345', '', '', '', 0, '2018-12-25', '2019-03-28 06:30:10', 1),
(5, 3, 'gayathri', 'gayathri@twics.in', '12345', '987654321', '', 'Admin', 1, '2019-03-20', '2019-03-28 06:30:08', 1),
(11, 3, 'surya', 'surya@twics.in', '12345', '987654321', '', 'Admin', 1, '2019-03-20', '2019-03-28 06:37:56', 1),
(12, 2, 'jh', 'ghjgh', 'jghjghj', '567567', '', 'Admin', 3, '2019-03-28', '2019-03-28 06:41:16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `epariksa_questions`
--

CREATE TABLE `epariksa_questions` (
  `question_id` int(11) NOT NULL,
  `role_id` int(5) NOT NULL,
  `category_id` int(5) NOT NULL,
  `subject_id` int(5) NOT NULL,
  `topic_id` int(5) NOT NULL,
  `question_type` varchar(50) NOT NULL,
  `question` text NOT NULL,
  `optionA` text NOT NULL,
  `optionB` text NOT NULL,
  `optionC` text NOT NULL,
  `optionD` text NOT NULL,
  `optionE` text NOT NULL,
  `optionP` varchar(250) NOT NULL,
  `optionQ` varchar(250) NOT NULL,
  `optionR` varchar(250) NOT NULL,
  `optionS` varchar(250) NOT NULL,
  `answer` text NOT NULL,
  `answerP` varchar(50) NOT NULL,
  `answerQ` varchar(50) NOT NULL,
  `answerR` varchar(50) NOT NULL,
  `answerS` varchar(50) NOT NULL,
  `solution` text NOT NULL,
  `question_created_date` date NOT NULL,
  `question_modified_date` datetime NOT NULL,
  `question_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `epariksa_questions`
--

INSERT INTO `epariksa_questions` (`question_id`, `role_id`, `category_id`, `subject_id`, `topic_id`, `question_type`, `question`, `optionA`, `optionB`, `optionC`, `optionD`, `optionE`, `optionP`, `optionQ`, `optionR`, `optionS`, `answer`, `answerP`, `answerQ`, `answerR`, `answerS`, `solution`, `question_created_date`, `question_modified_date`, `question_active`) VALUES
(1, 1, 1, 1, 4, 'multiple', '<p>During the period of Mahajanapadas, Magadhas most serious Rival was</p>', 'Koshala', 'Avanti', 'Gandhara', 'Anga', '', '', '', '', '', 'A,B', '', '', '', '', '<p>AngaAngaAngaAngaAnga</p>', '2019-03-18', '2019-03-18 12:00:42', 1),
(2, 1, 3, 1, 1, 'choice', '<p><strong>Which of the following served as Capitals of Magadha, the most powerful Mahajanapada?</strong></p>\r\n\r\n<p>1.Rajgir&nbsp; &nbsp; &nbsp;2.Pataliputra&nbsp; &nbsp; &nbsp;3.Taxila&nbsp; &nbsp; &nbsp;4.Ujjain</p>', '1 and 2', '2 and 3', '3 and 4', '4 and 1', '', '', '', '', '', 'C', '', '', '', '', '<p>following served as Capitals of Magadha, the most powerful Mahajanapada</p>', '2019-03-18', '2019-03-18 12:05:05', 1),
(3, 1, 1, 2, 3, 'true', '<p>Who was called ss &quot;Amitragatha&quot; meaning Slayer of Enemies ?</p>\r\n\r\n<p>&nbsp;</p>', 'Koshala', 'Amitragatha', 'Slayer ', 'Enemies ', '', '', '', '', '', 'True', '', '', '', '', '<p>Who was called ss &quot;Amitragatha&quot; meaning Slayer of Enemies Who was called ss &quot;Amitragatha&quot; meaning Slayer of Enemies ?</p>\r\n\r\n<p>&nbsp;</p>', '2019-03-18', '2019-03-18 12:06:03', 1),
(4, 1, 1, 3, 4, 'image-type', '<p><img src=\"image_type_question/girl-512.png\" alt=\"\" width=\"121\" height=\"121\" /></p>', '<p><img src=\"image_type_question/lgo-06-15-17-a-twitter.jpg\" alt=\"\" width=\"83\" height=\"83\" /></p>', '<p>image type 2</p>', '<p>image type 3</p>', '<p>image type 4</p>', '', '', '', '', '', '', '', '', '', '', '', '2019-03-18', '2019-03-18 12:08:08', 0),
(5, 1, 1, 1, 2, 'multiple', '<p>Which of the following countries has agreed to accept the payment of export of oil and petroleum products to India, in rupee terms instead of dollar or any other currency?</p>', 'Kuwait', 'UAE', 'Iran', 'Iraq', '', '', '', '', '', 'B', '', '', '', '', '', '2019-03-22', '2019-03-22 11:33:22', 1),
(6, 1, 1, 3, 3, 'multiple', '<p>As per the newspaper reports Government of India has finally agreed to purchase advanced MRMRs for its naval forces. What are these MRMRs?&nbsp;&nbsp;</p>', 'Aircrafts', 'Warships', 'Submarines', 'Radar Systems', '', '', '', '', '', 'B', '', '', '', '', '', '2019-03-22', '2019-03-22 11:34:29', 1),
(7, 1, 1, 3, 3, 'multiple', 'Which of the following has most of the bank branches? -', 'Allahabad Bank ', 'HDFC Bank ', 'ICICI Bank ', 'State Bank of India ', '', '', '', '', '', 'd', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(8, 1, 4, 4, 2, 'multiple', 'National stock exchange is located -', 'New Delhi ', 'Mumbai ', 'Kolkata ', 'Bangalore ', '', '', '', '', '', 'b', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(9, 1, 1, 1, 4, 'multiple', 'Where is the head quarter of world Bank?', 'America ', 'London ', 'Washington DC ', 'New York ', '', '', '', '', '', 'b', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(10, 1, 4, 4, 2, 'multiple', 'Where is the head quarter of International monetary fund (IMF)?', 'London ', 'New York ', 'Washington DC ', 'Peris ', '', '', '', '', '', 'b', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(11, 1, 4, 4, 2, 'multiple', 'Where is the head quarter of world Health organization (WHO)?', 'New York ', 'Jineva ', 'Peris ', 'London ', '', '', '', '', '', 'c', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(12, 1, 2, 3, 1, 'multiple', 'Who is called the Father of Computer ?', 'Bill Gates ', 'Charles Babbage ', 'Bells Pascal ', 'Josef Jackured ', '', '', '', '', '', 'b', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(13, 1, 2, 3, 1, 'multiple', 'Super computer which is made by India?', 'T3A ', 'Yanha 3 ', 'PARAM 10000 ', 'J8 ', '', '', '', '', '', 'c', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(14, 1, 2, 3, 1, 'multiple', 'The first computer which is made by India.', 'Siddharth ', 'PARAM ', 'MEGHA ', 'Cyber ', '', '', '', '', '', 'a', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(15, 1, 2, 3, 1, 'multiple', 'The first Electronic digital computer of the world is?', 'ANIYAK ', 'SIDDHARTH ', 'PARAM ', 'DEEP ', '', '', '', '', '', 'a', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(16, 1, 2, 3, 1, 'multiple', 'What language does the computer work?', 'BASIC ', 'COBOL ', 'Machine ', 'FORTRON ', '', '', '', '', '', 'c', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(17, 1, 1, 5, 2, 'multiple', 'What is national sport of India?', 'Kabaddi ', 'Cricket ', 'Hockey ', 'Chess ', '', '', '', '', '', 'c', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(18, 1, 1, 5, 2, 'multiple', 'Cricket is started from which of the following country? -', 'Australia ', 'India ', 'England ', 'West Indies ', '', '', '', '', '', 'c', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(19, 1, 1, 5, 2, 'multiple', 'How much players are there in each team of Cricket?', '2', '11', '12', '10', '', '', '', '', '', 'b', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(20, 1, 1, 5, 2, 'multiple', 'How many balls are thrown in one over in cricket?', '4', '12', '6', '8', '', '', '', '', '', 'c', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(21, 1, 1, 5, 2, 'multiple', 'How much players are there in each team of Kabaddi?', '7', '8', '11', '5', '', '', '', '', '', 'a', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(22, 1, 3, 6, 2, 'multiple', 'A money (at simple interest) amounts to Rs. 1200 in 3 years &amp; to Rs. 1280 in years. The sum is -', 'Rs. 840 ', 'Rs. 960 ', 'Rs. 900 ', 'Rs. 940 ', '', '', '', '', '', 'b', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(23, 1, 3, 6, 2, 'multiple', 'How much time will it take for an amount of Rs. 1500 to get Rs 225 as interest at 5% per annum of simple interest?', '1 Year ', '2 Year ', '4 Years ', '3 Years ', '', '', '', '', '', 'a', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(24, 1, 3, 6, 2, 'multiple', 'What will be the simple interest on an amount of Rs 2000 in 3 Years at interest 4% Per annum?', 'Rs . 220 ', 'Rs . 240 ', 'Rs . 250 ', 'Rs . 280 ', '', '', '', '', '', 'b', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(25, 1, 3, 6, 2, 'multiple', 'At what rate of interest, a sum of Rs 15000, will be Rs 17625 in 5 Years?', '0.03', '0.135', '0.04', '0.145', '', '', '', '', '', 'b', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(26, 1, 3, 6, 2, 'multiple', 'A Person takes a loan ofRs 2500 at 4% simple interest. He returns Rs 1500 at the end of 1 Year. What amount he would pay to clear his dues at the end of 2 Years?', 'Rs. 1100 ', 'Rs. 1140 ', 'Rs. 1050 ', 'Rs. 1150 ', '', '', '', '', '', 'b', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(27, 1, 1, 1, 1, 'multiple', 'In January 2015, India has successfully test container based missile Agni -5. With the test, India has joined the five countries, which are equipped with inter -continental ballistic missile. Where it was tested?', 'Chandipur (Odisha) ', 'Shri Harikota (Andhra Pradesh) ', 'Thiruvanamthapuram (Kerala) ', 'Hyderabad (Andhra Pradesh ', '', '', '', '', '', 'c', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(28, 1, 6, 1, 3, 'multiple', 'In January 2015, India has successfully test container based missile Agni -5 from chandipur integrated test range when it was tested?', '28 January ', '25 January ', '31 January', '21 January', '', '', '', '', '', 'd', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(29, 1, 6, 1, 3, 'multiple', 'When was concluded the 15th Delhi sustainable development convention on climate change', '5-7 February2015 ', '10 â€“15 February2015 ', '25-30 January2015 ', '20 â€“25 January2015 ', '', '', '', '', '', 'b', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(30, 1, 6, 1, 3, 'multiple', 'The mobile handset manufacture company &ldquo;Xiaomi&quot; is from which country?', 'India ', 'China ', 'Japan ', 'Korea ', '', '', '', '', '', 'a', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(31, 1, 6, 1, 3, 'multiple', 'The first state in the country to apply &quot;Web based learning program&quot; on December 23, 2014 is', 'Delhi ', 'Arunachal Pradesh ', 'Gujrat ', 'Karnataka ', '', '', '', '', '', 'b', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(32, 1, 5, 7, 4, 'multiple', 'Find out which of the figures (1), (2), (3) and (4) can be formed from the pieces given in figure (X). ', '1', '2', '3', '4', '', '', '', '', '', 'a', '', '', '', '', 'No answer description available for this question. ', '2019-03-22', '2019-03-22 12:14:44', 1),
(33, 1, 5, 7, 4, 'multiple', 'Find out which of the figures (1), (2), (3) and (4) can be formed from the pieces given in figure (X).', '1', '2', '3', '4', '', '', '', '', '', 'a', '', '', '', '', 'No answer description available for this question.   ', '2019-03-22', '2019-03-22 12:14:44', 1),
(34, 1, 2, 3, 5, 'multiple', 'A complaint \"Network not working\" logged into customer care. You called to customer to understand the exact problem he/ she was facing, what will be the first thing, which you will ask the customer to do so?', 'Ask him to check whether a \"Red Cross Mark\" appear at Network icon.', 'Ask him to check whether LAN Card is plugged on not.', 'Ask him to restart the PC', 'None of these', '', '', '', '', '', 'a', '', '', '', '', 'Operating System', '2019-03-22', '2019-03-22 12:14:44', 1),
(35, 1, 1, 3, 4, 'multiple', 'What should you do on your first visit to the customer?', 'I will greet the customer and ask about the problem he is facing', 'I will show our products', 'I will ask the problem', 'All of these', '', '', '', '', '', 'b', '', '', '', '', 'Animation/movie file', '2019-03-22', '2019-03-22 12:14:44', 1),
(36, 1, 2, 3, 5, 'multiple', 'You got a complaint from customer care department related to computer problem, to know the exact residence location of customer, which one is the most appropriate question to be asked from customer.', 'Sir, Where is your house', 'Sir, I am calling from XYZ Computer Services, Can I know the location of your residence.', 'Sir, where are you living, I will come for examine your PC.', 'Sir, Good Morning, I am Rajesh Saxena from XYZ Computer Services, can you please tell me the location of your residence.', '', '', '', '', '', 'c', '', '', '', '', 'Australia', '2019-03-22', '2019-03-22 12:14:44', 1),
(37, 1, 2, 3, 5, 'multiple', 'You reached at customer\'s place to resolve problem related to computer. Customer started shouting on you as you reached. What you will do?', 'I will also shouting on the customer', 'I will ask him to call another vendor to resolve your computerâ€™s problem.', 'I will ask, if you will shout again, I will go back.', 'I will politely say sorry, and try to understand the problem he was facing with his computer.', '', '', '', '', '', 'd', '', '', '', '', 'geographic grids', '2019-03-22', '2019-03-22 12:14:44', 1),
(38, 1, 2, 3, 5, 'multiple', 'What is the importance of customer feedback on work done by you?', 'To understand the customer\'s requirements', 'To understand the quality of work done', 'To know our behaviour at customer place', 'All the above', '', '', '', '', '', 'a', '', '', '', '', 'Savannah', '2019-03-22', '2019-03-22 12:14:44', 1),
(39, 1, 2, 3, 5, 'multiple', 'Which is the most appropriate answer to find the customer\'s location', 'Ayodhya Nagar', 'Mr Rajesh Gupta\nHouse No - 43, Ayodhya Nagar', 'Mr Rajesh Gupta', 'House No - 43, Ayodhya Nagar', '', '', '', '', '', 'b', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(40, 1, 2, 3, 5, 'multiple', 'You receive a call from customer care related to problem in computer of a customer, problem is â€œNo displayâ€, which is the most appropriate question you will ask to customer during call to customer before visit to residence', 'Sir, have you listen any BEEP sound after power on the system?', 'Sir, have you seen any color in the LED light on the front of Monitor?', 'Both A and B', 'None of these', '', '', '', '', '', 'c', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(41, 1, 2, 3, 5, 'multiple', 'Before visit to customer\'s house, you called the customer to understand the problem he is facing, The problem reported was \"computer not working\"', 'Sir, have you listen any BEEP sound after power on the system?', 'Sir,  is there any display on monitor', 'Sir, have you done, power cable are properly fixed and turn on the system.', 'All of these', '', '', '', '', '', 'd', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(42, 1, 2, 3, 5, 'multiple', 'You visited a customer and found the hard disk having BAD SECTORS, which is the most, appropriate information given by you to customer. (Hard Disk is under one year replacement warranty).', 'Sir, the hard disk is not working properly and need to replace, I have mention the details of hard disk In customer slip, mean while I have installed a spare HDD in computer so your work will not affected.', 'Sir, hard disk is not working and send to repair/ repair to TRC, it will take time', 'Sir, hard disk is not working and will replace or repair', 'Sir, hard disk is not working and will be replaced on chargeable basis.', '', '', '', '', '', 'a', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(43, 1, 5, 2, 5, 'multiple', 'Before visit to customer\'s home, which is the most appropriate question to be asked from customer to know the warranty details of computer', 'Sir, how old is your computer?', 'Sir, when did you buy this computer?', 'Sir Should I know the date of purchase of computer?', 'Sir, what is purchase date of computer?', '', '', '', '', '', 'b', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(44, 1, 5, 0, 5, 'multiple', 'During visit to customerâ€™s house, you found the SMPS is not working properly, what you will do in this case. \n\n(The PC is under warranty).', 'I will inform to customer and remove it from PC for replacement.', 'I will replace the SMPS by spare one after inform to customer and also inform that \"after getting the replacement from OEM within 8 -10 days I will replace the same.', 'I will replace the SMPS without informing to customer because it is under warranty.', 'I will ask to supervisor', '', '', '', '', '', 'a,b', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(45, 1, 2, 3, 5, 'multiple', 'You went to a Mr. Sharmaâ€™s house for installation of a new system.  During installation and discussion you knew that Mr. Sharm is working as DTP operator and frequent use of designing programs. Which programs you would like to suggest installing in new system.', 'Photo Shop', 'MS Office', 'Windows', 'Tally', '', '', '', '', '', 'a,b,c,d', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(46, 1, 2, 3, 5, 'multiple', 'Which one is the correct position of placing the computer packaging?', 'Windows', 'Tally', 'Photo Shop', 'MS Office', '', '', '', '', '', 'a,b', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(47, 1, 2, 3, 5, 'multiple', 'Which of the following microprocessor chip is used to install in the server computer?', 'Tally', 'MS Office', 'Windows', 'Photo Shop', '', '', '', '', '', 'a,b,c', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(48, 1, 2, 3, 5, 'multiple', 'Which type of port shown in the image?', 'USB-3.0', 'LAN Port', 'VGA', 'HDMI', '', '', '', '', '', 'a,b,c,d', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(49, 1, 2, 3, 5, 'multiple', 'Which one is the essential device for using the laptop?', 'VGA', 'HDMI', 'LAN Port', 'USB-3.0', '', '', '', '', '', 'a,b', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(50, 1, 2, 3, 5, 'multiple', 'Which device is shown in the following image?', 'Components holding clip', 'Anti static ESD wrist strap', 'Anti static ESD mat', 'Anti static ESD tester', '', '', '', '', '', 'a,b,c', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(51, 1, 2, 3, 5, 'multiple', 'Guidelines:\n1.  . Complaint related printer installation; first you should update operating system.\n2. Complaint related to virus related issue, first you must install Antivirus on System\n\nQuestion:\n You went to a problem, related to virus at Mr. Guptaâ€™s house. Which is the most appropriate process you should adhere?\n\n\n', 'First I will update operating system', 'First I will install antivirus on the system', 'First I will format the system', 'None of these', '', '', '', '', '', 'a,b,c,d', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(52, 1, 2, 3, 5, 'multiple', 'Which is the correct position of the mouse and hand?', 'First I will update the operating system, before installing the printer.', 'First I will update the antivirus, before installing the printer.', 'Both (a) and (b)', 'None of these', '', '', '', '', '', 'a', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(53, 1, 2, 3, 5, 'multiple', 'Guidelines:\nBefore installing printer, you should update the operating system.\nBefore scanning the virus in the system, you should update the antivirus.\nBefore adding a new hardware, you should update the operating system.\nQuestion:\nYou went to customerâ€™s house to install a new printer. What is the most appropriate process you will adhere?\n\n\n\n\n', 'True', 'False', '', '', '', '', '', '', '', 'True', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(54, 1, 2, 3, 5, 'multiple', 'Arrange the steps of installing a printer in the correct order\n1. Install printer driver\n2. connect power cord and switch on the printer\n3. Connect the printer with computer\n4. Print a test page\n5. Switch on the computer', 'True', 'False', '', '', '', '', '', '', '', 'False', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(55, 1, 2, 3, 5, 'multiple', 'A customer complains that his computer DVD drive is not playing the inserted disk. After checking you found only the lens of drive have to clean which require cleaning by hand to make it smooth working. What will you use to clean the lens of DVD drive?', 'True', 'False', '', '', '', '', '', '', '', 'True', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(56, 1, 2, 3, 5, 'multiple', 'While carrying out the installation process at a customer\'s place you had a lot of problems due the faulty tools provided by the company. To whom will you report the above problem?', 'True', 'False', '', '', '', '', '', '', '', 'False', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(57, 1, 2, 3, 5, 'multiple', 'Your customer need to increase computer storage capacity from 60 GB, what will you carry with you while going on site?', 'True', 'False', '', '', '', '', '', '', '', 'True', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(58, 1, 2, 3, 5, 'multiple', 'Before installing the hardware we should check the â€¦â€¦â€¦â€¦â€¦â€¦..', 'True', 'False', '', '', '', '', '', '', '', 'False', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(59, 1, 2, 3, 5, 'multiple', 'Which type of connector shown in the image?', 'True', 'False', '', '', '', '', '', '', '', 'True', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(60, 1, 2, 3, 5, 'multiple', 'The below connector is of which type of printer?', 'True', 'False', '', '', '', '', '', '', '', 'False', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(61, 1, 2, 3, 5, 'multiple', 'Your customer complains that his printer becomes very hot during use, what you will do?', 'True', 'False', '', '', '', '', '', '', '', 'True', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(62, 1, 2, 3, 5, 'multiple', 'Which one the correct port for keyboard?', 'True', 'False', '', '', '', '', '', '', '', 'False', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(63, 1, 2, 3, 5, 'multiple', 'Guidelines:\nAs per company guidelines you should follow the customerâ€™s instruction to select the location of PC installation.  \n\nQuestion:\nAt customerâ€™s house where will you install the computer system?\n', 'customer PC', '', '', '', '', '', '', '', '', 'a', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(64, 1, 2, 3, 5, 'multiple', 'Which software should be installed to the customer PC, asked to design electronic text presentation also include audio and video.', 'electronic text', '', '', '', '', '', '', '', '', 'a', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(65, 1, 2, 3, 5, 'multiple', 'What is the best way to educate customer after installation about hardware, software and operating system', 'operating system', '', '', '', '', '', '', '', '', 'a', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(66, 1, 2, 3, 5, 'multiple', 'You have received a call from customer care department of your company. What will you do?', 'department of your company', '', '', '', '', '', '', '', '', 'a', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(67, 1, 2, 3, 5, 'multiple', 'After receiving a complaint â€œPC not power onâ€, from customer care department, you have call to customer, what will you tell the customer to do?', 'PC not power on', '', '', '', '', '', '', '', '', 'a', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(68, 1, 2, 3, 5, 'multiple', 'In the given table shows the task assigned to you from your supervisor of different customers. The supervisor also instructs that, first you will complete the PC delivery then installation and at last attend the troubleshooting task. In which order you will attend the customer.', ' supervisor', '', '', '', '', '', '', '', '', 'a', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(69, 1, 2, 3, 5, 'multiple', 'Guidelines:\n1. For changing capacitor preheat the soldering iron for 10 min\n2. For changing the diode preheat the soldering iron for 5 min\n3. For changing the resister preheat the soldering iron for 2 min\n\nQuestion:\nAt customer place you are checking the SMPS and found a resister of 5 ohm will need to be replaced. How much time will you preheat the soldering iron.', 'At customer place you are checking the SMPS and found a resister of 5 ohm will need to be replaced. How much time will you preheat the soldering iron.', '', '', '', '', '', '', '', '', 'a', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(70, 1, 2, 3, 5, 'multiple', 'The table showed the warranty details of computer system.\n\n\n\n\n\n\n\n\n\nNote: If the computer system or any of itâ€™s module has been found in physically broken condition, then the warranty has been void. (Consider the present date is 10 June 2016)\n\nQuestion:\nFrom your customer care center, you have received a complaint. Mr. Sharmaâ€™s has problem with his keyboard. He is unable to use some keys. The keyboard has been purchased on 10 April 2016. You visited to Mr. Sharmaâ€™s house and found the keyboard has been broken from one corner. What will you do in this situation?\n\n', 'this situation', '', '', '', '', '', '', '', '', 'a', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(71, 1, 2, 3, 5, 'multiple', 'You received a call from customer care regarding â€œcomputer is automatically shut down after some time during workingâ€. Please select the tools which you will carry with you before moving to customerâ€™s house.', 'customerâ€™s house', '', '', '', '', '', '', '', '', 'a', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(72, 1, 2, 3, 5, 'multiple', 'The table showed the warranty details of computer system.\n\n\n\n\n\n\n\n\nNote: If the computer system or any of itâ€™s module has been found in physically broken condition, then the warranty has been void. (Consider the present date is 01 July 2016)\n\nQuestion:\nFrom your customer care center, you have received a complaint. Mr. Guptaâ€™s having problem with his keyboard which was purchased last week on 25 Jun 2016. After visited to Mr. Guptaâ€™s house you found that some of the keys are not working properly. What will you do in this situation?\n\n', 'you do in this situatio', '', '', '', '', '', '', '', '', 'a', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(73, 1, 2, 3, 5, 'multiple', 'Passage:\n1. For hardware related problem, you should inform to supervisor.\n2. Issued you a non-working part by store executive, you should inform to store in-charge.\n3. For software related problem, you should inform to technical support desk.\n\nQuestion:\nAt customer place you found, the hard disk you carry for replacement at customer site, is not functioning properly. To whom will you inform?', 'a1', 'b1', 'c1', 'd1', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(74, 1, 2, 3, 5, 'multiple', 'During visit to cusstomer\'s home you found the problem in motherboard, which requires soldering of some components.\nYou have not experience of soldering the motherboard. What will you do?', 'a2', 'b2', 'c2', 'd2', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(75, 1, 2, 3, 5, 'multiple', 'Which device not connected directly to USB port?', 'a3', 'b3', 'c3', 'd3', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(76, 1, 2, 3, 5, 'multiple', 'Which of the following is not the function of POST?\n1. Test the BIOS itseif\n2. Discover and test the computer hardware\n3. Test the computer software\n4. Verify Memory\n5. Test the buses\n6. Discover expansion cards', 'a4', 'b4', 'c4', 'd4', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(77, 1, 2, 3, 5, 'multiple', 'Customer is shouting on you, as you reached at his house. Itâ€™s 4th time in this month; he is facing trouble in computer. What will you do?', 'a5', 'b5', 'c5', 'd5', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(78, 1, 2, 3, 5, 'multiple', 'You receive a call from customer care department that Mr. Guptaâ€™s computer is shutdown after some time, what will you do?', 'a6', 'b6', 'c6', 'd6', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(79, 1, 2, 3, 5, 'multiple', 'Which is  used for ESD safe handling.', 'a7', 'b7', 'c7', 'd7', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(80, 1, 2, 3, 5, 'multiple', 'A customer complain that in his dot matrix printer â€œcarriage of the printer is moving, but pages are blankâ€. What order you will check a printer to find the cause of this problem?\n1. Check the ink ribbon to see if it is dry.\n2. Check if the print head is striking the ribbon.\n3. Check if the printer ribbon is being advanced every time the print head returns to its default position.\n4. Check the print head alignment. Do proper adjustment by the help of the lever. It should be nearer to the paper.', 'a8', 'b8', 'c8', 'd8', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(81, 1, 2, 3, 5, 'multiple', 'you reached at customer\'s home at 5:30 PM, Your shift will be till 6:00 pm. If you found the faulty SMPS needs some repairing (soldering) only, which will take 1 Hour. What will you do.', 'a9', 'b9', 'c9', 'd9', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(82, 1, 2, 3, 5, 'multiple', 'From customer care department, you are receiving a call related to â€œPC hanging problemâ€. What will you do?', 'a10', 'b10', 'c10', 'd10', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(83, 1, 2, 3, 5, 'multiple', 'If computer is under warranty with all it\'s components and you found that the RAM will need to change, most appropriately what will you do?', 'a1', 'b1', 'c1', 'd1', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(84, 1, 2, 3, 5, 'multiple', 'Identify the type of RAM shown in below image:', 'a2', 'b2', 'c2', 'd2', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(85, 1, 2, 3, 5, 'multiple', 'Which one is the correct shape and size of the soldering iron tip will you use to solder the component to achieve a good result and high efficiency?', 'a3', 'b3', 'c3', 'd3', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(86, 1, 2, 3, 5, 'multiple', '\"No printout from printer\", whether printer is connected on USB port. what will you do from below?', 'a4', 'b4', 'c4', 'd4', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(87, 1, 2, 3, 5, 'multiple', 'Guidelines\n1. For salary appraisal the call closure should be minimum 90% for hardware calls and 95% for software calls, in single visit\n2. For incentives the Hardware call closure should be minimum 95% in single visit\n3. For appreciation certificate the software call closure should be minimum 95% in single visit\n\nThe table below shows the call closure % of various technicians in single visit.\nQuestion:\nWho will get the salary appraisal?\n', 'a5', 'b5', 'c5', 'd5', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(88, 1, 2, 3, 5, 'multiple', 'Passage:\nGiven below is the material requirement for LAN connectivity of each PC.\nLAN Cable for one PC â€“ 2.5 meter\nLAN card for one PC â€“ 1\nRJ 45 connector for one PC â€“ 2\nCrimping tool â€“ 1\n\nQuestion:\nYou are assigned a task to complete LAN connection of 5 PC, what is your material requirement.\n\n', 'a6', 'b6', 'c6', 'd6', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(89, 1, 2, 3, 5, 'multiple', 'As per you company policy you need to finish 100% work assigned to you per day, but in any case at least 80% work must be finish for the day will be measurable. You assigned below work by your supervisor. \n\n\n\n\n\n\n\n\nWhat is order of work done by you?', 'a7', 'b7', 'c7', 'd7', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(90, 1, 2, 3, 5, 'multiple', 'Guidelines:\n1. If you are late 3 times by 5 min in a month then no deduction in salary.\n2. If you are late more than 3 times by 5 min then half day salary for each late coming will be deducted.\n3. If you are late more than 3 times by more 20 min then full day salary for each late coming will be deducted.\n\nQuestion:\nIf 11th, 16th and 21st of this month you are late by 5 min, then how much salary will be deducted?\n', 'a8', 'b8', 'c8', 'd8', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(91, 1, 2, 3, 5, 'multiple', 'During visit to customer place you found that the electrical point from which supply given to computer is not properly earthed.\nMost appropriately what will you do?', 'a9', 'b9', 'c9', 'd9', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(92, 1, 2, 3, 5, 's', 'Your supervisor points out that your work is not upto the mark and gives a monthly feedback report on the work done by you. What will you do after this?', 'a10', 'b10', 'c10', 'd10', '', '', '', '', '', 'a-p,b-q,c-r,d-s,e-t,f-u,g-v,h-w', '', '', '', '', '', '2019-03-22', '2019-03-22 12:14:44', 1),
(93, 1, 1, 2, 4, 'multiple', 'What should you do on your first visit to the customer?', 'I will greet the customer and ask about the problem he is facing', 'I will show our products', 'I will ask the problem', 'All of these', '', '', '', '', '', 'b', '', '', '', '', 'Animation/movie file', '2019-03-22', '2019-03-22 12:14:44', 1),
(94, 0, 1, 5, 7, '4', 'multiple', 'Find out which of the figures (1), (2), (3) and (4) can be formed from the pieces given in figure (X). ', '1', '2', '3', '4', '', '', '', '', '', '', '', '', '', 'a', '2019-03-27', '2019-03-27 12:11:00', 1),
(95, 0, 1, 5, 7, '4', 'multiple', 'Find out which of the figures (1), (2), (3) and (4) can be formed from the pieces given in figure (X).', '1', '2', '3', '4', '', '', '', '', '', '', '', '', '', 'a', '2019-03-27', '2019-03-27 12:11:00', 1),
(96, 0, 1, 5, 7, '4', 'multiple', 'Find out which of the figures (1), (2), (3) and (4) can be formed from the pieces given in figure (X). ', '1', '2', '3', '4', '', '', '', '', '', '', '', '', '', 'a', '2019-03-27', '2019-03-27 12:11:00', 1),
(97, 0, 1, 5, 7, '4', 'multiple', 'Find out which of the figures (1), (2), (3) and (4) can be formed from the pieces given in figure (X).', '1', '2', '3', '4', '', '', '', '', '', '', '', '', '', 'a', '2019-03-27', '2019-03-27 12:11:00', 1),
(142, 0, 27, 0, 0, 'Non Verbal Reasoning', 'MC', '1', '2', '3', '4', '', '', '', '', '', '', '', '', '', '', '', '2019-03-27', '2019-03-27 15:12:51', 1),
(143, 0, 26, 0, 0, 'Non Verbal Reasoning', 'MC', '1', '2', '3', '4', '', '', '', '', '', '', '', '', '', '', '', '2019-03-27', '2019-03-27 15:12:51', 1),
(144, 0, 27, 0, 0, 'f', 'fgh', 'fgh', 'fghfgh', 'fgh', 'fgh', '', '', '', '', '', '', '', '', '', '', '', '2019-03-27', '2019-03-27 15:12:51', 1),
(145, 0, 27, 45, 27, 'Find out which of the figures (1), (2), (3) and (4', 'Image Analysis', 'Non Verbal Reasoning', 'MC', '1', '2', '3', '', '', '', '', '4', '', '', '', '', '', '2019-03-27', '2019-03-27 15:14:00', 1),
(146, 0, 26, 4, 26, 'Find out which of the figures (1), (2), (3) and (4', 'Image Analysis', 'Non Verbal Reasoning', 'MC', '1', '2', '3', '', '', '', '', '4', '', '', '', '', '', '2019-03-27', '2019-03-27 15:14:00', 1),
(147, 0, 27, 4, 27, '', 'tet', 'f', 'fgh', 'fgh', 'fghfgh', 'fgh', '', '', '', '', 'fgh', '', '', '', '', '', '2019-03-27', '2019-03-27 15:14:00', 1),
(148, 0, 27, 45, 27, 'Find out which of the figures (1), (2), (3) and (4', 'Image Analysis', 'Non Verbal Reasoning', 'MC', '1', '2', '3', '', '', '', '', '4', '', '', '', '', '', '2019-03-27', '2019-03-27 16:12:38', 1),
(149, 0, 26, 4, 26, 'Find out which of the figures (1), (2), (3) and (4', 'Image Analysis', 'Non Verbal Reasoning', 'MC', '1', '2', '3', '', '', '', '', '4', '', '', '', '', '', '2019-03-27', '2019-03-27 16:12:38', 1),
(150, 0, 27, 4, 27, '', 'tet', 'f', 'fgh', 'fgh', 'fghfgh', 'fgh', '', '', '', '', 'fgh', '', '', '', '', '', '2019-03-27', '2019-03-27 16:12:38', 1);

-- --------------------------------------------------------

--
-- Table structure for table `epariksa_questions1`
--

CREATE TABLE `epariksa_questions1` (
  `question_id` int(11) NOT NULL,
  `role_id` int(5) NOT NULL,
  `category_id` int(5) NOT NULL,
  `subject_id` int(5) NOT NULL,
  `topic_id` int(5) NOT NULL,
  `question_type` varchar(50) NOT NULL,
  `question` text NOT NULL,
  `optionA` text NOT NULL,
  `optionB` text NOT NULL,
  `optionC` text NOT NULL,
  `optionD` text NOT NULL,
  `optionE` text NOT NULL,
  `optionP` varchar(250) NOT NULL,
  `optionQ` varchar(250) NOT NULL,
  `optionR` varchar(250) NOT NULL,
  `optionS` varchar(250) NOT NULL,
  `answer` text NOT NULL,
  `answerP` varchar(50) NOT NULL,
  `answerQ` varchar(50) NOT NULL,
  `answerR` varchar(50) NOT NULL,
  `answerS` varchar(50) NOT NULL,
  `solution` text NOT NULL,
  `question_created_date` date NOT NULL,
  `question_modified_date` datetime NOT NULL,
  `question_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `epariksa_questions1`
--

INSERT INTO `epariksa_questions1` (`question_id`, `role_id`, `category_id`, `subject_id`, `topic_id`, `question_type`, `question`, `optionA`, `optionB`, `optionC`, `optionD`, `optionE`, `optionP`, `optionQ`, `optionR`, `optionS`, `answer`, `answerP`, `answerQ`, `answerR`, `answerS`, `solution`, `question_created_date`, `question_modified_date`, `question_active`) VALUES
(1, 1, 1, 1, 4, 'multiple', '<p>During the period of Mahajanapadas, Magadhas most serious Rival was</p>', 'Koshala', 'Avanti', 'Gandhara', 'Anga', '', '', '', '', '', 'A,B', '', '', '', '', '<p>AngaAngaAngaAngaAnga</p>', '2019-03-18', '2019-03-18 12:00:42', 1),
(2, 1, 1, 2, 4, 'choice', '<p><strong>Which of the following served as Capitals of Magadha, the most powerful Mahajanapada?</strong></p>\r\n\r\n<p>1.Rajgir&nbsp; &nbsp; &nbsp;2.Pataliputra&nbsp; &nbsp; &nbsp;3.Taxila&nbsp; &nbsp; &nbsp;4.Ujjain</p>', '1 and 2', '2 and 3', '3 and 4', '4 and 1', '', '', '', '', '', 'C', '', '', '', '', '<p>following served as Capitals of Magadha, the most powerful Mahajanapada</p>', '2019-03-18', '2019-03-18 12:05:05', 1),
(3, 1, 1, 1, 4, 'true', '<p>Who was called ss &quot;Amitragatha&quot; meaning Slayer of Enemies ?</p>\r\n\r\n<p>&nbsp;</p>', '', '', '', '', '', '', '', '', '', 'True', '', '', '', '', '<p>Who was called ss &quot;Amitragatha&quot; meaning Slayer of Enemies Who was called ss &quot;Amitragatha&quot; meaning Slayer of Enemies ?</p>\r\n\r\n<p>&nbsp;</p>', '2019-03-18', '2019-03-18 12:06:03', 1),
(4, 1, 1, 1, 4, 'image-type', '<p><img src=\"image_type_question/girl-512.png\" alt=\"\" width=\"121\" height=\"121\" /></p>', '<p><img src=\"image_type_question/lgo-06-15-17-a-twitter.jpg\" alt=\"\" width=\"83\" height=\"83\" /></p>', '<p>image type 2</p>', '<p>image type 3</p>', '<p>image type 4</p>', '', '', '', '', '', '', '', '', '', '', '', '2019-03-18', '2019-03-18 12:08:08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `epariksa_role`
--

CREATE TABLE `epariksa_role` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(100) NOT NULL,
  `role_created_date` date NOT NULL,
  `role_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `role_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `epariksa_role`
--

INSERT INTO `epariksa_role` (`role_id`, `role_name`, `role_created_date`, `role_modified_date`, `role_active`) VALUES
(1, 'admin', '2018-12-25', '2018-12-25 11:12:03', 1),
(2, 'tutor', '2018-12-25', '2018-12-25 11:12:03', 1),
(3, 'students', '2018-12-25', '2018-12-25 11:12:30', 1);

-- --------------------------------------------------------

--
-- Table structure for table `epariksa_subjects`
--

CREATE TABLE `epariksa_subjects` (
  `subject_id` int(5) NOT NULL,
  `category_id` int(5) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  `subject_description` text NOT NULL,
  `subject_date` date NOT NULL,
  `subject_created_date` date NOT NULL,
  `subject_modified_date` datetime NOT NULL,
  `subject_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `epariksa_subjects`
--

INSERT INTO `epariksa_subjects` (`subject_id`, `category_id`, `subject_name`, `subject_description`, `subject_date`, `subject_created_date`, `subject_modified_date`, `subject_active`) VALUES
(1, 1, 'General Science', '', '2019-03-22', '2019-03-22', '2019-03-22 13:03:59', 1),
(2, 1, 'Current Events', '', '2019-03-22', '2019-03-22', '2019-03-22 13:04:06', 1),
(3, 1, 'Geography', '', '2019-03-22', '2019-03-22', '2019-03-22 13:04:13', 1),
(4, 2, 'Agriculture', '', '2019-03-22', '2019-03-22', '2019-03-22 13:04:58', 1),
(5, 2, 'Botany', '', '2019-03-22', '2019-03-22', '2019-03-22 13:05:09', 1),
(6, 2, 'Physics', '', '2019-03-22', '2019-03-22', '2019-03-22 13:05:24', 1);

-- --------------------------------------------------------

--
-- Table structure for table `epariksa_temp_ans`
--

CREATE TABLE `epariksa_temp_ans` (
  `id` int(12) NOT NULL,
  `login_id` int(12) NOT NULL,
  `test_id` int(12) NOT NULL,
  `question_id` int(12) NOT NULL,
  `question_ans` varchar(250) NOT NULL,
  `question_total_mark` varchar(250) NOT NULL,
  `total_question` varchar(250) NOT NULL,
  `total_time` varchar(23) NOT NULL,
  `skip_question` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `epariksa_temp_ans`
--

INSERT INTO `epariksa_temp_ans` (`id`, `login_id`, `test_id`, `question_id`, `question_ans`, `question_total_mark`, `total_question`, `total_time`, `skip_question`) VALUES
(1, 1, 47, 5, '', '', '', '', '1'),
(2, 1, 47, 9, '', '', '', '', '1'),
(3, 1, 47, 27, '', '', '', '', '1'),
(4, 1, 47, 93, '', '', '', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `epariksa_test_frame`
--

CREATE TABLE `epariksa_test_frame` (
  `test_id` int(11) NOT NULL,
  `test_title` varchar(255) NOT NULL,
  `category_id` varchar(255) NOT NULL,
  `subject_id` varchar(255) NOT NULL,
  `topic_id` varchar(255) NOT NULL,
  `question_id` varchar(255) NOT NULL,
  `no_of_questions` int(11) NOT NULL,
  `total_marks` varchar(255) NOT NULL,
  `test_time` varchar(255) NOT NULL,
  `test_description` text NOT NULL,
  `test_image` varchar(255) NOT NULL,
  `test_type` varchar(255) NOT NULL,
  `test_created_by` varchar(255) NOT NULL,
  `test_created_date` date NOT NULL,
  `test_modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `test_active` tinyint(1) DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `epariksa_test_frame`
--

INSERT INTO `epariksa_test_frame` (`test_id`, `test_title`, `category_id`, `subject_id`, `topic_id`, `question_id`, `no_of_questions`, `total_marks`, `test_time`, `test_description`, `test_image`, `test_type`, `test_created_by`, `test_created_date`, `test_modified_date`, `test_active`) VALUES
(54, 'Test for beginners manual', '1', '2,1,3', '', '', 100, '100', '00:00:10', 'test', 'Test-for-beginners-manual864743198.jpeg', '', '1', '2019-03-26', '2019-03-26 05:29:30', 0),
(53, 'Test for beginners', '1', '2', '', '', 10, '100', '00:00:10', 'test', 'Test-for-beginners1639075980.jpeg', '', '1', '2019-03-26', '2019-03-26 05:28:35', 0),
(52, 'Test', '1', '2,1,3', '', '', 10, '100', '00:00:12', 'ryrtyrty', 'Test1471572415.jpeg', '', '1', '2019-03-23', '2019-03-23 06:32:25', 0),
(51, 'Test batch 1', '1', '2,1,3', '', '', 10, '100', '00:00:10', 'test', 'Test-batch-1189621299.png', '', '1', '2019-03-23', '2019-03-23 04:49:13', 0),
(50, 'Test for beginners', '1,1,1', '2,1', '3,2', '3,5', 10, '100', '1:08', 'test', 'Test-for-beginners1923961413.jpeg', 'manual', '1', '2019-03-22', '2019-03-28 06:18:06', 1),
(49, 'History Questions', '1,1,1', '3,3,1', '3,3,1', '6,7,27', 10, '100', '00:00:07', 'test', 'History-Questions346579072.png', 'manual', '1', '2019-03-22', '2019-03-22 14:39:40', 1),
(48, 'Economy questions', '1,1', '3,3,1', '3,3,1', '6,7', 2, '2', '00:00:07', 'test    \r\n                                                ', 'Economy-questions-1706360929.jpeg', 'random', '1', '2019-03-22', '2019-03-23 11:48:25', 1),
(47, 'Test for beginners', '1,1,1,1', '1,1,1,2', '2,4,1,4', '5,9,27,93', 10, '100', '00:00:07', 'test', 'Test-for-beginners225009474.png', 'manual', '1', '2019-03-22', '2019-03-22 14:01:51', 1),
(55, '1', '1', '2', '', '', 1, '', '00:01', '', '11324252298.jpeg', '', '1', '2019-03-28', '2019-03-28 04:40:01', 0),
(56, 'Test bar', '1', '2,1', '', '', 1, '100', '01:05', '', 'Test-bar390710360.jpeg', '', '1', '2019-03-28', '2019-03-28 06:07:24', 0),
(57, 'Test bar', '1', '2,1,3', '', '', 1, '100', '03:03', '', 'Test-bar437700966.jpeg', '', '1', '2019-03-28', '2019-03-28 07:53:23', 0),
(58, 'Test bar', '1', '2,1,3', '', '', 1, '100', '01:05', '', 'Test-bar705507040.jpeg', '', '1', '2019-03-28', '2019-03-28 09:59:41', 0);

-- --------------------------------------------------------

--
-- Table structure for table `epariksa_test_result`
--

CREATE TABLE `epariksa_test_result` (
  `result_id` int(12) NOT NULL,
  `login_id` int(12) NOT NULL,
  `test_id` int(12) NOT NULL,
  `question_id` varchar(250) NOT NULL,
  `question_ans` varchar(250) NOT NULL,
  `question_skip_id` varchar(250) NOT NULL,
  `question_total` varchar(25) NOT NULL,
  `question_right_ans` varchar(50) NOT NULL,
  `question_wrong_ans` varchar(50) NOT NULL,
  `question_complete_time` varchar(50) NOT NULL,
  `test_created_date` date NOT NULL,
  `test_active` bit(1) NOT NULL DEFAULT b'1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `epariksa_test_result`
--

INSERT INTO `epariksa_test_result` (`result_id`, `login_id`, `test_id`, `question_id`, `question_ans`, `question_skip_id`, `question_total`, `question_right_ans`, `question_wrong_ans`, `question_complete_time`, `test_created_date`, `test_active`) VALUES
(1, 1, 47, '5,5', '0,0', '0,0', '100', '0', '6', '0', '2019-03-27', b'1');

-- --------------------------------------------------------

--
-- Table structure for table `epariksa_topics`
--

CREATE TABLE `epariksa_topics` (
  `topic_id` int(5) NOT NULL,
  `category_id` int(5) NOT NULL,
  `subject_id` int(5) NOT NULL,
  `topic_name` varchar(50) NOT NULL,
  `topic_date` date NOT NULL,
  `topic_created_date` date NOT NULL,
  `topic_modified_date` datetime NOT NULL,
  `topic_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `epariksa_topics`
--

INSERT INTO `epariksa_topics` (`topic_id`, `category_id`, `subject_id`, `topic_name`, `topic_date`, `topic_created_date`, `topic_modified_date`, `topic_active`) VALUES
(1, 1, 1, 'Physics', '2019-03-22', '2019-03-22', '2019-03-22 13:06:11', 1),
(2, 1, 1, 'Chemistry', '2019-03-22', '2019-03-22', '2019-03-22 13:06:19', 1),
(3, 1, 3, 'Botany', '2019-03-22', '2019-03-22', '2019-03-22 13:06:27', 1),
(4, 1, 2, 'History', '2019-03-22', '2019-03-22', '2019-03-22 13:06:42', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `epariksa_batch`
--
ALTER TABLE `epariksa_batch`
  ADD PRIMARY KEY (`batch_id`);

--
-- Indexes for table `epariksa_category`
--
ALTER TABLE `epariksa_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `epariksa_login`
--
ALTER TABLE `epariksa_login`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `epariksa_questions`
--
ALTER TABLE `epariksa_questions`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `epariksa_questions1`
--
ALTER TABLE `epariksa_questions1`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `epariksa_role`
--
ALTER TABLE `epariksa_role`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `epariksa_subjects`
--
ALTER TABLE `epariksa_subjects`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `epariksa_temp_ans`
--
ALTER TABLE `epariksa_temp_ans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `epariksa_test_frame`
--
ALTER TABLE `epariksa_test_frame`
  ADD PRIMARY KEY (`test_id`);

--
-- Indexes for table `epariksa_test_result`
--
ALTER TABLE `epariksa_test_result`
  ADD PRIMARY KEY (`result_id`);

--
-- Indexes for table `epariksa_topics`
--
ALTER TABLE `epariksa_topics`
  ADD PRIMARY KEY (`topic_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `epariksa_batch`
--
ALTER TABLE `epariksa_batch`
  MODIFY `batch_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `epariksa_category`
--
ALTER TABLE `epariksa_category`
  MODIFY `category_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `epariksa_login`
--
ALTER TABLE `epariksa_login`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `epariksa_questions`
--
ALTER TABLE `epariksa_questions`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;

--
-- AUTO_INCREMENT for table `epariksa_questions1`
--
ALTER TABLE `epariksa_questions1`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `epariksa_role`
--
ALTER TABLE `epariksa_role`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `epariksa_subjects`
--
ALTER TABLE `epariksa_subjects`
  MODIFY `subject_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `epariksa_temp_ans`
--
ALTER TABLE `epariksa_temp_ans`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `epariksa_test_frame`
--
ALTER TABLE `epariksa_test_frame`
  MODIFY `test_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `epariksa_test_result`
--
ALTER TABLE `epariksa_test_result`
  MODIFY `result_id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `epariksa_topics`
--
ALTER TABLE `epariksa_topics`
  MODIFY `topic_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
