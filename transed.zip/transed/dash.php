<?php include('epariksa-transed-config.php'); ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Transed</title>

    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="assets/css/fontawesome.rtl.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">

<style type="text/css">

</style>







</head>

<body class="layout-fluid">







    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->
<?php include 'header.php';?>

        <!-- // END Header -->

        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content">

            <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
                <div class="mdk-drawer-layout__content page">

                    <div class="container-fluid page__container">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                        <h1 class="h2">Dashboard</h1>

<div class="row">
    <div class="col-lg-4">
        <div class="card bg-c-blue order-card">
            <div class="card-block">
                <h6 class="m-b-20">No of Students</h6>
                <h2 class="text-right"><i class="sidebar-menu-icon sidebar-menu-icon--left material-icons f-left">account_box</i><span>486</span></h2>
                <p class="m-b-0">No of Students<span class="f-right">351</span></p>
                 <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card bg-c-yellow order-card">
            <div class="card-block">
                <h6 class="m-b-20">No of Candidates</h6>
                <h2 class="text-right"><i class="sidebar-menu-icon sidebar-menu-icon--left material-icons f-left">account_box</i><span>486</span></h2>
                <p class="m-b-0">No of Candidates<span class="f-right">351</span></p>

            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card bg-c-green order-card">
            <div class="card-block">
                <h6 class="m-b-20">No of Test</h6>
                <h2 class="text-right"><i class="sidebar-menu-icon sidebar-menu-icon--left material-icons f-left">import_contacts</i><span>486</span></h2>
                <p class="m-b-0">No of Test<span class="f-right">351</span></p>
            </div>
        </div>
    </div>
    
</div>

   <div class="row">
                            <div class="col-lg-6">
                                <div class="card">
                                    <div class="card-header d-flex align-items-center">
                                        <div class="flex">
                                            <h4 class="card-title">Earnings</h4>
                                            <p class="card-subtitle">Last 7 Days</p>
                                        </div>
                                        <a href="" class="btn btn-sm btn-primary"><i class="material-icons">trending_up</i></a>
                                    </div>
                                    <div class="card-body">
                                        <div class="chart" style="height: 200px;">
                                            <canvas id="earningsChart" class="chart-canvas"></canvas>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header d-flex align-items-center">
                                        <div class="flex">
                                            <h4 class="card-title">Transactions</h4>
                                            <p class="card-subtitle">Latest Transactions</p>
                                        </div>
                                        <a href="" class="btn btn-sm btn-primary"><i class="material-icons">receipt</i></a>
                                    </div>
                                    <div data-toggle="lists" data-lists-values='[
            "js-lists-values-course", 
            "js-lists-values-document",
            "js-lists-values-amount",
            "js-lists-values-date"
          ]' data-lists-sort-by="js-lists-values-date" data-lists-sort-desc="true" class="table-responsive">
                                        <table class="table table-nowrap m-0">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th colspan="2">
                                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-course">Course</a>
                                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-document">Document</a>
                                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-amount">Amount</a>
                                                        <a href="javascript:void(0)" class="sort" data-sort="js-lists-values-date">Date</a>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody class="list">




                                                <tr>
                                                    <td>
                                                        <div class="media align-items-center">
                                                            <a href="" class="avatar avatar-4by3 avatar-sm mr-3">
                                                                <img src="assets/images/vuejs.png" alt="course" class="avatar-img rounded">
                                                            </a>
                                                            <div class="media-body">
                                                                <a class="text-body js-lists-values-course" href=""><strong>Angular Routing In-Depth</strong></a><br>
                                                                <small class="text-muted mr-1">
                                                                    Invoice
                                                                    <a href="" style="color: inherit;" class="js-lists-values-document">#8734</a> -
                                                                    &dollar;<span class="js-lists-values-amount">89</span> USD
                                                                </small>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="text-right">
                                                        <small class="text-muted text-uppercase js-lists-values-date">12 Nov 2018</small>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <div class="media align-items-center">
                                                            <a href="" class="avatar avatar-4by3 avatar-sm mr-3">
                                                                <img src="assets/images/vuejs.png" alt="course" class="avatar-img rounded">
                                                            </a>
                                                            <div class="media-body">
                                                                <a class="text-body js-lists-values-course" href=""><strong>Angular Unit Testing</strong></a><br>
                                                                <small class="text-muted mr-1">
                                                                    Invoice
                                                                    <a href="" style="color: inherit;" class="js-lists-values-document">#8735</a> -
                                                                    &dollar;<span class="js-lists-values-amount">89</span> USD
                                                                </small>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="text-right">
                                                        <small class="text-muted text-uppercase js-lists-values-date">13 Nov 2018</small>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <div class="media align-items-center">
                                                            <a href="" class="avatar avatar-4by3 avatar-sm mr-3">
                                                                <img src="assets/images/github.png" alt="course" class="avatar-img rounded">
                                                            </a>
                                                            <div class="media-body">
                                                                <a class="text-body js-lists-values-course" href=""><strong>Introduction to TypeScript</strong></a><br>
                                                                <small class="text-muted mr-1">
                                                                    Invoice
                                                                    <a href="" style="color: inherit;" class="js-lists-values-document">#8736</a> -
                                                                    &dollar;<span class="js-lists-values-amount">89</span> USD
                                                                </small>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="text-right">
                                                        <small class="text-muted text-uppercase js-lists-values-date">14 Nov 2018</small>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <div class="media align-items-center">
                                                            <a href="]" class="avatar avatar-4by3 avatar-sm mr-3">
                                                                <img src="assets/images/gulp.png" alt="course" class="avatar-img rounded">
                                                            </a>
                                                            <div class="media-body">
                                                                <a class="text-body js-lists-values-course" href=""><strong>Learn Angular Fundamentals</strong></a><br>
                                                                <small class="text-muted mr-1">
                                                                    Invoice
                                                                    <a href="" style="color: inherit;" class="js-lists-values-document">#8737</a> -
                                                                    &dollar;<span class="js-lists-values-amount">89</span> USD
                                                                </small>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="text-right">
                                                        <small class="text-muted text-uppercase js-lists-values-date">15 Nov 2018</small>
                                                    </td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card">
                                    <div class="card-header d-flex align-items-center">
                                        <div class="flex">
                                            <h4 class="card-title">Sales today</h4>
                                            <p class="card-subtitle">by course</p>
                                        </div>
                                        <a class="btn btn-sm btn-primary" href="">Earnings</a>
                                    </div>
                                    <ul class="list-group list-group-fit mb-0">
                                        <li class="list-group-item">
                                            <div class="media align-items-center">
                                                <div class="media-body">
                                                    <a href="" class="text-body"><strong>Basics of HTML</strong></a>
                                                </div>
                                                <div class="media-right">
                                                    <div class="text-center">
                                                        <span class="badge badge-pill badge-primary">15</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="media align-items-center">
                                                <div class="media-body">
                                                    <a href="" class="text-body"><strong>Angular in Steps</strong></a>
                                                </div>
                                                <div class="media-right">
                                                    <div class="text-center">
                                                        <span class="badge badge-pill badge-success">50</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="media align-items-center">
                                                <div class="media-body">
                                                    <a href="" class="text-body"><strong>Bootstrap Foundations</strong></a>
                                                </div>
                                                <div class="media-right">
                                                    <div class="text-center">
                                                        <span class="badge badge-pill badge-warning">14</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            <div class="media align-items-center">
                                                <div class="media-body">
                                                    <a href="" class="text-body"><strong>GitHub Basics</strong></a>
                                                </div>
                                                <div class="media-right">
                                                    <div class="text-center">
                                                        <span class="badge badge-pill  badge-danger ">14</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <div class="card">
                                    <div class="card-header d-flex align-items-center">
                                        <div class="flex">
                                            <h4 class="card-title">Comments</h4>
                                            <p class="card-subtitle">Latest comments</p>
                                        </div>
                                        <div class="text-right" style="min-width: 80px;">
                                            <a href="#" class="btn btn-outline-primary btn-sm"><i class="material-icons">keyboard_arrow_left</i></a>
                                            <a href="#" class="btn btn-outline-primary btn-sm"><i class="material-icons">keyboard_arrow_right</i></a>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="media">
                                            <div class="media-left">
                                                <a href="#" class="avatar avatar-sm">
                                                    <img src="assets/images/people/110/guy-9.jpg" alt="Guy" class="avatar-img rounded-circle">
                                                </a>
                                            </div>
                                            <div class="media-body d-flex flex-column">
                                                <div class="d-flex align-items-center">
                                                    <a href="" class="text-body"><strong>Laza Bogdan</strong></a>
                                                    <small class="ml-auto text-muted">27 min ago</small><br>
                                                </div>
                                                <span class="text-muted">on <a href="" class="text-black-50" style="text-decoration: underline;">Data Visualization With Chart.js</a></span>
                                                <p class="mt-1 mb-0 text-black-70">How can I load Charts on a page?</p>
                                            </div>
                                        </div>
                                        <div class="media ml-sm-32pt mt-3 border rounded p-3 bg-light">
                                            <div class="media-left">
                                                <a href="#" class="avatar avatar-sm">
                                                    <img src="assets/images/people/110/guy-6.jpg" alt="Guy" class="avatar-img rounded-circle">
                                                </a>
                                            </div>
                                            <div class="media-body">
                                                <div class="d-flex align-items-center">
                                                    <a href="" class="text-body"><strong>FrontendMatter</strong></a>
                                                    <small class="ml-auto text-muted">just now</small>
                                                </div>
                                                <p class="mt-1 mb-0 text-black-70">Hi Bogdan,<br> Thank you for purchasing our course! <br><br>Please have a look at the charts library documentation <a href="#">here</a> and follow the instructions.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <form action="#" id="message-reply">
                                            <div class="input-group input-group-merge">
                                                <input type="text" class="form-control form-control-appended" required="" placeholder="Quick Reply">
                                                <div class="input-group-append">
                                                    <div class="input-group-text pr-2">
                                                        <button class="btn btn-flush" type="button"><i class="material-icons">tag_faces</i></button>
                                                    </div>
                                                    <div class="input-group-text pl-0">
                                                        <div class="custom-file custom-file-naked d-flex" style="width: 24px; overflow: hidden;">
                                                            <input type="file" class="custom-file-input" id="customFile">
                                                            <label class="custom-file-label" style="color: inherit;" for="customFile">
                                                                <i class="material-icons">attach_file</i>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="input-group-text pl-0">
                                                        <button class="btn btn-flush" type="button"><i class="material-icons">send</i></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

<?php include 'sidebar.php';?>

            </div>

            <!-- App Settings FAB -->
         <!--    <div id="app-settings">
                <app layout-active="default" :layout-location="{
      'fixed': 'fixed-instructor-dashboard.html',
      'default': 'instructor-dashboard.html'
    }" sidebar-variant="bg-transparent border-0"></app>
            </div> -->

        </div>
    </div>

 <div class="modal fade" id="editQuiz">
        <div class="modal-dialog modal-dialog-centered width-increase">
            <div class="modal-content bg-clr">
                <div class="modal-header bg-primary margin-0">
                    <h4 class="modal-title text-white text-center">Test Exam</h4>
                    <button type="button" class="close text-white close-design" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body ">
                   
                    <form action="#">
                         <div class="card-design">
                       
                        <div class="row design-view">
                            <label for="type" class="col-form-label form-label col-md-4 table-design">Exam for</label>
                           <div class="col-md-8">
                              <p>TNPSC</p>
                            </div>
                        </div>
                        <div class="row design-view">
                            <label for="type" class="col-form-label form-label col-md-4 table-design">Subject</label>
                           <div class="col-md-8">
                              <p>Maths</p>
                            </div>
                        </div>
                        <div class="row design-view">
                            <label class="col-form-label form-label col-md-4 table-design">Topics</label>
                            <div class="col-md-8">
                              <p>Algebra</p>
                            </div>
                        </div>
                        <div class="row design-view">
                            <label for="touch-spin-2" class="col-form-label form-label col-md-4 table-design">No of Questions</label>
                            <div class="col-md-8">
                             <p>100</p>
                            </div>
                        </div>
                        <div class="row design-view">
                            <label for="touch-spin-2" class="col-form-label form-label col-md-4 table-design">No of Mark</label>
                            <div class="col-md-8">
                             <p>100</p>
                            </div>
                        </div>
                        <div class="row design-view">
                            <label for="touch-spin-2" class="col-form-label form-label col-md-4 table-design">Timeframe</label>
                            <div class="col-md-8 card-footer time-schedule border-top-0">
                              <a href="#" class="text-size">   <i class="material-icons text-muted-light">schedule</i> &nbsp;  2 &nbsp; <small class="text-muted">hrs</small> &nbsp; 26 <small class="text-muted"> &nbsp;min</small> </a>
                            </div>
                        </div>
                        </div>
                         <div class="row">
                            <div class="instructions">
                             <div class="col-sm-12">
                                <h4 class="modal-title text-black">Instructions</h4>
                                <ul>

                    <li>Close all programs, including email</li>
                    <li>Click on the Click here to open the exam link provided in the email from The College.</li>
                    <li>Click "Log In For Your Exam Here" at the bottom of the screen.</li>
                    <li>Have your Proctor enter the Username and Password provided in the email from The College and click enter.</li>
                    <li>To begin the exam, click on the link to the appropriate exam listed under Online Assessments.</li>
                </ul>
            </div>
                    </div>
                    </div>
                    <div class="form-group terms">
                                            <div class="custom-control custom-checkbox">
                                                <input class="custom-control-input" type="checkbox" value="" id="invalidCheck01" required="">
                                                <label class="custom-control-label" for="invalidCheck01">
                                                    Agree to terms and conditions
                                                </label>
                                            </div>
                                        </div>
                        <div class="form-group row mb-0 text-center margin-bottom-20">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-success">Start a Test</button>
                            </div>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/dom-factory.js"></script>
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- App Settings (safe to remove) -->
    <script src="assets/js/app-settings.js"></script>






    <!-- Global Settings -->
    <script src="assets/js/settings.js"></script>

    <!-- Moment.js -->
    <script src="assets/vendor/moment.min.js"></script>
    <script src="assets/vendor/moment-range.min.js"></script>

    <!-- Chart.js -->
    <script src="assets/vendor/Chart.min.js"></script>

    <!-- UI Charts Page JS -->
    <script src="assets/js/chartjs-rounded-bar.js"></script>
    <script src="assets/js/chartjs.js"></script>

    <!-- Chart.js Samples -->
    <script>
        (function() {
            'use strict';

            Charts.init()

            var earnings = []

            // Create a date range for the last 7 days
            var start = moment().subtract(7, 'days').format('YYYY-MM-DD') // 7 days ago
            var end = moment().format('YYYY-MM-DD') // today
            var range = moment.range(start, end)

            // Create the earnings graph data
            // Iterate the date range and assign a random ($) earnings value for each day
            range.by('days', function(moment) {
                earnings.push({
                    y: Math.floor(Math.random() * 300) + 10,
                    x: moment.toDate()
                })
            })

            var Earnings = function(id, type = 'roundedBar', options = {}) {
                options = Chart.helpers.merge({
                    barRoundness: 1.2,
                    scales: {
                        yAxes: [{
                            ticks: {
                                callback: function(a) {
                                    if (!(a % 10))
                                        return "$" + a
                                }
                            }
                        }],
                        xAxes: [{
                            offset: true,
                            ticks: {
                                padding: 10
                            },
                            maxBarThickness: 20,
                            gridLines: {
                                display: false
                            },
                            type: 'time',
                            time: {
                                unit: 'day'
                            }
                        }]
                    },
                    tooltips: {
                        callbacks: {
                            label: function(a, e) {
                                var t = e.datasets[a.datasetIndex].label || "",
                                    o = a.yLabel,
                                    r = "";
                                return 1 < e.datasets.length && (r += '<span class="popover-body-label mr-auto">' + t + "</span>"), r += '<span class="popover-body-value">$' + o + "</span>"
                            }
                        }
                    }
                }, options)

                var data = {
                    datasets: [{
                        label: "Earnings",
                        data: earnings
                    }]
                }

                Charts.create(id, type, options, data)
            }

            // Create Chart
            Earnings('#earningsChart')

        })()
    </script>

    <!-- List.js -->
    <script src="assets/vendor/list.min.js"></script>
    <script src="assets/js/list.js"></script>

</body>


</html>