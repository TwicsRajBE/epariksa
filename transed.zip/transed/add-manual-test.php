<?php include('epariksa-transed-config.php'); ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Transed</title>

    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="assets/css/fontawesome.rtl.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">


    <!-- Touchspin -->
    <link rel="stylesheet" href="assets/css/bootstrap-touchspin.css">
    <link rel="stylesheet" href="assets/css/bootstrap-touchspin.rtl.css">

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="assets/css/nestable.css">
    <link rel="stylesheet" href="assets/css/nestable.rtl.css">
    <link rel="stylesheet" href="assets/css/wickedpicker.css">

 <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.css" rel="stylesheet">

</head>
<body class=" layout-fluid">
 <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->

        <?php include 'header.php';?>

        <!-- // END Header -->

        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content">

            <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
                <div class="mdk-drawer-layout__content page">

                    <div class="container-fluid page__container">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                           
                            <li class="breadcrumb-item active">Add Question</li>
                        </ol>
                       <!--  <h1 class="h2">Vue.js Deploy Quiz</h1> -->
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Basic</h4>
                            </div>
                            <div class="card-body">
                                <form action="#">
                                    <div class="form-group row">
                                        <label for="quiz_title" class="col-sm-3 col-form-label form-label">Test Title:</label>
                                        <div class="col-sm-9">
                                            <input id="quiz_title" type="text" class="form-control" placeholder="Title" value=" Introduction">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="course_title" class="col-sm-3 col-form-label form-label">Category:</label>
                                        <div class="col-sm-9 col-md-4">
                                            <select id="course_title" class="custom-select form-control">
                                                <option value="#" selected>HTML</option>
                                                <option value="#">Angular JS</option>
                                                <option value="#" >Vue.js</option>
                                                <option value="#">CSS / LESS</option>
                                                <option value="#">Design / Concept</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                          
                                    <label class="col-sm-3 col-form-label form-label" for="maskSample01">No of Questions</label>
                                    <div class="col-sm-9 col-md-4">
                                    <input id="maskSample01" type="text" class="form-control" placeholder="No: 1" data-mask="#.##0,00" data-mask-reverse="true" autocomplete="off">
                                </div>
                                </div>

                                  <div class="form-group row">
                                          
                                    <label class="col-sm-3 col-form-label form-label" for="maskSample01"> Subject</label>
                                    <div class="col-sm-9 col-md-9">
                  <select class="s2-multiple" class="form-control" multiple="multiple">
                                            <option>Maths</option>
                                           
                                            <option selected="selected">English</option>
                                            <option>Tamil</option>
                                            <option selected="selected">Science</option>
                                        </select>
                                </div>
                                
                                </div>

                                 <div class="form-group row">
                                          
                                    <label class="col-sm-3 col-form-label form-label" for="maskSample01"> Topics</label>
                                    <div class="col-sm-9 col-md-9">
                  <select class="s2-multiple" class="form-control" multiple="multiple">
                                            <option>Grammar</option>
                                           
                                            <option selected="selected">History</option>
                                            <option>probability </option>
                                            <option selected="selected">Chemistry</option>
                                             <option selected="selected">Astronomy</option>
                                        </select>
                                </div>
                                
                                </div>



                                    <div class="form-group row">
                                        <label for="quiz_image" class="col-sm-3 col-form-label form-label">Quiz Image:</label>
                                        <div class="col-sm-9 col-md-4">
                                            <p><img src="assets/images/vuejs.png" alt="" width="150" class="rounded"></p>
                                            <div class="custom-file">
                                                <input type="file" id="quiz_image" class="custom-file-input">
                                                <label for="quiz_image" class="custom-file-label">Choose file</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="cmn-toggle" class="col-sm-3 col-form-label form-label">Timeframe</label>
                                        <div class="col-sm-4">
                                           
                                                <input type="text" id="timepicker-one" name="timepicker-one" class="timepicker form-control"/>
                                           
                                           
                                        </div>
                                    </div>
                                    <div class="form-group row mb-0">
                                        <div class="col-sm-9 offset-sm-3">
                                            <button type="submit" class="btn btn-success">Save</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Questions</h4>
                            </div>
                            <div class="card-header">
                                <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-outline-secondary">Add Question <i class="material-icons">add</i></a>
                            </div>
                            <div class="nestable" id="nestable">
                                <ul class="list-group list-group-fit nestable-list-plain mb-0">
                                    <li class="list-group-item nestable-item">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                            </div>
                                            <div class="media-body">
                                                Installation
                                            </div>
                                            <div class="media-right text-right">
                                                <div style="width:100px">
                                                    <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item nestable-item">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                            </div>
                                            <div class="media-body">
                                                The MVC architectural pattern
                                            </div>
                                            <div class="media-right text-right">
                                                <div style="width:100px">
                                                    <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item nestable-item">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                            </div>
                                            <div class="media-body">
                                                Database Models
                                            </div>
                                            <div class="media-right text-right">
                                                <div style="width:100px">
                                                    <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item nestable-item" data-id="4">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                            </div>
                                            <div class="media-body">
                                                Database Access
                                            </div>
                                            <div class="media-right text-right">
                                                <div style="width:100px">
                                                    <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item nestable-item" data-id="5">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                            </div>
                                            <div class="media-body">
                                                Eloquent Basics
                                            </div>
                                            <div class="media-right text-right">
                                                <div style="width:100px">
                                                    <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item nestable-item" data-id="6">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                            </div>
                                            <div class="media-body">
                                                Take Quiz
                                            </div>
                                            <div class="media-right text-right">
                                                <div style="width:100px">
                                                    <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>




             <?php include 'sidebar.php';?>

            </div>

            <!-- App Settings FAB -->
          

        </div>
    </div>



    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/dom-factory.js"></script>
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- App Settings (safe to remove) -->
    <script src="assets/js/app-settings.js"></script>

     <script src="assets/js/select2.min.js"></script>
      <script src="assets/js/wickedpicker.js"></script>

     <script type="text/javascript">
          var timepickers = $('.timepicker').wickedpicker(); console.log(timepickers.wickedpicker('time', 1));
     </script>



   
  



    <div class="modal fade" id="editQuiz">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <h4 class="modal-title text-white">Edit Question</h4>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="#">
                        <div class="form-group row">
                            <label for="qtitle" class="col-form-label form-label col-md-3">Title:</label>
                            <div class="col-md-9">
                                <input id="qtitle" type="text" class="form-control" value="Database Access">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="type" class="col-form-label form-label col-md-3">Type:</label>
                            <div class="col-md-4">
                                <select id="type" class="custom-control custom-select form-control">
                                    <option value="1">Input</option>
                                    <option value="2">Textarea</option>
                                    <option value="3">Checkbox</option>
                                    <option value="3">Radio</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label form-label col-md-3">Answers:</label>
                            <div class="col-md-9">
                                <a href="#" class="btn btn-default"><i class="material-icons">add</i> Add Answer</a>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="touch-spin-2" class="col-form-label form-label col-md-3">Question Score:</label>
                            <div class="col-md-4">
                                <input id="touch-spin-2" data-toggle="touch-spin" data-min="0" data-max="100" data-step="5" type="text" value="50" name="demo2" class="form-control" />
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-3">
                                <button type="submit" class="btn btn-success">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Vendor JS -->
    <script src="assets/vendor/jquery.nestable.js"></script>
    <script src="assets/vendor/jquery.bootstrap-touchspin.js"></script>

    <!-- Initialize -->
    <script src="assets/js/nestable.js"></script>
    <script src="assets/js/touchspin.js"></script>

     <script type="text/javascript">
                                        document.addEventListener("DOMContentLoaded", function() {
                                            $(".s2-multiple").select2();
                                        });
                                       
                                    </script>

    
</body>

</html>