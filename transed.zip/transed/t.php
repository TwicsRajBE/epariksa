<html lang="en">
<head>
    <title>Change image on select new image from file input</title>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
	<style>
	@charset "utf-8";
/* CSS Document */
body{background:#B6B7BC;font-family:Calibri;}
#main{width:1000px;margin:0 auto;border-radius:10px;background:#FFF;}
#menu{padding:5px;background: #666;}
#menu{color:#CCCCCC}
#header{height:120px;background:#4B6C9F;border-radius:10px 10px 0 0;}
.heading{font-weight:bold;color:#FFF;font-size:2em;padding:30px;}
.title{font-size:2em;color:#3A4E66;margin-bottom:10px;}
#menu a{color:#fff;padding:5px;margin-left:-3px;text-decoration:none}
#menu a:hover{text-decoration:none;background:#8080FF;}
#content{padding:30px;min-height:300px;}
.csv{background: #8080ff; padding: 10px;}
#footer{padding:20px;text-align:center;background:#4B6C9F;color:#FFF;border-radius:0 0 10px 10px}
.button{display:inline-block;text-align:center}
.button{padding:5px 20px; font-size:20px;border-radius:5px;color:#FFF;text-decoration:none;background: #06C; font-weight:bold;}
.button:hover{cursor:pointer;background: #09F;}
.button,.button:hover,#menu{transition:500ms ease-out;-moz-transition:500ms ease-out; -webkit-transition:500ms ease-out;-0-transition:500ms ease-out;}
.small{padding:2px 8px; background: green;font-size:0.8em;width:50px;}
.small:hover{background: #0C0}
.red{background:red; }
.red:hover{background:#C30;  }
.button:active{cursor:pointer;box-shadow:1px 1px 5px #CCC;}
form#form input[type=text],form#form input[type=password],form#form textarea{width:100%}
.clear{clear:both;}
#left,#right{float:left;width:470px;}
#left{margin-right:20px;width:450px;}
form#form div.title{margin-top:10px;}

.choice{border:none;width:500px;}
#form input[type=submit]{width:100%;padding:10px;}
div.question .qtext .title{font-size:1.5em;}
.qtext{background:#e5e5e5;padding:20px; margin-top:5px;margin-bottom:5px; border:1px solid #ccc; border-radius:10px;}
#form .question textarea{font-family:calibri;font-size:16px;padding:5px}
#form .question input[type=text]{padding:3px;}
#form .question textarea,#form .question input[type=text]{border:1px solid #CCC; border-radius:5px;}
#form .question textarea:focus,#form .question input:focus[type=text]{border:1px solid #CCC;box-shadow:0 0 5px #B7D6FB; border-radius:5px;}
#submit{width:500px;}
.rowTitle{background:#C9CDFC;}
table.qlist{text-align:center;border:1px solid #C9CDFC;cursor:default;}
#difficulty{background: #e5e5e5;border:1px solid #ccc;position:relative; padding:5px; margin-top:5px; border-radius:10px;}
#ageGroup{background: #e5e5e5;border:1px solid #ccc; padding:5px; margin-top:5px; border-radius:10px; }
#category{background:#e5e5e5; padding:5px; margin-top:5px;margin-bottom:5px; border:1px solid #ccc; border-radius:10px;}
#answers{border:1px solid #ccc;background:#e5e5e5;padding:5px; margin-top:5px;margin-bottom:5px;border-radius:10px;}

/*************ANSWERING****************/
#timer{float:right;}
.panel{width:200px;min-height:100px;background:#542;display:inline-block;float:left;outline:1px solid green}
#qContainer{min-height:250px;}
.qPanel{display:none;}
.active{display:block;background:#FFF}
.active,.current{transition:1s ease-out; -moz-transition:1s ease-out; -webkit-transition:1s ease-out;-0-transition:1s ease-out;}
#nav{text-align:center;margin:30px;}
a.qButton,a.navbutton{background: none repeat scroll 0 0 #ECEEF5;
    border: 1px solid #CAD4E7;
    border-radius: 5px;
    color: #3B5998;
    font-size: 1em;
    font-weight: 700;
    margin: 0 10px 0 0;
    padding: 5px 10px;
    
    text-decoration: none;}
.hidden{display:none}
a.qButton:hover,a.navbutton:hover{cursor:pointer; border-color: #3B5998;}
a.qButton.current{background:#3B5998;color:#FFF}
.options{padding:10px;}
#txt {
  border:none;
  font-family:verdana;
  font-size:16pt;
  font-weight:bold;
  border-right-color:#FFFFFF;
  width:80px;
}
/*****************Results***********/
div#results{text-align:center}
table#resultstats td{text-align:left;}
div#results{background:#FBFDB3; border-radius:10px; border:1px solid #FF8000;padding:10px;margin:10px;width:500px;margin:10px auto;}
div.score,div.result{font-size:2em;color:blue;margin-bottom:10px;font-weight:bold;text-shadow:1px 1px #555}
div.result{color:blue}
.green{color:#85F420}
#initiallyhide
{
	display:none;
}




/**********Pagination**********/
div.pagination {
	padding: 3px;
	margin: 3px;
}

div.pagination a {
	padding: 2px 5px 2px 5px;
	margin: 2px;
	border: 1px solid #AAAADD;
	
	text-decoration: none; /* no underline */
	color: #000099;
}
div.pagination a:hover, div.pagination a:active {
	border: 1px solid #000099;

	color: #000;
}
div.pagination span.current {
	padding: 2px 5px 2px 5px;
	margin: 2px;
		border: 1px solid #000099;
		
		font-weight: bold;
		background-color: #000099;
		color: #FFF;
	}
	div.pagination span.disabled {
		padding: 2px 5px 2px 5px;
		margin: 2px;
		border: 1px solid #EEE;
	
		color: #DDD;
	}
	
	/**EDIT FOR QUIZQUESTION.php**/
#pagination a{padding:5px;border:1px solid black;cursor:pointer;}
	</style
</head>
<body>

				<form method="post" name="answers" id="answers" action="results.php?quizId=56">
				<div id="qContainer">
					<input type='hidden' value='56' name='quizId'><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1041' name='qid[1]'>
								<b>Q1.</b> Cars7 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[1]' value='0' id='op-1-0' class='hidden' checked>
									<input type='radio' name='op[1]' value='1' id='op-1-1'><label for='op-1-1'> I</label><br>
									<input type='radio' name='op[1]' value='2' id='op-1-2'><label for='op-1-2'> J</label><br>
									<input type='radio' name='op[1]' value='3' id='op-1-3'><label for='op-1-3'> K</label><br>
									<input type='radio' name='op[1]' value='4' id='op-1-4'><label for='op-1-4'> L</label><br>
								</div>
								<div><b>Level:</b> Difficult</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1035' name='qid[2]'>
								<b>Q2.</b> Cars1 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[2]' value='0' id='op-2-0' class='hidden' checked>
									<input type='radio' name='op[2]' value='1' id='op-2-1'><label for='op-2-1'> A</label><br>
									<input type='radio' name='op[2]' value='2' id='op-2-2'><label for='op-2-2'> B</label><br>
									<input type='radio' name='op[2]' value='3' id='op-2-3'><label for='op-2-3'> C</label><br>
									<input type='radio' name='op[2]' value='4' id='op-2-4'><label for='op-2-4'> D</label><br>
								</div>
								<div><b>Level:</b> Easy</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1094' name='qid[3]'>
								<b>Q3.</b> Mercedes10 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[3]' value='0' id='op-3-0' class='hidden' checked>
									<input type='radio' name='op[3]' value='1' id='op-3-1'><label for='op-3-1'>E</label><br>
									<input type='radio' name='op[3]' value='2' id='op-3-2'><label for='op-3-2'> F</label><br>
									<input type='radio' name='op[3]' value='3' id='op-3-3'><label for='op-3-3'> G</label><br>
									<input type='radio' name='op[3]' value='4' id='op-3-4'><label for='op-3-4'> H</label><br>
								</div>
								<div><b>Level:</b> Medium</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1038' name='qid[4]'>
								<b>Q4.</b> Cars4 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[4]' value='0' id='op-4-0' class='hidden' checked>
									<input type='radio' name='op[4]' value='1' id='op-4-1'><label for='op-4-1'> M</label><br>
									<input type='radio' name='op[4]' value='2' id='op-4-2'><label for='op-4-2'> N</label><br>
									<input type='radio' name='op[4]' value='3' id='op-4-3'><label for='op-4-3'> O</label><br>
									<input type='radio' name='op[4]' value='4' id='op-4-4'><label for='op-4-4'> P</label><br>
								</div>
								<div><b>Level:</b> Medium</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1037' name='qid[5]'>
								<b>Q5.</b> Cars3 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[5]' value='0' id='op-5-0' class='hidden' checked>
									<input type='radio' name='op[5]' value='1' id='op-5-1'><label for='op-5-1'> I</label><br>
									<input type='radio' name='op[5]' value='2' id='op-5-2'><label for='op-5-2'> J</label><br>
									<input type='radio' name='op[5]' value='3' id='op-5-3'><label for='op-5-3'> K</label><br>
									<input type='radio' name='op[5]' value='4' id='op-5-4'><label for='op-5-4'> L</label><br>
								</div>
								<div><b>Level:</b> Difficult</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1090' name='qid[6]'>
								<b>Q6.</b> Mercedes6 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[6]' value='0' id='op-6-0' class='hidden' checked>
									<input type='radio' name='op[6]' value='1' id='op-6-1'><label for='op-6-1'> E</label><br>
									<input type='radio' name='op[6]' value='2' id='op-6-2'><label for='op-6-2'> F</label><br>
									<input type='radio' name='op[6]' value='3' id='op-6-3'><label for='op-6-3'> G</label><br>
									<input type='radio' name='op[6]' value='4' id='op-6-4'><label for='op-6-4'> H</label><br>
								</div>
								<div><b>Level:</b> Medium</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1040' name='qid[7]'>
								<b>Q7.</b> Cars6 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[7]' value='0' id='op-7-0' class='hidden' checked>
									<input type='radio' name='op[7]' value='1' id='op-7-1'><label for='op-7-1'> E</label><br>
									<input type='radio' name='op[7]' value='2' id='op-7-2'><label for='op-7-2'> F</label><br>
									<input type='radio' name='op[7]' value='3' id='op-7-3'><label for='op-7-3'> G</label><br>
									<input type='radio' name='op[7]' value='4' id='op-7-4'><label for='op-7-4'> H</label><br>
								</div>
								<div><b>Level:</b> Medium</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1036' name='qid[8]'>
								<b>Q8.</b> Cars2 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[8]' value='0' id='op-8-0' class='hidden' checked>
									<input type='radio' name='op[8]' value='1' id='op-8-1'><label for='op-8-1'> E</label><br>
									<input type='radio' name='op[8]' value='2' id='op-8-2'><label for='op-8-2'> F</label><br>
									<input type='radio' name='op[8]' value='3' id='op-8-3'><label for='op-8-3'> G</label><br>
									<input type='radio' name='op[8]' value='4' id='op-8-4'><label for='op-8-4'> H</label><br>
								</div>
								<div><b>Level:</b> Medium</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1043' name='qid[9]'>
								<b>Q9.</b> Cars9 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[9]' value='0' id='op-9-0' class='hidden' checked>
									<input type='radio' name='op[9]' value='1' id='op-9-1'><label for='op-9-1'> A</label><br>
									<input type='radio' name='op[9]' value='2' id='op-9-2'><label for='op-9-2'> B</label><br>
									<input type='radio' name='op[9]' value='3' id='op-9-3'><label for='op-9-3'> C</label><br>
									<input type='radio' name='op[9]' value='4' id='op-9-4'><label for='op-9-4'> D</label><br>
								</div>
								<div><b>Level:</b> Easy</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1085' name='qid[10]'>
								<b>Q10.</b> Mercedes1 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[10]' value='0' id='op-10-0' class='hidden' checked>
									<input type='radio' name='op[10]' value='1' id='op-10-1'><label for='op-10-1'> A</label><br>
									<input type='radio' name='op[10]' value='2' id='op-10-2'><label for='op-10-2'> B</label><br>
									<input type='radio' name='op[10]' value='3' id='op-10-3'><label for='op-10-3'> C</label><br>
									<input type='radio' name='op[10]' value='4' id='op-10-4'><label for='op-10-4'> D</label><br>
								</div>
								<div><b>Level:</b> Easy</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1088' name='qid[11]'>
								<b>Q11.</b> Mercedes4 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[11]' value='0' id='op-11-0' class='hidden' checked>
									<input type='radio' name='op[11]' value='1' id='op-11-1'><label for='op-11-1'> M</label><br>
									<input type='radio' name='op[11]' value='2' id='op-11-2'><label for='op-11-2'> N</label><br>
									<input type='radio' name='op[11]' value='3' id='op-11-3'><label for='op-11-3'> O</label><br>
									<input type='radio' name='op[11]' value='4' id='op-11-4'><label for='op-11-4'> P</label><br>
								</div>
								<div><b>Level:</b> Medium</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1044' name='qid[12]'>
								<b>Q12.</b> Cars10 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[12]' value='0' id='op-12-0' class='hidden' checked>
									<input type='radio' name='op[12]' value='1' id='op-12-1'><label for='op-12-1'>E</label><br>
									<input type='radio' name='op[12]' value='2' id='op-12-2'><label for='op-12-2'> F</label><br>
									<input type='radio' name='op[12]' value='3' id='op-12-3'><label for='op-12-3'> G</label><br>
									<input type='radio' name='op[12]' value='4' id='op-12-4'><label for='op-12-4'> H</label><br>
								</div>
								<div><b>Level:</b> Medium</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1087' name='qid[13]'>
								<b>Q13.</b> Mercedes3 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[13]' value='0' id='op-13-0' class='hidden' checked>
									<input type='radio' name='op[13]' value='1' id='op-13-1'><label for='op-13-1'> I</label><br>
									<input type='radio' name='op[13]' value='2' id='op-13-2'><label for='op-13-2'> J</label><br>
									<input type='radio' name='op[13]' value='3' id='op-13-3'><label for='op-13-3'> K</label><br>
									<input type='radio' name='op[13]' value='4' id='op-13-4'><label for='op-13-4'> L</label><br>
								</div>
								<div><b>Level:</b> Difficult</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1093' name='qid[14]'>
								<b>Q14.</b> Mercedes9 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[14]' value='0' id='op-14-0' class='hidden' checked>
									<input type='radio' name='op[14]' value='1' id='op-14-1'><label for='op-14-1'> A</label><br>
									<input type='radio' name='op[14]' value='2' id='op-14-2'><label for='op-14-2'> B</label><br>
									<input type='radio' name='op[14]' value='3' id='op-14-3'><label for='op-14-3'> C</label><br>
									<input type='radio' name='op[14]' value='4' id='op-14-4'><label for='op-14-4'> D</label><br>
								</div>
								<div><b>Level:</b> Easy</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1091' name='qid[15]'>
								<b>Q15.</b> Mercedes7 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[15]' value='0' id='op-15-0' class='hidden' checked>
									<input type='radio' name='op[15]' value='1' id='op-15-1'><label for='op-15-1'> I</label><br>
									<input type='radio' name='op[15]' value='2' id='op-15-2'><label for='op-15-2'> J</label><br>
									<input type='radio' name='op[15]' value='3' id='op-15-3'><label for='op-15-3'> K</label><br>
									<input type='radio' name='op[15]' value='4' id='op-15-4'><label for='op-15-4'> L</label><br>
								</div>
								<div><b>Level:</b> Difficult</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1039' name='qid[16]'>
								<b>Q16.</b> Cars5 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[16]' value='0' id='op-16-0' class='hidden' checked>
									<input type='radio' name='op[16]' value='1' id='op-16-1'><label for='op-16-1'> A</label><br>
									<input type='radio' name='op[16]' value='2' id='op-16-2'><label for='op-16-2'> B</label><br>
									<input type='radio' name='op[16]' value='3' id='op-16-3'><label for='op-16-3'> C</label><br>
									<input type='radio' name='op[16]' value='4' id='op-16-4'><label for='op-16-4'> D</label><br>
								</div>
								<div><b>Level:</b> Easy</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1089' name='qid[17]'>
								<b>Q17.</b> Mercedes5 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[17]' value='0' id='op-17-0' class='hidden' checked>
									<input type='radio' name='op[17]' value='1' id='op-17-1'><label for='op-17-1'> A</label><br>
									<input type='radio' name='op[17]' value='2' id='op-17-2'><label for='op-17-2'> B</label><br>
									<input type='radio' name='op[17]' value='3' id='op-17-3'><label for='op-17-3'> C</label><br>
									<input type='radio' name='op[17]' value='4' id='op-17-4'><label for='op-17-4'> D</label><br>
								</div>
								<div><b>Level:</b> Easy</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1086' name='qid[18]'>
								<b>Q18.</b> Mercedes2 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[18]' value='0' id='op-18-0' class='hidden' checked>
									<input type='radio' name='op[18]' value='1' id='op-18-1'><label for='op-18-1'> E</label><br>
									<input type='radio' name='op[18]' value='2' id='op-18-2'><label for='op-18-2'> F</label><br>
									<input type='radio' name='op[18]' value='3' id='op-18-3'><label for='op-18-3'> G</label><br>
									<input type='radio' name='op[18]' value='4' id='op-18-4'><label for='op-18-4'> H</label><br>
								</div>
								<div><b>Level:</b> Medium</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1092' name='qid[19]'>
								<b>Q19.</b> Mercedes8 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[19]' value='0' id='op-19-0' class='hidden' checked>
									<input type='radio' name='op[19]' value='1' id='op-19-1'><label for='op-19-1'> M</label><br>
									<input type='radio' name='op[19]' value='2' id='op-19-2'><label for='op-19-2'> N</label><br>
									<input type='radio' name='op[19]' value='3' id='op-19-3'><label for='op-19-3'> O</label><br>
									<input type='radio' name='op[19]' value='4' id='op-19-4'><label for='op-19-4'> P</label><br>
								</div>
								<div><b>Level:</b> Medium</div>
							</div><div class='qPanel'>
								<input type='hidden'>
								<div class='qText'>
								<input type='hidden' value='1042' name='qid[20]'>
								<b>Q20.</b> Cars8 <br>
								
								</div>
								
								<div class='options'>
									<input type='radio' name='op[20]' value='0' id='op-20-0' class='hidden' checked>
									<input type='radio' name='op[20]' value='1' id='op-20-1'><label for='op-20-1'> M</label><br>
									<input type='radio' name='op[20]' value='2' id='op-20-2'><label for='op-20-2'> N</label><br>
									<input type='radio' name='op[20]' value='3' id='op-20-3'><label for='op-20-3'> O</label><br>
									<input type='radio' name='op[20]' value='4' id='op-20-4'><label for='op-20-4'> P</label><br>
								</div>
								<div><b>Level:</b> Medium</div>
							</div>					
				</div>
				<div id='nav'><a class='navbutton' onclick='nav(-1)'>&laquo; Previous Question</a> <a class='navbutton' onclick='nav(1)'>Next Question &raquo;</a><br /><br /><br /><br /><a class='qButton' onclick='show(0)'>1</a><a class='qButton' onclick='show(1)'>2</a><a class='qButton' onclick='show(2)'>3</a><a class='qButton' onclick='show(3)'>4</a><a class='qButton' onclick='show(4)'>5</a><a class='qButton' onclick='show(5)'>6</a><a class='qButton' onclick='show(6)'>7</a><a class='qButton' onclick='show(7)'>8</a><a class='qButton' onclick='show(8)'>9</a><a class='qButton' onclick='show(9)'>10</a></div>				

                    <center><input class="button" type="submit" value="Submit Answers" name="submit1"/></center>
				</form>










<input type="file" name="file" id="profile-img">
<img src="twics-1935503585.jpg" id="profile-img-tag" width="200px" />


<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#profile-img-tag').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#profile-img").change(function(){
        readURL(this);
    });
	
	
	
	
	
	
	var mins
var secs;

function cd() {
 	mins = 1 * m("2"); // change minutes here
 	secs = 0 + s(":52"); // change seconds here (always add an additional second to your total)
 	redo();
}

function m(obj) {
 	for(var i = 0; i < obj.length; i++) {
  		if(obj.substring(i, i + 1) =