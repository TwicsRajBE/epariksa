<?php include('epariksa-transed-config.php');
$a =='';
if(isset($_POST['register_submit'])) {
        
            $role_id            = 3;         
           $username            = trim($_POST['username']);         
           $email               = trim($_POST['email']);
           $password            = trim($_POST['password']);
           $mobile_number       = trim($_POST['mobile_number']); 
           $user_image          = trim($_POST['user_image']);
           $batch_id          = trim($_POST['batch_id']);
           // $category_id         = trim(implode(',',$_POST['category_id']));  
           // $subject_id          = trim(implode(',',$_POST['subject_id']));  
           $created_by          = 'Admin';           
           $login_created_date  = date('Y-m-d');
           $login_modified_date = date('Y-m-d H:i:s');
           $login_active          = 1;  
        
 
            // eliminate all special characters
            $res = preg_replace("/[^a-zA-Z0-9\s]/", "", $username);
            // To remove multiple white space into one single space
            $output = preg_replace('!\s+!', ' ', $res);
            // Change white space into (-)
            $user_image_name = str_replace(' ', '-', $output);
    
                $name                            = ''; $type = ''; $size = ''; $error = '';
                function compress_image($source_url, $destination_url, $quality) {
                $info                            = getimagesize($source_url);
                if ($info['mime']                == 'image/jpeg')
                $image                           = imagecreatefromjpeg($source_url);
                elseif ($info['mime']            == 'image/gif')
                $image                           = imagecreatefromgif($source_url);
                elseif ($info['mime']            == 'image/png')
                $image                           = imagecreatefrompng($source_url);
                imagejpeg($image, $destination_url, $quality);
                return $destination_url;
                }
                if($_FILES["user_image"]["name"] != '') {
                $file_ext                        = strtolower(end(explode('.', $_FILES["user_image"]["name"])));
              echo  $user_image                      = $user_image_name.rand().'.'.$file_ext;
                compress_image($_FILES["user_image"]["tmp_name"], "user/profile/".$user_image, 80);
                }
       
       // print_r($_POST);

       // echo $_FILES["user_image"]["name"];
      

       // print_r($_FILES);
       
       

 $insertstudent = $mysqli->query("INSERT INTO epariksa_login(role_id, username, email, password, mobile_number, user_image, batch_id, created_by, login_created_date, login_modified_date, login_active) VALUES ('$role_id','$username','$email','$password','$mobile_number','$user_image','$batch_id','$created_by','$login_created_date','$login_modified_date','$login_active')");


 if($insertstudent == true) {
        $response["success"] = "1";
        $a = json_encode($response);
      }
}
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Transed</title>

    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="assets/css/fontawesome.rtl.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">
    <link href="assets/css/toastr.min.css" rel="stylesheet">
 <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.css" rel="stylesheet">


</head>

<body class=" layout-fluid">







    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->

      <?php include 'header.php';?>

        <!-- // END Header -->

        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content">

            <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
                <div class="mdk-drawer-layout__content page">

                    <div class="container-fluid page__container">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>

                            <li class="breadcrumb-item">Student</li>
                              <li class="breadcrumb-item active">Add Student</li>
                        </ol>
                        <h1 class="h2">Add Student</h1>

                        <div class="card">
                            
                            <div class="tab-content card-body">
                                <div class="tab-pane active" id="first">
                                    <form action="add-student.php" method="POST" class="form-horizontal" enctype="multipart/form-data" onsubmit="return addstudvalidation()">
                                        <div class="form-group row">
                                            <label for="avatar" class="col-sm-3 col-form-label form-label">Upload Image</label>
                                            <div class="col-sm-9">
                                              <div class="media align-items-center">
                                                    <div class="media-left">
                                                        <div class="icon-block rounded">
                                                          <img src="" id="profile-img-tag" width="90px" />
                                                        </div>
                                                    </div>
                                                    <div class="media-body">
                                                        <div class="custom-file" style="width: auto;">
                                                             <input type="file" id="profile-img" name="user_image" class="custom-file-input" onclick="hideErrorimage();"> 

                                                            <label for="avatar" class="custom-file-label">Choose file</label>

                                                        </div>
														<p style="color: red;" id="add_image" ></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                          <div class="form-group row">
                                                <label for="password" class="col-sm-3 col-form-label form-label"> Name</label>
                                            <div class="col-sm-6 col-md-6">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="material-icons md-18 text-muted">lock</i>
                                                        </div>
                                                    </div>
                                                    <input type="text" id="username"  name="username" class="form-control" placeholder="Enter Name" onkeyup="hideErrorname();">
                                                </div>
												<p style="color: red;" id="add_name" ></p>
                                            </div>
                                        </div>



                                        <div class="form-group row">
                                            <label for="email" class="col-sm-3 col-form-label form-label">Email</label>
                                            <div class="col-sm-6 col-md-6">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="material-icons md-18 text-muted">mail</i>
                                                        </div>
                                                    </div>
                                                    <input type="text" id="email" name="email" class="form-control" placeholder="Email Address"  onkeyup="hideErroremail();">
                                                </div>
												<p style="color: red;" id="add_email" ></p>
                                            </div>
                                        </div>
                                      
                                        <div class="form-group row">
                                            <label for="password" class="col-sm-3 col-form-label form-label"> Password</label>
                                            <div class="col-sm-6 col-md-6">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="material-icons md-18 text-muted">lock</i>
                                                        </div>
                                                    </div>
                                                    <input type="password" id="password" name="password" class="form-control" placeholder="Enter new password" onkeyup="hideErrorpassword();">
                                                </div>
												<p style="color: red;" id="add_pwd" ></p>
                                            </div>
                                        </div>
                                          <div class="form-group row">
                                            <label for="website" class="col-sm-3 col-form-label form-label">Mobile Number</label>
                                            <div class="col-sm-6 col-md-6">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="material-icons md-18 text-muted">phone_android</i>
                                                        </div>
                                                    </div>
                                                    <input type="text" id="mobile_number" name="mobile_number" class="form-control" placeholder="9842724295" value="" onkeyup="hideErrormobile();" maxlength="10">
                                                </div>
												<p style="color: red;" id="add_mobile" ></p>
                                            </div>
                                        </div>



                                <div class="form-group row">
                                          
                                    <label class="col-sm-3 col-form-label form-label" for="maskSample01"> Batch</label>
                                    <div class="col-sm-6 col-md-6">
                  <select class="form-control" id="batch_id" name="batch_id" onclick="hideErrorbatch();">
                    <option value="">Select Batch</option>
                                           <?php 
                    $select_batch = $mysqli->query("SELECT * FROM epariksa_batch WHERE batch_active=1");
                    while($batch_row = mysqli_fetch_array($select_batch)) {
                    $batch_id       = $batch_row['batch_id'];
                    $batch_name      = $batch_row['batch_name']; ?>
                    <option value="<?php echo $batch_id; ?>"><?php echo $batch_name; ?></option>
                    <?php } ?>
                                        </select>
										 <p style="color: red;" id="add_batch" ></p>
                                </div>
                                
                                </div>



                                        
                                        <div class="form-group row">
                                            <div class="col-sm-8 offset-sm-3">
                                                <div class="media align-items-center">
                                                    <div class="media-left">
                                                        <button type="submit" id="register_submit" name="register_submit" class="btn btn-success">Save Changes</button>
                                                    </div>
                                                   <!--  <div class="media-body pl-1">
                                                        <div class="custom-control custom-checkbox">
                                                            <input id="subscribe" type="checkbox" class="custom-control-input" checked>
                                                            <label for="subscribe" class="custom-control-label">Subscribe to Newsletter</label>
                                                        </div>
                                                    </div> -->
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                            
                            </div>
                        </div>
                    </div>

                </div>




                     <?php include 'sidebar.php';?>

            </div>

          

        </div>
    </div>



    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/dom-factory.js"></script>
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- App Settings (safe to remove) -->
    <script src="assets/js/app-settings.js"></script>
<script src="assets/js/select2.min.js"></script>
<!--  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script> -->





<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#profile-img-tag').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#profile-img").change(function(){
        readURL(this);
    });
</script>

     <script type="text/javascript">
document.addEventListener("DOMContentLoaded", function() {
    $(".s2-multiple").select2();
});

</script>
<script type="text/javascript">
 
function hideErrorimage(){
		 document.getElementById("add_image").innerHTML= " ";
		}
function hideErrorname(){
		 document.getElementById("add_name").innerHTML= " ";
		}
function hideErroremail(){
		 document.getElementById("add_email").innerHTML= " ";
		}
function hideErrorpassword(){
		 document.getElementById("add_pwd").innerHTML= " ";
		}
function hideErrormobile(){
		 document.getElementById("add_mobile").innerHTML= " ";
		}
function hideErrorbatch(){
		 document.getElementById("add_batch").innerHTML= " ";
		}		
function addstudvalidation()
			{
				
 var stud_image = document.getElementById('profile-img');					
   var fileName = stud_image.value;
				  var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
				  
				  
				 //empty
                 if(fileName == "") {
				
                        document.getElementById("add_image").innerHTML= "Please Upload the Image..!";
                        stud_image.focus();
			        return false;		
				
                        }
                  
				
				//format
				
					if(ext == "PNG" || ext == "png" || ext == "JPEG" || ext == "jpeg" || ext == "jpg" || ext == "JPG")
					{
				
					} 
					else
					{
					document.getElementById("add_image").innerHTML= "Please Upload Png or Jpg images only..!";
					stud_image.focus();
					return false;
					}	
var stud_name = document.getElementById("username").value;
                    if(stud_name == "")
					{
                            document.getElementById("add_name").innerHTML="Please Enter Name..!";
                            document.getElementById("username").focus();
							return false;
                                
                    }
if (!/^[a-zA-Z0-9-_]+$/.test(stud_name)) 
				    {
								document.getElementById("add_name").innerHTML= "Please Use Alphanumeric Value...!";
								document.getElementById("username").focus();
								return false;
					} 
var stud_email = document.getElementById("email").value;
                    if(stud_email == "")
					{
                            document.getElementById("add_email").innerHTML="Please Enter Email address...!";
                            document.getElementById("email").focus();
							return false;
                                
                    }
 var atposition=stud_email.indexOf("@");  
					var dotposition=stud_email.lastIndexOf(".");  
					if (atposition<1 || dotposition<atposition+2 || dotposition+2>=stud_email.length)
					{  
				   document.getElementById("add_email").innerHTML = "Invalid E-mail Address...!";
                   document.getElementById("email").focus();
					//alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
					return false;  
					  }  					
  if (stud_email.length > 0) 
					{
                    if (!/^([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,63})$/.test(stud_email)) 
				    {
                        document.getElementById("add_email").innerHTML = "Invalid E-mail Address...!";
                        document.getElementById("email").focus();
						return false;

                    }
					                        
					}					
var stud_pwd = document.getElementById("password").value;
                    if(stud_pwd == "")
					{
                            document.getElementById("add_pwd").innerHTML="Please Enter Password...!";
                            document.getElementById("password").focus();
							return false;
                                
                    }	
var stud_mobile = document.getElementById("mobile_number").value;
                    if(stud_mobile == "")
					{
                            document.getElementById("add_mobile").innerHTML="Please Enter Mobile Number...!";
                            document.getElementById("mobile_number").focus();
							return false;
                                
                    }
					 if(isNaN(stud_mobile)) {
								document.getElementById("add_mobile").innerHTML="Mobile Number must be only in numbers...!";
								document.getElementById("mobile_number").focus();
								return false;
                    			}
                   		 if(stud_mobile.length< 10) {
								document.getElementById("add_mobile").innerHTML="Mobile Number must be minimum of 10 digits...!";
								document.getElementById("mobile_number").focus();
								return false;
                    			}
                    	if(stud_mobile.length> 10) {
								document.getElementById("add_mobile").innerHTML="Mobile Number must be maximum of 10 digits...!";
								document.getElementById("mobile_number").focus();
								return false; 
                   			 }
					
var stud_batch = document.getElementById("batch_id").value;
                    if(stud_batch == "")
					{
                            document.getElementById("add_batch").innerHTML="Please Select the Batch...!";
                            document.getElementById("batch_id").focus();
							return false;
                                
                    }
return true;					
			}
</script>




<script type="text/javascript" src="assets/js/toastr.min.js"></script>
<script>

var a = '<?php echo  $a ;?>';
var obj = JSON.parse(a);
if (obj.success == 1){
toastr.success('Success', 'Student Added Successfully..')
setTimeout(function(){  window.location.href = "add-student.php" }, 1000);
}
</script>

</body>


</html>