<?php include('epariksa-transed-config.php'); 

if(isset($_POST["search_submit"])) {


    if(isset($_POST['category_id']) && $_POST['category_id'] != ''){
        $category    = $_POST['category_id'];
        $category_id     = trim($category);

      }


    if(isset($_POST['test_title']) && $_POST['test_title'] != ''){
        $test_title    = $_POST['test_title'];
        $testtitle     = trim($test_title);

      }


   $wherecondition = "SELECT * FROM epariksa_test_frame WHERE";
    

  if(!empty($category) && !is_null($category) && $category !== '')
    {
    
            if($category > 0){
                   $wherecondition .= " (category_id = $category_id";
                        }
            $wherecondition .= ")";
    } 




     if(!empty($test_title) && !is_null($test_title) && $test_title != '')

    {
      if((!empty($category)) && !empty($test_title)){

            $wherecondition .= " AND ";
        }
            if($test_title !=''){
                  $wherecondition .= "(test_title LIKE '$test_title'";
                        }
            $wherecondition .= ")";
    } 




   $select_test_frame = $mysqli->query($wherecondition .= "  AND test_active=1 order by test_created_date DESC");
  
   $count_test_frame = mysqli_num_rows($select_test_frame);



}

else{
    $select_test_frame = $mysqli->query("SELECT * FROM epariksa_test_frame WHERE test_active=1");
     $count_test_frame = mysqli_num_rows($select_test_frame);

}
  
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Transed</title>

    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="assets/css/fontawesome.rtl.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">
       <link rel="stylesheet" href="assets/css/datatable/jquery.dataTables.min.css" crossorigin="anonymous">

  <link rel="stylesheet" href="assets/css/datatable/rowReorder.dataTables.min.css">

<link rel="stylesheet" type="text/css" href="assets/css/datatable/responsive.dataTables.min.css">

<link rel="stylesheet" href="//code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css">
<style type="text/css">
    
nav > .nav.nav-tabs{

  border: none !important;
    color:#fff;
    background:#272e38;
    border-radius:0;

}
nav > div a.nav-item.nav-link {
    border: none !important;
    padding: 10px 22px;
    color: #333 !important;
    background: #f7f7f7 !important;
    border-radius: 0 !important;
    font-size: 18px;
}

nav > div a.nav-item.nav-link.active:after {
    content: "";
    position: relative;
    bottom: -50px;
    left: -10%;
    border: 15px solid transparent;
    border-top-color: #333;
}
.tab-content {
    background: #fdfdfd;
    line-height: 25px;
    border: 1px solid #ddd;
   /* border-top: 5px solid #064577;
    border-bottom: 5px solid #064577;*/
    padding: 30px 25px;
}

nav > div a.nav-item.nav-link:hover, nav > div a.nav-item.nav-link:focus, a.nav-item.nav-link.active {
    border: none !important;
    background: #e0e2e3 !important;
    color: #333!important;
    border-radius: 0;
    transition: background 0.20s linear;
}
.nav-fill .nav-item {
    -ms-flex: 1 1 auto !important;
    flex: 1 1 auto !important;
    text-align: center !important;
    display: initial;
}
div#nav-tabContent {
    padding: 30px 25px !important;
}
</style>

</head>

<body class=" layout-fluid">

    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->
<?php include 'header.php';?>
        <!-- // END Header -->
<!-- Header Layout Content -->
<div class="mdk-header-layout__content">
    <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
        <div class="mdk-drawer-layout__content page">
            <div class="container-fluid page__container">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                    <!-- <li class="breadcrumb-item">Student</li> -->
                    <li class="breadcrumb-item active">View Batches</li>
                </ol>





                    <div class="d-flex flex-column flex-sm-row flex-wrap mb-headings align-items-start align-items-sm-center">
                        <div class="flex mb-2 mb-sm-0">
                            <h1 class="h2">View Batches</h1>
                        </div>
                      
                    </div>

                    

                 <!--    <div class="alert alert-light alert-dismissible border-1 border-left-3 border-left-warning" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <div class="text-black-70">Ohh no! No courses to display. Add some courses.</div>
                    </div>
 -->
                    <div class="row">

                         <div class="col-xs-12" style="width: 100%;">
                  <nav>
                    <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                      <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Student List</a>
                      <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">List of the test frame</a>
                     
                    </div>
                  </nav>
                  <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                       <div class="table-responsive border-bottom" data-toggle="lists" data-lists-values='["js-lists-values-employee-name"]'>

                                           <!-- <div class="search-form search-form--light mb-3">
                                                <input type="text" class="form-control search" placeholder="Search">
                                                <button class="btn" type="button" role="button"><i class="material-icons">search</i></button>
                                            </div>-->
                                            <table id="example" class="display nowrap" style="width:100%">
                                                <thead>
                                                <?php $i=1; ?>
                                                    <th>S.no</th>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Mobile Number</th>
                                                   
                                                </thead>
                                                    <tbody>
                                                     <?php                                 
$students = $mysqli->query("SELECT * FROM epariksa_login WHERE login_active=1  AND role_id=3");
while($students_row = mysqli_fetch_array($students)) {
    
$username    = $students_row['username'];  
$email    = $students_row['email'];  
$mobile_number    = $students_row['mobile_number'];  

?> 
                                                        <tr>
                                                            <td> <span class="js-lists-values-employee-name"><?php echo $i; ?></span></td>
                                                            <td> <span class="js-lists-values-employee-name"><?php echo $username; ?></span></td>
                                                            <td> <span class="js-lists-values-employee-name"><?php echo $email; ?></span></td>
                                                            <td> <span class="js-lists-values-employee-name"><?php echo $mobile_number; ?></span></td>
                                                            
                                                        </tr>
                                                         <?php $i++;} ?>
                                                         
                                                    </tbody>
    <tfoot>
        <tr>
             <th>S.no</th>
             <th>Name</th>
            <th>Email</th>
            <th>Mobile Number</th>
           
        </tr>
    </tfoot>
</table>




                                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                      <div class="d-flex flex-column flex-sm-row flex-wrap mb-headings align-items-start align-items-sm-center">
                        <div class="flex mb-2 mb-sm-0">
                            <h1 class="h2">Search Test</h1>
                           
                        </div>
                      
                    </div>
                    <?php if($_SESSION['role_id'] != '3') {?>
                         <div class="card card-body border-left-3 border-left-primary navbar-shadow mb-4">
                        <form action="view-test-frame.php" name="test" method="POST" enctype="multipart/form-data">
                         <div class=" row">
                                <div class="col-sm-9 col-md-4">
                                  <select id="category" name= "category_id" class="form-control">
                                    <option value="">Search by Category</option>
                                    <?php 
                                      $select_maincategory = $mysqli->query("SELECT * FROM epariksa_category WHERE category_active=1");
                                      while($maincategoryRow = mysqli_fetch_array($select_maincategory)) {
                                      $category_id       = $maincategoryRow['category_id'];
                                      $category_name      = $maincategoryRow['category_name']; ?>
                                    <option value="<?php echo $category_id; ?>"><?php echo $category_name; ?></option>
                                    <?php } ?>
                                  </select>
                                  </div>
                                      <?php
                                        $j=0;
                                        $test_frame =  $mysqli->query("SELECT * FROM epariksa_test_frame WHERE test_active=1");
                                        while($selecttest = mysqli_fetch_array($test_frame)){
                                          $test_titles[$j] = '"'.$selecttest['test_title'].'"';
                                          $j++;
                                        }
                                        $arraytitle = implode(',',$test_titles);
                                        ?>
                                            <div class="col-sm-9 col-md-6">
                                              <input type="text" id="test_title" name="test_title" class="form-control" placeholder="Search by Test Title">
                                                      </div>
                                          <div class="col-sm-9 col-md-2">
                                            <input type="submit" class="btn btn-success" id="search_submit" name="search_submit">
                                          </div>
                                      </div>
                                    </form>
                  </div><?php } ?>
                   <p style="text-align: center;">Search Results :  <?php if($count_test_frame > 0)  {
                                      if($category != '')  { 
                                        $selectcategory = $mysqli->query("SELECT * FROM epariksa_category WHERE category_active=1 AND category_id=$category");
                                        $mainRow = mysqli_fetch_array($selectcategory);
                                        echo $category_name      = $mainRow['category_name'].','; }
                                        if($test_title != '')  { echo $test_title; } 
                                      }
                                      else {
                                        echo "No Test Available";
                                      } ?>
                                        
                                      </p>
                                       <div class="row">
                                        <?php                                 
                                            $test_frame_query = $mysqli->query("SELECT * FROM epariksa_test_frame WHERE test_active=1");
                                             // $count = mysqli_num_rows($test_frame_query);
                                            while($row = mysqli_fetch_array($select_test_frame)) {
                                            
                                                 $test_id       = $row['test_id']; 
                                                 
                                                  $test_image        = $row['test_image']; 
                                                   $test_title        = $row['test_title']; 
                                                    $no_of_questions        = $row['no_of_questions']; 
                                                     $total_marks        = $row['total_marks']; 
                                                      $test_time        = $row['test_time']; $question_id_arr_1     = explode(',', $row['question_id']); 
                                                $question_created_date  =getdate_formated ($row['test_created_date']);
                                                $category_id_arr_1     = $row['category_id'];
                                                $category_query = $mysqli->query("SELECT category_name FROM epariksa_category WHERE category_active = 1 AND category_id IN ($category_id_arr_1)");
                                                $category_arr = mysqli_fetch_array($category_query);
                                                $category_name = $category_arr['category_name'];
                                                $question_query =  $mysqli->query("SELECT question FROM epariksa_questions WHERE question_active = 1 AND question_id = $question_id "); 
                                                $question_arr = mysqli_fetch_array($question_query);

                                        ?>


                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-body">

                                    <div class="d-flex flex-column flex-sm-row">
                                        <a href="fixed-instructor-course-edit.html" class="avatar avatar-lg avatar-4by3 mb-3 w-xs-plus-down-100 mr-sm-3">
                                            <img src="test/<?php echo $test_image; ?>" alt="Card image cap" class="avatar-img rounded">
                                        </a>
                                        <div class="flex" style="min-width: 200px;">
                                            <!-- <h5 class="card-title text-base m-0"><a href="fixed-instructor-course-edit.html"><strong>Learn Vue.js</strong></a></h5> -->
                                            <h4 class="card-title mb-1"><a href="fixed-instructor-course-edit.html"><?php echo $test_title; ?></a></h4>
                                            <p> <?php echo $category_name; ?></p>
                                            <p class="text-black-70">  <?php 
                                $subject_id_arr_1      = $row['subject_id'];
                                $subject_query = $mysqli->query("SELECT subject_name FROM epariksa_subjects WHERE subject_active = 1 AND subject_id IN ($subject_id_arr_1)");

                                      while($subject_arr = mysqli_fetch_array($subject_query)) {
                                  $subject_name = $subject_arr['subject_name'];
                                   echo $subject_name.', '; ?>
                             <?php } ?></p>
                                            <div class="d-flex align-items-end">
                                                <div class="d-flex flex flex-column mr-3">
                                                    <div class="d-flex align-items-center py-1 border-bottom">
                                                        <small class="text-black-70 mr-2">No of Questions: <?php echo $no_of_questions; ?></small>
                                                         <small class="text-black-50">Time: <?php echo $test_time; ?></small>
                                                      


                                                    </div>
                                                    <div class="d-flex align-items-center py-1">
                                                       <!--  <small class="text-muted mr-2">GULP</small> -->
                                                        <small class="text-muted">Total Marks:  <?php echo $total_marks; ?></small>
                                                    </div>
                                                </div>
                                                <div class="text-center">
                                                  <?php if($_SESSION['role_id'] != 3){?>
                                                    <a href="view-questions.php?test_id=<?php echo $test_id; ?>" class="btn btn-sm btn-white">View</a>
                                                  <?php } else { ?><a data-toggle="modal" data-target="#editQuiz" href="view-questions.php?test_id=<?php echo $test_id; ?>" class="btn btn-sm btn-white">Start Test</a><?php } 
                                                  ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="card__options dropdown right-0 pr-2">
                                    <!-- <a href="#" class="dropdown-toggle text-muted" data-caret="false" data-toggle="dropdown">
                                        <i class="material-icons">more_vert</i>
                                    </a> -->
                                    

                                    <input type="checkbox" name="checked_box" class="checked_frame" value="<?php echo $test_id; ?>">
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a class="dropdown-item" href="fixed-instructor-course-edit.html">Edit course</a>
                                        <a class="dropdown-item" href="#">Course Insights</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item text-danger" href="#">Delete course</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                      <?php } ?>

                    </div>




                    </div>
                   
                  </div>
                
                </div>

                             

                    </div>





              
                
            </div>

        </div>




    <?php include 'sidebar.php';?>

    </div>

    
</div>
</div>

    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/dom-factory.js"></script>
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- App Settings (safe to remove) -->
    <script src="assets/js/app-settings.js"></script>






    <!-- List.js -->
    <script src="assets/vendor/list.min.js"></script>
    <script src="assets/js/list.js"></script>

    <!-- Tables -->
    <script src="assets/js/toggle-check-all.js"></script>
    <script src="assets/js/check-selected-row.js"></script>



  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script src="https://loopj.com/jquery-tokeninput/src/jquery.tokeninput.js"></script>
<script src="assets/js/datatable/jquery.dataTables.min.js"></script>

     <script type="text/javascript" src="assets/js/datatable/dataTables.rowReorder.min.js"></script>
  
    <script type="text/javascript" src="assets/js/datatable/dataTables.responsive.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
    var table = $('#example').DataTable( {
        rowReorder: {
            selector: 'td:nth-child(2)'
        },
        responsive: true
    } );
} );
    </script>


<script>
  $( function() {
    var availableTags = [<?php echo $arraytitle; ?>];
    
    $("#test_title").autocomplete({
      source: availableTags
    });
  } );
</script>


</body>

</html>