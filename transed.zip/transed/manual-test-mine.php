
<?php include('epariksa-transed-config.php');

$a ='';
if(isset($_GET['success'])){
    $response["success"] = "2";
        $a = json_encode($response);


}

if(isset($_POST['manual_question_submit'])) {

        $test_title      = ucfirst($_POST['test_title']);        
        $category_id                     = trim($_POST['category_id']);  
        $subject_id                      = trim(implode(',',$_POST['subject_id']));  

    
        $no_of_questions                 = trim($_POST['no_of_questions']); 
        $total_marks                     = trim($_POST['total_marks']);
        $test_time                      = trim($_POST['test_time']);
        $test_description                = trim(str_replace("'", "", $_POST['test_instructions'])); 
          $test_created_by                     = $session_login_id; 
        
        $test_created_date               = date('Y-m-d');
        $test_modified_date              = date('Y-m-d H:i:s');
        $test_active                     = 0;  
        
     
        // eliminate all special characters
        $res                             = preg_replace("/[^a-zA-Z0-9\s]/", "", $test_title);
        // To remove multiple white space into one single space
        $output                          = preg_replace('!\s+!', ' ', $res);
        // Change white space into (-)
        $image_name                            = str_replace(' ', '-', $output);
        
        $name                            = ''; $type = ''; $size = ''; $error = '';
        function compress_image($source_url, $destination_url, $quality) {
        $info                            = getimagesize($source_url);
        if ($info['mime']                == 'image/jpeg')
        $image                           = imagecreatefromjpeg($source_url);
        elseif ($info['mime']            == 'image/gif')
        $image                           = imagecreatefromgif($source_url);
        elseif ($info['mime']            == 'image/png')
        $image                           = imagecreatefrompng($source_url);
        imagejpeg($image, $destination_url, $quality);
        return $destination_url;
        }
        if($_FILES["test_image"]["name"] != '') {
        $file_ext                        = strtolower(end(explode('.', $_FILES["test_image"]["name"])));
        $test_image                      = $image_name.rand().'.'.$file_ext;
        compress_image($_FILES["test_image"]["tmp_name"], "test/".$test_image, 80);
        }
      

        
        $insertTest = $mysqli->query("INSERT INTO epariksa_test_frame(test_title, category_id, subject_id, no_of_questions, total_marks, test_time, test_description, test_image, test_created_by , test_created_date,test_modified_date,test_active) VALUES ('$test_title', '$category_id', '$subject_id', '$no_of_questions', '$total_marks', '$test_time', '$test_description', '$test_image', '$test_created_by','$test_created_date', '$test_modified_date', '$test_active')");

        $lastInserted_id  = $mysqli->insert_id;

       
 if($insertTest == true) {
        $response["success"] = "1";
        $a = json_encode($response);
      }
}

?>
<!DOCTYPE html> 
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Transed</title>

    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="assets/css/fontawesome.rtl.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">


    <!-- Touchspin -->
    <link rel="stylesheet" href="assets/css/bootstrap-touchspin.css">
    <link rel="stylesheet" href="assets/css/bootstrap-touchspin.rtl.css">

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="assets/css/nestable.css">
    <link rel="stylesheet" href="assets/css/nestable.rtl.css">
    <link rel="stylesheet" href="assets/css/wickedpicker.css">
    >
<link type="text/css" href="assets/css/quill.css" rel="stylesheet">
    <link type="text/css" href="assets/css/quill.rtl.css" rel="stylesheet">
<link href="assets/css/toastr.min.css" rel="stylesheet">
 <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.css" rel="stylesheet">

</head>

<body class=" layout-fluid">
 <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->

        <?php include 'header.php';?>

        <!-- // END Header -->

        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content">

            <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
                <div class="mdk-drawer-layout__content page">

                    <div class="container-fluid page__container">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                           
                            <li class="breadcrumb-item active">Manual Questions Test Creation</li>
                        </ol>
                       <!--  <h1 class="h2">Vue.js Deploy Quiz</h1> -->
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Test Creation (Manual Questions)</h4>
                            </div>
                            <div class="card-body">
                                <form action="manual-test.php" method="POST" enctype="multipart/form-data"> 
                                    <div class="form-group row">
                                        <label for="quiz_title" class="col-sm-3 col-form-label form-label">Test Title:</label>
                                        <div class="col-sm-9">
                                            <input id="test_title" name="test_title" type="text" class="form-control" placeholder="Title">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="course_title" class="col-sm-3 col-form-label form-label">Category:</label>
                                        <div class="col-sm-9 col-md-9">
                                            <select id="category_id" name="category_id" class="custom-select form-control" >
                                                <option val="">Select Category</option>
                                               <?php 
                    $select_maincategory = $mysqli->query("SELECT * FROM epariksa_category WHERE category_active=1");
                    while($maincategoryRow = mysqli_fetch_array($select_maincategory)) {
                    $category_id       = $maincategoryRow['category_id'];
                    $category_name      = $maincategoryRow['category_name']; ?>
                  <option value="<?php echo $category_id; ?>"><?php echo $category_name; ?></option>
                        <?php } ?>
                                            </select>
                                        </div>
                                    </div>


                                <div class="form-group row">
                                          
                                    <label class="col-sm-3 col-form-label form-label" for="maskSample01"> Subjects</label>
                                    <div class="col-sm-9 col-md-9">
                                      <select class="s2-multiple" class="form-control" id="subject_id" name="subject_id[]"  multiple="multiple">  
                                       </select>
                                </div>
                                
                                </div>  



                                 <div class="form-group row">
                                          
                                <label class="col-sm-3 col-form-label form-label" for="maskSample01">No of Questions</label>
                                    <div class="col-sm-9 col-md-4">
                                    <input id="no_of_questions"  name="no_of_questions" type="text" class="form-control" placeholder="No: 1">
                                </div>
                                </div>



                                 <div class="form-group row">
                                          
                                <label class="col-sm-3 col-form-label form-label" for="maskSample01">Total Mark</label>
                                    <div class="col-sm-9 col-md-4">
                                    <input id="total_marks" name="total_marks" type="text" class="form-control" placeholder="100" >
                                </div>
                                </div>


         

                                    <div class="form-group row">
                                        <label for="cmn-toggle" class="col-sm-3 col-form-label form-label">Timeframe</label>
                                        <div class="col-sm-4">
                                           
                                              <!--   <input type="text" id="timepicker-one" name="test_time" class="timepicker form-control"/> -->
                                                <input type="text" id="time" name="test_time" data-format="HH:mm" data-template="HH : mm" name="datetime">
                                           
                                           
                                        </div>
                                    </div>




                                 <div class="form-group row">
                                          
                                <label class="col-sm-3 col-form-label form-label" for="maskSample01">Instructions</label>
                                    <div class="col-sm-9 col-md-9">
                                      <div style="height: 150px;" data-toggle="quill" data-quill-placeholder="Quill WYSIWYG editor">
                                </div>
                                </div>
                                </div>


                                    <div class="form-group row">
                                            <label for="avatar" class="col-sm-3 col-form-label form-label">Upload Image</label>
                                            <div class="col-sm-9">
                                              <div class="media align-items-center">
                                                    <div class="media-left">
                                                        <div class="icon-block rounded">
                                                          <img src="" id="profile-img-tag" width="90px" />
                                                        </div>
                                                    </div>
                                                    <div class="media-body">
                                                        <div class="custom-file" style="width: auto;">
                                                             <input type="file"  id="profile-img" name="test_image" class="custom-file-input"> 

                                                            <label for="avatar" class="custom-file-label">Choose file</label>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>



                                    <div class="form-group row mb-0">
                                        <div class="col-sm-9 offset-sm-3">
                                            <button type="submit" id="manual_question_submit" name="manual_question_submit" class="btn btn-success">Save</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Questions</h4>
                            </div>
                            <div class="card-header">
                                <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-outline-secondary">Add Question <i class="material-icons">add</i></a>
                            </div>
                            <div class="nestable" id="nestable">
                                <ul class="list-group list-group-fit nestable-list-plain mb-0">
                                    <li class="list-group-item nestable-item">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                            </div>
                                            <div class="media-body">
                                                Installation
                                            </div>
                                            <div class="media-right text-right">
                                                <div style="width:100px">
                                                    <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item nestable-item">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                            </div>
                                            <div class="media-body">
                                                The MVC architectural pattern
                                            </div>
                                            <div class="media-right text-right">
                                                <div style="width:100px">
                                                    <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item nestable-item">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                            </div>
                                            <div class="media-body">
                                                Database Models
                                            </div>
                                            <div class="media-right text-right">
                                                <div style="width:100px">
                                                    <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item nestable-item" data-id="4">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                            </div>
                                            <div class="media-body">
                                                Database Access
                                            </div>
                                            <div class="media-right text-right">
                                                <div style="width:100px">
                                                    <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item nestable-item" data-id="5">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                            </div>
                                            <div class="media-body">
                                                Eloquent Basics
                                            </div>
                                            <div class="media-right text-right">
                                                <div style="width:100px">
                                                    <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item nestable-item" data-id="6">
                                        <div class="media align-items-center">
                                            <div class="media-left">
                                                <a href="#" class="btn btn-default nestable-handle"><i class="material-icons">menu</i></a>
                                            </div>
                                            <div class="media-body">
                                                Take Quiz
                                            </div>
                                            <div class="media-right text-right">
                                                <div style="width:100px">
                                                    <a href="#" data-toggle="modal" data-target="#editQuiz" class="btn btn-primary btn-sm"><i class="material-icons">edit</i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>




             <?php include 'sidebar.php';?>

            </div>

            <!-- App Settings FAB -->
          

        </div>
    </div>



    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/dom-factory.js"></script>
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- App Settings (safe to remove) -->
    <script src="assets/js/app-settings.js"></script>

     <script src="assets/js/select2.min.js"></script>
      <script src="assets/js/wickedpicker.js"></script>

     <script type="text/javascript">
          var timepickers = $('.timepicker').wickedpicker();
        console.log(timepickers.wickedpicker('time', 1));
     </script>



   
  



    <div class="modal fade" id="editQuiz">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <h4 class="modal-title text-white">Edit Question</h4>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="#">
                        <div class="form-group row">
                            <label for="qtitle" class="col-form-label form-label col-md-3">Title:</label>
                            <div class="col-md-9">
                                <input id="qtitle" type="text" class="form-control" value="Database Access">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="type" class="col-form-label form-label col-md-3">Type:</label>
                            <div class="col-md-4">
                                <select id="type" class="custom-control custom-select form-control">
                                    <option value="1">Input</option>
                                    <option value="2">Textarea</option>
                                    <option value="3">Checkbox</option>
                                    <option value="3">Radio</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label form-label col-md-3">Answers:</label>
                            <div class="col-md-9">
                                <a href="#" class="btn btn-default"><i class="material-icons">add</i> Add Answer</a>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="touch-spin-2" class="col-form-label form-label col-md-3">Question Score:</label>
                            <div class="col-md-4">
                                <input id="touch-spin-2" data-toggle="touch-spin" data-min="0" data-max="100" data-step="5" type="text" value="50" name="demo2" class="form-control" />
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-3">
                                <button type="submit" class="btn btn-success">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Vendor JS -->
    <script src="assets/vendor/jquery.nestable.js"></script>
    <script src="assets/vendor/jquery.bootstrap-touchspin.js"></script>
   <script src="assets/vendor/quill.min.js"></script>
    <script src="assets/js/quill.js"></script>
    <!-- Initialize -->
    <script src="assets/js/nestable.js"></script>
    <script src="assets/js/touchspin.js"></script>
<script src="assets/js/select2.min.js"></script>
<script src="assets/js/moment.min.js"></script>
     
      <script src="assets/js/combodate.js"></script>

      <script>
$(function(){
    $('#date').combodate({customClass: 'form-control'});    
    $('#datetime').combodate(); 
    $('#time').combodate({
        firstItem: 'name', //show 'hour' and 'minute' string at first item of dropdown
        minuteStep: 1,
        customClass: 'form-control'
    });   
});
</script>
<!-- <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script> -->
     <script type="text/javascript">
document.addEventListener("DOMContentLoaded", function() {
    $(".s2-multiple").select2();
});

</script>
<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#profile-img-tag').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#profile-img").change(function(){
        readURL(this);
    });
</script>
<script>
$('#category_id').change(function(){
    var category_id = $('#category_id').val();
   // var subject_id  = $('#subject_id').val();
    console.log(category_id);
    $.ajax({
        type:'POST',
        url:'questionpanel/ajax-subjects.php',
        data:'category_manual='+category_id,
        success:function(html){
            $("#subject_id").html(html);

        }
    })

});
</script>
<script type="text/javascript" src="assets/js/toastr.min.js"></script>
<script>

var a = '<?php echo  $a ;?>';
var obj = JSON.parse(a);
if (obj.success == 1){
// toastr.success('Success', 'Test Created Successfully..')

  toastr.success('Test Created Successfully..');
    
  setTimeout(function(){  window.location.href = "manual-question-selection.php?test_id=<?php echo $lastInserted_id; ?>" }, 1000);

}

if (obj.success == 2){
  toastr.success('Test Created Successfully..');
}
</script>
</body>

</html>