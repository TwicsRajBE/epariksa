<?php
session_start();
ini_set('display_errors','On');
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_WARNING & ~E_STRICT & ~E_DEPRECATED);
date_default_timezone_set('Asia/Kolkata');

$msg = $lmsg = "";
  $mysqli = new mysqli('localhost', 'root', '', 'epariksa_transed');

  if ($mysqli->connect_error) {
    die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
  }

if(isset($_REQUEST['action'])) {

  if ($_REQUEST['action'] == "logout") {
      
    $lmsg = "You have successfully logged out!";
    $msg = "";
    session_destroy();
    unset($_SESSION);
    
  } 
  else if (isset($_REQUEST['action']) || $_REQUEST['action'] == "login") {

   // $user_name = $_REQUEST['user_name'];
    $email     = $_REQUEST['email'];
    $password  = $_REQUEST['password'];
    

  if($email !='' & $password !='') {

    $login_sql = $mysqli->query("SELECT * FROM epariksa_login WHERE email LIKE '$email' AND password LIKE '$password' AND login_active=1");
    
     $loginRowCount = mysqli_num_rows($login_sql);
     $loginRow = mysqli_fetch_array($login_sql);
     
    if ($loginRowCount == 1) {
         $role_id = $loginRow['role_id'];
         $login_id = $loginRow['login_id'];

      if($role_id == 1){
        $_SESSION['login_id'] = $login_id;
        $_SESSION['role_id']  = $role_id;
        header("Location: dashboard.php"); 
       }

      if ($role_id == 2) {
         $_SESSION['login_id'] = $login_id;
         $_SESSION['role_id']  = $role_id;
      
        header("Location: dashboard.php");
   
      }

      if ($role_id == 3) {
        $_SESSION['login_id'] = $login_id;
        $_SESSION['role_id']  = $role_id;
        header("Location: dashboard.php"); 
      }
      
    } 
      
  }

    else {
      $msg = "Invalid Username / Password..Try Again !";
      $lmsg = "";
      session_destroy();
      unset($_SESSION);
      unset($username, $password);
    }
  }
}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login | Transed</title>

    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="assets/css/fontawesome.rtl.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
 <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.css" rel="stylesheet">





</head>

<body class="login" background="login-bg.png">


    <div class="d-flex align-items-center" style="min-height: 100vh">
        <div class="col-sm-8 col-md-6 col-lg-4 mx-auto" style="min-width: 300px;">
            <div class="text-center mt-5 mb-1">
                <div class="">
                    <img src="assets/images/logo/epariksa-logo.png" class="" alt="transed" />
                </div>
            </div>
           
            <div class="card navbar-shadow">
                <div class="card-header text-center">
                    <h4 class="card-title">Login</h4>
                    <p class="card-subtitle">Access your account</p>
                </div>
                <div class="card-body">
<!-- 
                    <a href="#" class="btn btn-light btn-block">
                         <i class="fab fa-google padding-right-0"></i>
                        Continue with Google
                    </a>
 -->
                 <!--    <div class="page-separator">
                        <div class="page-separator__text">or</div>
                    </div> -->

                    <form action="login.php"  method="POST" onsubmit="return addloginvalidation()">
                        <div class="form-group">
                            <label class="form-label" for="email">Your email address:</label>
                            <div class="input-group input-group-merge">
                                <input id="email" name="email" type="email" class="form-control form-control-prepended" placeholder="Your email address" onkeyup="hideErroremail();">
                              
							  
                                 <input id="action" name="action" type="hidden" class="form-control form-control-prepended" value="login" placeholder="Your email address">
                         
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                        <span class="far fa-envelope"></span>
                                    </div>
                                </div>
								
                            </div>
                        </div>
						  <p style="color: red;" id="add_email" ></p>
                        <div class="form-group">
                            <label class="form-label" for="password">Your password:</label>
                            <div class="input-group input-group-merge">
                                <input id="password" name="password" type="password" class="form-control form-control-prepended" placeholder="Your password" onkeyup="hideErrorpwd();">
								
                                <div class="input-group-prepend">
                                    <div class="input-group-text">
                                         <i class="fas fa-key"></i>
                                    </div>
                                </div>
								
                            </div>
                        </div>
						 <p style="color: red;" id="add_pwd" ></p>
                        <div class="form-group ">
                            <button type="submit" id="login_submit" name="login_submit" class="btn btn-primary btn-block">Login</button>
                        </div>
                        <div class="text-center">
                            <a href="" class="text-black-70" style="text-decoration: underline;">Forgot Password?</a>
                        </div>
                    </form>
                </div>

                <div class="card-footer text-center text-black-50">
                    Not yet a student? <a href="signup.php">Sign up</a>
                </div>
            </div>
        </div>
<div class="clearfix"></div>

          <footer class="footer dark-block">
   
  </footer>


    </div>


    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/dom-factory.js"></script>
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- App Settings (safe to remove) -->
    <script src="assets/js/app-settings.js"></script>
<script type="text/javascript">
 
 function hideErroremail(){
		 document.getElementById("add_email").innerHTML= " ";
		}
function hideErrorpwd(){
		 document.getElementById("add_pwd").innerHTML= " ";
		}
function addloginvalidation()
			{
				
			var loginemail = document.getElementById("email").value;
                    if(loginemail == "")
					{
                            document.getElementById("add_email").innerHTML="Please Enter Email address...!";
                            document.getElementById("email").focus();
							return false;
                                
                    }
                    var atposition=loginemail.indexOf("@");  
					var dotposition=loginemail.lastIndexOf(".");  
					if (atposition<1 || dotposition<atposition+2 || dotposition+2>=loginemail.length)
					{  
				   document.getElementById("add_email").innerHTML = "Invalid E-mail Address...!";
                   document.getElementById("email").focus();
					//alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
					 return false;  
					  }  
                    
                    
                    
                    if (loginemail.length > 0) 
					{
                    if (!/^([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,63})$/.test(loginemail)) 
				    {
                        document.getElementById("add_email").innerHTML = "Invalid E-mail Address...!";
                        document.getElementById("email").focus();
						return false;

                    }
					                        
					}

		var loginpwd = document.getElementById("password").value;
				    if(loginpwd == "") 
					   {
										
						document.getElementById("add_pwd").innerHTML= "Please Enter the Password...!";
						document.getElementById("password").focus();
						return false;
											
					   }
					    
					/* if(loginpwd.length < 8) 
					   {
						document.getElementById("add_pwd").innerHTML= "Password must Contain at least Eight Characters!";
						document.getElementById("password").focus();
						return false;
															
					   
					    }
					  if(loginpwd== loginemail)
					   {
						document.getElementById("add_pwd").innerHTML= "Password must be Different from Username!";
						document.getElementById("password").focus();
						return false;
					    }
					
					  
					  re = /[0-9]/;
					  if(!re.test(loginpwd))
						  {
						  
						document.getElementById("add_pwd").innerHTML= "Password must Contain at least One Number (0-9)!";
						document.getElementById("password").focus();
						return false;
					  }
					   upper = /[A-Z]/;
					  if(!upper.test(loginpwd))
					  {
						document.getElementById("add_pwd").innerHTML= "Password must Contain at least One Uppercase Letter (A-Z)!";
						document.getElementById("password").focus();
						return false;
					  }
					  lower = /[a-z]/;
					  if(!lower.test(loginpwd))
					 {
						document.getElementById("add_pwd").innerHTML= "Password must Contain at least One Lowercase Letter (a-z)!";
						document.getElementById("password").focus();
						return false;
					  }
					  symbol = /[!@#$%^&*_]/;
					  if(!symbol.test(loginpwd))
					 {
						document.getElementById("add_pwd").innerHTML= "Password must Contain at least One Symbol (!@#$%^&*_)!";
						document.getElementById("password").focus();
						return false;
					  }*/
					  
				  
				
		return true;
				
			
			}
</script>




</body>

</html>