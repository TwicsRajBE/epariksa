<?php include('epariksa-transed-config.php'); ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Transed</title>
    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">
    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="assets/css/fontawesome.rtl.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">


    <!-- Data Table -->

    <link rel="stylesheet" href="assets/css/datatable/jquery.dataTables.min.css" crossorigin="anonymous">

  <link rel="stylesheet" href="assets/css/datatable/rowReorder.dataTables.min.css">

<link rel="stylesheet" type="text/css" href="assets/css/datatable/responsive.dataTables.min.css">











</head>

<body class=" layout-fluid">







    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->
<?php include 'header.php';?>
       

        <!-- // END Header -->

        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content">

            <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
                <div class="mdk-drawer-layout__content page">



                    <div class="container-fluid page__container">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                            <li class="breadcrumb-item">Test Result</li>
                            <li class="breadcrumb-item active">View Test Result</li>
                        </ol>

                        <h1 class="h2">View List</h1>


                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    
                                    <div class="col-lg-12">

                                        <div class="table-responsive border-bottom" data-toggle="lists" data-lists-values='["js-lists-values-employee-name"]'>

                                           <!-- <div class="search-form search-form--light mb-3">
                                                <input type="text" class="form-control search" placeholder="Search">
                                                <button class="btn" type="button" role="button"><i class="material-icons">search</i></button>
                                            </div>-->
                                            <table id="example" class="display nowrap" style="width:100%">
                                                <thead>
												<?php $i=1; ?>
												     <th>Sno.</th>
		                                             <th>Title</th>
                                                     <th>Questions</th>
													<th>Right Answers</th>
													<th>Wrong Answers</th>
												   <th>Time<th>
												   <th>view<th>
                                                </thead>
                                                    <tbody>
													 <?php     
$session_login_id           = $_SESSION['login_id'];
											 
$studentstempans = $mysqli->query("SELECT * FROM epariksa_temp_ans WHERE login_id=$session_login_id");
//echo "SELECT * FROM epariksa_temp_ans WHERE login_id=$session_login_id";
while($students_row = mysqli_fetch_array($studentstempans)) {
$test_id    = $students_row['test_id'];  

}
$studentstitle = $mysqli->query("SELECT * FROM epariksa_test_frame WHERE test_id=$test_id");
//echo "SELECT * FROM epariksa_test_frame WHERE test_id=$test_id";
while($studentstitle_row = mysqli_fetch_array($studentstitle)) {

 $test_title    = $studentstitle_row['test_title']; 
 //print_r($test_title);
$test_time    = $studentstitle_row['test_time']; 	
//print_r($test_time);
$explode_value =  explode(':', $test_time);

                                $hours =  $explode_value[0];
								
                                $min =  $explode_value[1];
								
}

$studenttestresult = $mysqli->query("SELECT * FROM epariksa_test_result WHERE test_id=$test_id");
//echo "SELECT * FROM epariksa_test_result WHERE test_id=$test_id";
while($testresult_row = mysqli_fetch_array($studenttestresult))
	{
$result_id    = $testresult_row['result_id']; 		
$question_ans    = $testresult_row['question_ans'];
//print_r($question_ans);  
$question_total    = $testresult_row['question_total'];  
$question_right_ans    = $testresult_row['question_right_ans'];
$question_wrong_ans    = $testresult_row['question_wrong_ans'];

           
    
                                  ?> 



             



                                                   <tr>
														    <td> <span class="js-lists-values-employee-name"><?php echo $i; ?></span></td>
                                                            <td> <span class="js-lists-values-employee-name"><?php echo $test_title; ?></span></td>
                                                            
                                                            
                                                            <td> <span class="js-lists-values-employee-name"><?php echo $question_total; ?></span></td>
                                                            <td> <span class="js-lists-values-employee-name"><?php echo $question_right_ans; ?></span></td>
															<td> <span class="js-lists-values-employee-name"><?php echo $question_wrong_ans; ?></span></td>
															<td><span class="js-lists-values-employee-name"><?php echo $hours;?>   Hrs  <?php echo $min; ?> Min</span></p></td>
															
															<td><a href="view-test-result.php?result_id=<?php echo $result_id; ?>"><span class="fa fa-eye"></span></p></a></td>
															
															
                                                        </tr>
	<?php $i++;} ?>
														 
                                                    </tbody>
    <tfoot>
        <tr>
		                                             <th>Sno.</th>
		                                             <th>Title</th>
                                                     <th>Questions</th>
													<th>Right Answers</th>
													<th>Wrong Answers</th>
												   <th>Time<th>
                                                   <th>view<th>
        </tr>
    </tfoot>
</table>




                                        </div>


                                    </div>
                                </div>
                            </div>
                            
                        </div>

                        
                    </div>

                </div>




            <?php include 'sidebar.php';?>

            </div>

            
        </div>
    </div>



    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/dom-factory.js"></script>
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- App Settings (safe to remove) -->
    <script src="assets/js/app-settings.js"></script>

    <!-- List.js -->
    <script src="assets/vendor/list.min.js"></script>
    <script src="assets/js/list.js"></script>

    <!-- Tables -->
    <script src="assets/js/toggle-check-all.js"></script>
    <script src="assets/js/check-selected-row.js"></script>

    <!-- DATA TABLE JS -->

      <!-- Latest compiled and minified JavaScript -->
<script src="assets/js/datatable/jquery.dataTables.min.js"></script>

     <script type="text/javascript" src="assets/js/datatable/dataTables.rowReorder.min.js"></script>
  
    <script type="text/javascript" src="assets/js/datatable/dataTables.responsive.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
    var table = $('#example').DataTable( {
        rowReorder: {
            selector: 'td:nth-child(2)'
        },
        responsive: true
    } );
} );
    </script>

</body>

</html>