
<?php include('epariksa-transed-config.php');



if(isset($_GET['test_id'])) {

 $test_id          = $_GET['test_id'];

$Select_test      = $mysqli->query("SELECT * FROM epariksa_test_frame WHERE test_id = '$test_id'");

$test_row         = mysqli_fetch_array($Select_test);
$test_title       = $test_row['test_title'];
$category_id      = $test_row['category_id'];
$select_maincategory = $mysqli->query("SELECT * FROM epariksa_category WHERE category_active=1 AND category_id = '$category_id'");
$maincategoryRow = mysqli_fetch_array($select_maincategory);
$category_name      = $maincategoryRow['category_name']; 
$subject_id       = $test_row['subject_id'];
$no_of_questions  = $test_row['no_of_questions'];
$total_marks      = $test_row['total_marks'];
$test_time        = $test_row['test_time'];
$test_description = $test_row['test_description'];
$test_image       = $test_row['test_image'];

}

$response["success"] = "0";
$a = json_encode($response);


if(isset($_POST['question_submit'])) {


$test    = $_POST['test'];
$question = implode(',',$_POST['question']);
  $test_type   = 'manual';

$select_question = $mysqli->query("SELECT *  FROM epariksa_questions eq 
WHERE eq.question_id IN ($question)");
    $select_question_count = mysqli_num_rows($select_question);
    if($select_question_count > 0){
        while($row = mysqli_fetch_array($select_question)){
            $category_id_arr[] = $row['category_id'];
            $subject_id_arr[]     = $row['subject_id'];
            $topic_id_arr[]      = $row['topic_id'];
            $question_id_arr[]    = $row['question_id'];
           

        }

        $category_id           = trim(implode(',',$category_id_arr));
        $subject_id            = trim(implode(',',$subject_id_arr));
        $topic_id              = trim(implode(',',$topic_id_arr));
                      

$update = $mysqli->query("UPDATE epariksa_test_frame SET category_id= '$category_id', subject_id= '$subject_id',topic_id='$topic_id', question_id ='$question', test_active = 1,test_type ='$test_type' WHERE test_id= $test");



}
 if($update == true) {
    //   echo "hjkl";
    // exit;
        //$response["success"] = "1";
        //$a = json_encode($response);
    header("Location:manual-test.php?success=created");
    }
     


}


?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Transed</title>

    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="assets/css/fontawesome.rtl.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/fontawesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/fancytree.css">
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link href="assets/css/toastr.min.css" rel="stylesheet">

 <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.css" rel="stylesheet">



</head>

<body class=" layout-fluid">







    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->

      <?php include 'header.php';?>

        <!-- // END Header -->

        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content">

            <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
                <div class="mdk-drawer-layout__content page">

                    <div class="container-fluid page__container">
                      <!--   <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                            <li class="breadcrumb-item active">Manage Test</li>
                        </ol>

                        <div class="media align-items-center mb-headings">
                            <div class="media-body">
                                <h1 class="h2">Manage Test</h1>
                            </div>
                           
                        </div> -->



                        

                            <div class="card card-sm">
                                <div class="card-body media padd-extra">
                                    <div class="media-left">
                                        <a href="" class="avatar avatar-lg avatar-4by3">
                                            <img src="test/<?php echo $test_image; ?>" alt="Card image cap" class="avatar-img rounded">
                                        </a>
                                    </div>
                                    <div class="media-body">
                                    <h3 class="card-title mb-0"><?php echo $test_title; ?> (<?php echo $category_name; ?>) </h3>
                                    <?php 
                                    $sub_value = explode(',',$subject_id); 
                         $count_id = count($sub_value);

                          for($i=0; $i<$count_id; $i++) {

                          $selectQuery = $mysqli->query("SELECT * FROM epariksa_subjects WHERE subject_active=1 AND subject_id='$sub_value[$i]'");
                      

                          $selectRow =  mysqli_fetch_array($selectQuery);
                            $sub_name = $selectRow['subject_name'];  ?>
                        

                                       <?php echo $sub_name,','; ?>

                                       <?php } ?>
                                    </div>
                                   
                                </div>
                                <div class="card-footer text-center time-schedule">
                                    <a href="#" class="btn btn-white btn-sm float-left text-size">Total No of Question <span class="badge badge-dark ml-2"><?php echo $no_of_questions; ?></span></a>

                                 <?php  
                                $explode_value =  explode(':', $test_time);
                                $hours =  $explode_value[0];
                                $min =  $explode_value[1];
                                  ?> 



                                    <a href="#" class="btn btn-default btn-sm float-right text-size">   <i class="material-icons text-muted-light">schedule</i> &nbsp; <?php echo $hours; ?>  &nbsp; <small class="text-muted">hrs</small> &nbsp; <?php echo $min; ?><small class="text-muted"> &nbsp;min</small> </a>

                                     <!--  <span class="badge badge-notifications badge-success selected_topic_question" style="float: right;"></span> -->

                                      <!--  <a href="#" class="btn btn-white btn-sm float-left text-size">List of Questions <span class="badge badge-dark ml-2 selected_topic_question"></span></a> -->
                                       <span class="selected_topic_question"></span>

                                        <span class="remaining_question"></span>

                                        <!-- <a href="#" class="btn btn-white btn-sm float-left text-size">Remaining Questions<span class="badge badge-dark ml-2 remaining_question"></span></a> -->

<!-- 

                                      <span class="badge badge-dark ml-2 selected_topic_question"></span>

                                      <span class="badge badge-dark ml-2 remaining_question"></span>
 -->

                                    <!--    <span class="badge badge-notifications badge-success remaining_question" style="float: right;"></span> -->



                                    <div class="clearfix"></div>
                                </div>
                            </div>

           
                         
                             <form action="manual-question-selection.php" method="POST">   

                        <div class="card ">
                            <div class="card-body">
                                <div class="row">
                                    
                                    <div class="col-lg-12">
                                        <div class="table-responsive border-bottom" data-toggle="lists" data-lists-values='["js-lists-values-employee-name"]'>

                                            <div class="search-form search-form--light mb-3">
                                                <input type="text" class="form-control search" placeholder="Search">
                                                <button class="btn" type="button" role="button"><i class="material-icons">search</i></button>
                                            </div>

                                            <table class="table mb-0">
                                                <thead>
                                                    <tr>
                                                           <!--  <input type="checkbox" id="checkAll"/> -->
                                                          
                                                        <th>  S.no</th>
                                                        <th>Questions</th>
                                                         <th>Topics</th>
                                                        <th>Answer</th>

                                                      
                                                    </tr>
                                                </thead>
                                                <tbody class="list question_list" id="search">
                                                    
                                              

                                                </tbody>
                                            </table>
                                        </div>


                                    </div>

                                       <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-3">
                                <button type="submit" id="question_submit" name="question_submit" class="btn btn-success"> Create Test</button>
                            </div>
                        </div>



                                </div>



                     

                            </div>
                        </div>


                    </form>
                        <!-- card end -->

                       

                   
                    </div>

                </div>







<!-- sidebar -->

<div class="mdk-drawer js-mdk-drawer" id="default-drawer">
                    <div class="mdk-drawer__content ">
                        <div class="sidebar sidebar-left sidebar-white bg-white o-hidden" data-perfect-scrollbar>
                             <div class="sidebar-p-y tree-pad">
                    <aside class="sidebar">
            <h1 class="sidebar-heading">
                Filter by
            </h1>



            <ul class="filter ul-reset">
                

                <form action="manual-question-selection" method="POST" >
                 <?php 
                     $sub_value = explode(',',$subject_id); 
                         $count_id = count($sub_value);

                          for($i=0; $i<$count_id; $i++) {
                          $selectQuery = $mysqli->query("SELECT * FROM epariksa_subjects WHERE subject_active=1 AND subject_id='$sub_value[$i]'");
                          $selectRow =  mysqli_fetch_array($selectQuery);
                           $subject_id = $selectRow['subject_id'];
                            $sub_name = $selectRow['subject_name'];  ?>
                <li class="filter-item">
                    <section class="filter-item-inner">
                        <h1 class="filter-item-inner-heading minus">
                            <?php echo $sub_name; ?>
                        </h1>
                        <ul class="filter-attribute-list ul-reset">
                            <div class="filter-attribute-list-inner custom-control custom-checkbox">

                        <?php   
                        $j=1;

                         $select_topic = $mysqli->query("SELECT * FROM epariksa_topics WHERE topic_active=1 AND subject_id = $subject_id");
                    while($topicrow = mysqli_fetch_array($select_topic)) {

                    $topic_id       = $topicrow['topic_id'];
                    $topic_name      = $topicrow['topic_name']; ?>

                                <li class="filter-attribute-item">

                                    <input type="hidden" class = "question_checkbox_checked_count" name = "question_checkbox_checked_count">


                                    <input  type="checkbox" class="topic_name_search" data_category_id = "<?php echo  $category_id; ?>"  data_subject_id = "<?php echo $subject_id; ?>"  data_topic_id = "<?php echo $topic_id;  ?>" id="topic_name_search" name="topic_name_search[]" value="<?php echo $topic_id.'-'. $category_id.'-'.$subject_id; ?>"> <?php echo $topic_name; ?>
                               <!--    <input  type="hidden" id="category_na$category_id me" name="category_name" >

                                  <input  type="hidden" id="subject_name" name="subject_name" value=" <?php echo $subject_id; ?>"> -->

                                </li>
                             
                              <?php } ?>                     
                               
                                
                            </div>

       


                        </form>
                        </ul>


                    </section>
               
                 <?php } ?> </li>
            </ul>
        </aside>

            </div>
        </div>
    </div>
</div>


<!-- sidebar -->














            </div>

          

        </div>
    </div>






    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/dom-factory.js"></script>
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- App Settings (safe to remove) -->
    <script src="assets/js/app-settings.js"></script>

 <script src="https://cdn.jsdelivr.net/jquery.ui/1.11.4/jquery-ui.min.js"></script>
    <script src="assets/vendor/jquery.fancytree-all.min.js"></script>
    <script type="text/javascript" src="assets/js/toastr.min.js"></script>

    <!-- Initialize tree -->
    <script src="assets/js/fancytree.js"></script>

<script type="text/javascript">
     $('.filter-attribute-list').css('display','none');
    function accordion(section, heading, list) {
    $(section).each(function() {
        var that = this,
                listHeight = $(this).find(list).height();

        $(this).find(heading).click(function() {
            $(this).toggleClass('plus minus');
            //$('.filter-attribute-list').css('display','block');
            $(that).find(list).slideToggle(250);
        });
    });
};
accordion('.filter-item', '.filter-item-inner-heading', '.filter-attribute-list');
</script>

<script>
$('.topic_name_search').click(function(){
    var topic_id = $(this).attr('data-id');
     var test_id = <?php echo $_GET['test_id']; ?>;
     var question_checkbox_checked_count = $('.question_checkbox_checked_count').val();

            var category_value = $(this).attr('data_category_id');

            var subject = [];
            $.each($("input[name='topic_name_search[]']:checked"), function(){            
                subject.push($(this).attr('data_subject_id'));
            });
            var subject_value = subject.join(", ");


              var topic = [];
            $.each($("input[name='topic_name_search[]']:checked"), function(){            
                topic.push($(this).attr('data_topic_id'));
            });
            //alert("My favourite sports are: " + topic.join(", "));

            var topic_value = topic.join(", ");
    $.ajax({
        type:'POST',
        url:'questionpanel/ajax-subjects.php',

        // data:'category_value='+category_value+,'subject_value='+subject_value,'topic_value='+topic_value

data: {'category_value': category_value,'subject_value' : subject_value,'topic_value' :topic_value,'test_id' :test_id,'question_checkbox_checked_count':question_checkbox_checked_count },

        success:function(html){
            $(".question_list").html(html);
               var numworking = $('.question_count').length;
                // $('.selected_topic_question').text('List of questions '+numworking);
                $('.selected_topic_question').empty();
                $('.selected_topic_question').append('<a href="#" class="btn btn-white btn-sm float-left text-size">List of Questions <span class="badge badge-dark ml-2 selected_topic_question">'+ numworking +'</span></a>')
                //$('.selected_topic_question').text(numworking);
        }
    })

});
</script>

<!-- Checked box count -->
<script type="text/javascript">

$(document).on('click', '.question_checked_all', function(){
var ckecked_questions = $('.question_checked_all').filter(':checked').length;
 var favorite = [];
            $.each($("input[name='question[]']:checked"), function(){            
                favorite.push($(this).val());
            });
            //alert("My favourite sports are: " + favorite.join(", "));
            $('.question_checkbox_checked_count').val(favorite.join(", "));
var no_of_que = <?php echo $no_of_questions; ?>;
var bal_que = no_of_que - ckecked_questions;
 $('.remaining_question').empty();
$('.remaining_question').append('<a href="#" class="btn btn-white btn-sm float-left text-size">Remaining Questions<span class="badge badge-dark ml-2 remaining_question">'+bal_que+'</span></a>')

});
</script>

<script>

var a = '<?php echo  $a ;?>';
var obj = JSON.parse(a);
if (obj.success == 1){
 
  window.location.href = "manual-test.php";
   toastr.success('Test Created Successfully..');

}

</script>


</body>


</html>