<!DOCTYPE html>
<html lang="en" dir="ltr">


<!-- Mirrored from learnplus-bootstrap.frontendmatter.com/fixed-instructor-courses.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 07 Dec 2018 07:15:09 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Transed</title>

    <!-- Prevent the demo from appearing in search engines (REMOVE THIS) -->
    <meta name="robots" content="noindex">

    <!-- Perfect Scrollbar -->
    <link type="text/css" href="assets/vendor/perfect-scrollbar.css" rel="stylesheet">

    <!-- Material Design Icons -->
    <link type="text/css" href="assets/css/material-icons.css" rel="stylesheet">
    <link type="text/css" href="assets/css/material-icons.rtl.css" rel="stylesheet">

    <!-- Font Awesome Icons -->
    <link type="text/css" href="assets/css/fontawesome.css" rel="stylesheet">
    <link type="text/css" href="assets/css/fontawesome.rtl.css" rel="stylesheet">

    <!-- App CSS -->
    <link type="text/css" href="assets/css/app.css" rel="stylesheet">
    <link type="text/css" href="assets/css/app.rtl.css" rel="stylesheet">

 <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.1/css/all.css" rel="stylesheet">








</head>

<body class=" fixed-layout">










    <div class="preloader">
        <div class="sk-double-bounce">
            <div class="sk-child sk-double-bounce1"></div>
            <div class="sk-child sk-double-bounce2"></div>
        </div>
    </div>

    <!-- Header Layout -->
    <div class="mdk-header-layout js-mdk-header-layout">

        <!-- Header -->

        <div id="header" class="mdk-header bg-dark js-mdk-header m-0" data-fixed data-effects="waterfall">
            <div class="mdk-header__content">

                <!-- Navbar -->
                <nav id="default-navbar" class="navbar navbar-expand navbar-dark bg-primary m-0">
                    <div class="container">
                        <!-- Toggle sidebar -->
                        <button class="navbar-toggler d-block" data-toggle="sidebar" type="button">
                            <span class="material-icons">menu</span>
                        </button>

                        <!-- Brand -->
                        <a href="fixed-instructor-dashboard.html" class="navbar-brand">
                            <img src="assets/images/logo/white.svg" class="mr-2" alt="LearnPlus" />
                            <span class="d-none d-xs-md-block">LearnPlus</span>
                        </a>

                        <ul class="nav navbar-nav navbar-nav-stats d-none d-md-flex flex-nowrap">
                            <li class="nav-item">
                                <div class="nav-stats">$591 <small>GROSS</small></div>
                            </li>
                            <li class="nav-item">
                                <div class="nav-stats">$31 <small>TAXES</small></div>
                            </li>
                            <li class="nav-item mr-3">
                                <div class="nav-stats">$560 <small>NET</small></div>
                            </li>
                        </ul>

                        <!-- Search -->
                        <form class="search-form d-none d-md-flex">
                            <input type="text" class="form-control" placeholder="Search">
                            <button class="btn" type="button"><i class="material-icons font-size-24pt">search</i></button>
                        </form>
                        <!-- // END Search -->

                        <div class="flex"></div>

                        <!-- Menu -->
                        <ul class="nav navbar-nav flex-nowrap d-none d-lg-flex">
                            <li class="nav-item">
                                <a class="nav-link" href="fixed-instructor-forum.html">Forum</a>
                            </li>
                        </ul>

                        <!-- Menu -->
                        <ul class="nav navbar-nav flex-nowrap">




                            <!-- Notifications dropdown -->
                            <li class="nav-item dropdown dropdown-notifications dropdown-menu-sm-full">
                                <button class="nav-link btn-flush dropdown-toggle" type="button" data-toggle="dropdown" data-dropdown-disable-document-scroll data-caret="false">
                                    <i class="material-icons">notifications</i>
                                    <span class="badge badge-notifications badge-danger">2</span>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <div data-perfect-scrollbar class="position-relative">
                                        <div class="dropdown-header"><strong>Messages</strong></div>
                                        <div class="list-group list-group-flush mb-0">

                                            <a href="fixed-instructor-messages.html" class="list-group-item list-group-item-action unread">
                                                <span class="d-flex align-items-center mb-1">
                                                    <small class="text-muted">5 minutes ago</small>

                                                    <span class="ml-auto unread-indicator bg-primary"></span>

                                                </span>
                                                <span class="d-flex">
                                                    <span class="avatar avatar-xs mr-2">
                                                        <img src="assets/images/people/110/woman-5.jpg" alt="people" class="avatar-img rounded-circle">
                                                    </span>
                                                    <span class="flex d-flex flex-column">
                                                        <strong>Michelle</strong>
                                                        <span class="text-black-70">Clients loved the new design.</span>
                                                    </span>
                                                </span>
                                            </a>

                                            <a href="fixed-instructor-messages.html" class="list-group-item list-group-item-action unread">
                                                <span class="d-flex align-items-center mb-1">
                                                    <small class="text-muted">5 minutes ago</small>

                                                    <span class="ml-auto unread-indicator bg-primary"></span>

                                                </span>
                                                <span class="d-flex">
                                                    <span class="avatar avatar-xs mr-2">
                                                        <img src="assets/images/people/110/woman-5.jpg" alt="people" class="avatar-img rounded-circle">
                                                    </span>
                                                    <span class="flex d-flex flex-column">
                                                        <strong>Michelle</strong>
                                                        <span class="text-black-70">🔥 Superb job..</span>
                                                    </span>
                                                </span>
                                            </a>

                                        </div>

                                        <div class="dropdown-header"><strong>System notifications</strong></div>
                                        <div class="list-group list-group-flush mb-0">

                                            <a href="fixed-instructor-messages.html" class="list-group-item list-group-item-action border-left-3 border-left-danger">
                                                <span class="d-flex align-items-center mb-1">
                                                    <small class="text-muted">3 minutes ago</small>

                                                </span>
                                                <span class="d-flex">
                                                    <span class="avatar avatar-xs mr-2">
                                                        <span class="avatar-title rounded-circle bg-light">
                                                            <i class="material-icons font-size-16pt text-danger">account_circle</i>
                                                        </span>
                                                    </span>
                                                    <span class="flex d-flex flex-column">

                                                        <span class="text-black-70">Your profile information has not been synced correctly.</span>
                                                    </span>
                                                </span>
                                            </a>

                                            <a href="fixed-instructor-messages.html" class="list-group-item list-group-item-action">
                                                <span class="d-flex align-items-center mb-1">
                                                    <small class="text-muted">5 hours ago</small>

                                                </span>
                                                <span class="d-flex">
                                                    <span class="avatar avatar-xs mr-2">
                                                        <span class="avatar-title rounded-circle bg-light">
                                                            <i class="material-icons font-size-16pt text-success">group_add</i>
                                                        </span>
                                                    </span>
                                                    <span class="flex d-flex flex-column">
                                                        <strong>Adrian. D</strong>
                                                        <span class="text-black-70">Wants to join your private group.</span>
                                                    </span>
                                                </span>
                                            </a>

                                            <a href="fixed-instructor-messages.html" class="list-group-item list-group-item-action">
                                                <span class="d-flex align-items-center mb-1">
                                                    <small class="text-muted">1 day ago</small>

                                                </span>
                                                <span class="d-flex">
                                                    <span class="avatar avatar-xs mr-2">
                                                        <span class="avatar-title rounded-circle bg-light">
                                                            <i class="material-icons font-size-16pt text-warning">storage</i>
                                                        </span>
                                                    </span>
                                                    <span class="flex d-flex flex-column">

                                                        <span class="text-black-70">Your deploy was successful.</span>
                                                    </span>
                                                </span>
                                            </a>

                                        </div>
                                    </div>
                                </div>
                            </li>
                            <!-- // END Notifications dropdown -->
                            <!-- User dropdown -->
                            <li class="nav-item dropdown ml-1 ml-md-3">
                                <a class="nav-link active dropdown-toggle" data-toggle="dropdown" href="#" role="button"><img src="assets/images/people/50/guy-6.jpg" alt="Avatar" class="rounded-circle" width="40"></a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="fixed-instructor-account-edit.html">
                                        <i class="material-icons">edit</i> Edit Account
                                    </a>
                                    <a class="dropdown-item" href="fixed-instructor-profile.html">
                                        <i class="material-icons">person</i> Public Profile
                                    </a>
                                    <a class="dropdown-item" href="guest-login.html">
                                        <i class="material-icons">lock</i> Logout
                                    </a>
                                </div>
                            </li>
                            <!-- // END User dropdown -->
                        </ul>
                    </div>
                </nav>
                <!-- // END Navbar -->

            </div>
        </div>

        <!-- // END Header -->

        <!-- Header Layout Content -->
        <div class="mdk-header-layout__content d-flex flex-column">

            <div class="page__header">
                <div class="navbar bg-dark navbar-dark navbar-expand-sm d-none2 d-md-flex2">
                    <div class="container">

                        <div class="navbar-collapse collapse" id="navbarsExample03">
                            <ul class="nav navbar-nav">
                                <li class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Student</a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="fixed-student-dashboard.html">Dashboard</a>
                                        <a class="dropdown-item" href="fixed-student-browse-courses.html">Browse Courses</a>
                                        <a class="dropdown-item" href="fixed-student-view-course.html">View Course</a>
                                        <a class="dropdown-item" href="fixed-student-take-course.html">Take Course</a>
                                        <a class="dropdown-item" href="fixed-student-take-quiz.html">Take a Quiz</a>
                                        <a class="dropdown-item" href="fixed-student-quiz-results.html">Quiz Results</a>
                                        <a class="dropdown-item" href="fixed-student-my-courses.html">My Courses</a>
                                        <a class="dropdown-item" href="fixed-student-billing.html">Billing</a>
                                        <a class="dropdown-item" href="fixed-student-pay.html">Payment</a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown active">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Instructor</a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="fixed-instructor-dashboard.html">Dashboard</a>
                                        <a class="dropdown-item active" href="fixed-instructor-courses.html">Course Manager</a>
                                        <a class="dropdown-item" href="fixed-instructor-quizzes.html">Quiz Manager</a>
                                        <a class="dropdown-item" href="fixed-instructor-profile.html">Public Profile</a>
                                        <a class="dropdown-item" href="fixed-instructor-earnings.html">Earnings</a>
                                        <a class="dropdown-item" href="fixed-instructor-statement.html">Statement</a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Account</a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="fixed-instructor-account-edit.html">Edit Account</a>
                                        <a class="dropdown-item" href="fixed-instructor-messages.html">Messages</a>
                                        <a class="dropdown-item" href="fixed-instructor-invoice.html">Invoice</a>
                                        <a class="dropdown-item" href="guest-login.html">Logout</a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Components</a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="fixed-ui-avatars.html">Avatars</a>
                                        <a class="dropdown-item" href="fixed-ui-forms.html">Forms</a>
                                        <a class="dropdown-item" href="fixed-ui-loaders.html">Loaders</a>
                                        <a class="dropdown-item" href="fixed-ui-tables.html">Tables</a>
                                        <a class="dropdown-item" href="fixed-ui-cards.html">Cards</a>
                                        <a class="dropdown-item" href="fixed-ui-tabs.html">Tabs</a>
                                        <a class="dropdown-item" href="fixed-ui-icons.html">Icons</a>
                                        <a class="dropdown-item" href="fixed-ui-buttons.html">Buttons</a>
                                        <a class="dropdown-item" href="fixed-ui-alerts.html">Alerts</a>
                                        <a class="dropdown-item" href="fixed-ui-badges.html">Badges</a>
                                        <!-- <a class="dropdown-item" href="fixed-ui-modals.html">- Modals</a> -->
                                        <a class="dropdown-item" href="fixed-ui-progress.html">Progress</a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Plugins</a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="fixed-ui-charts.html">Charts</a>
                                        <a class="dropdown-item" href="fixed-ui-drag.html">Drag &amp; Drop</a>
                                        <a class="dropdown-item" href="fixed-ui-calendar.html">Calendar</a>
                                        <a class="dropdown-item" href="fixed-ui-nestable.html">Nestable</a>
                                        <a class="dropdown-item" href="fixed-ui-tree.html">Tree</a>
                                        <a class="dropdown-item" href="fixed-ui-maps-vector.html">Vector Maps</a>
                                        <a class="dropdown-item" href="fixed-ui-sweet-alert.html">Sweet Alert</a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Layouts</a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="instructor-courses.html">Fluid</a>
                                        <a class="dropdown-item active" href="fixed-instructor-courses.html">Fixed</a>
                                    </div>
                                </li>
                            </ul>
                        </div>

                        <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarsExample03" type="button">
                            <span class="material-icons">menu</span>
                        </button>

                    </div>
                </div>
            </div>

            <div class="page">

                <div class="container page__container">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="fixed-instructor-dashboard.html">Home</a></li>
                        <li class="breadcrumb-item active">Courses</li>
                    </ol>

                    <div class="d-flex flex-column flex-sm-row flex-wrap mb-headings align-items-start align-items-sm-center">
                        <div class="flex mb-2 mb-sm-0">
                            <h1 class="h2">Manage Courses</h1>
                        </div>
                        <a href="fixed-instructor-quiz-edit.html" class="btn btn-success">Add course</a>
                    </div>

                    <div class="card card-body border-left-3 border-left-primary navbar-shadow mb-4">
                        <form action="#">
                            <div class="d-flex flex-wrap2 align-items-center mb-headings">
                                <div class="dropdown">
                                    <a href="#" data-toggle="dropdown" class="btn btn-white"><i class="material-icons mr-sm-2">tune</i> <span class="d-none d-sm-block">Filters</span></a>
                                    <div class="dropdown-menu">
                                        <div class="dropdown-item d-flex flex-column">
                                            <div class="form-group">
                                                <label for="custom-select" class="form-label">Category</label><br>
                                                <select id="custom-select" class="form-control custom-select" style="width: 200px;">
                                                    <option selected>All categories</option>
                                                    <option value="1">Vue.js</option>
                                                    <option value="2">Node.js</option>
                                                    <option value="3">GitHub</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="published01" class="form-label">Published</label><br>
                                                <select id="published01" class="form-control custom-select" style="width: 200px;">
                                                    <option selected>Published courses</option>
                                                    <option value="1">Draft courses</option>
                                                    <option value="3">All courses</option>
                                                </select>
                                            </div>
                                            <a href="#">Clear filters</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="flex search-form ml-3 search-form--light">
                                    <input type="text" class="form-control" placeholder="Search courses" id="searchSample02">
                                    <button class="btn" type="button" role="button"><i class="material-icons">search</i></button>
                                </div>
                            </div>

                            <div class="d-flex flex-column flex-sm-row align-items-sm-center" style="white-space: nowrap;">
                                <small class="flex text-muted text-uppercase mr-3 mb-2 mb-sm-0">Displaying 4 out of 10 courses</small>
                                <div class="w-auto ml-sm-auto table d-flex align-items-center mb-0">
                                    <small class="text-muted text-uppercase mr-3 d-none d-sm-block">Sort by</small>
                                    <a href="#" class="sort desc small text-uppercase">Course</a>
                                    <a href="#" class="sort small text-uppercase ml-2">Earnings</a>
                                    <a href="#" class="sort small text-uppercase ml-2">Sales</a>
                                </div>
                            </div>
                        </form>
                    </div>



                    <div class="alert alert-light alert-dismissible border-1 border-left-3 border-left-warning" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <div class="text-black-70">Ohh no! No courses to display. Add some courses.</div>
                    </div>

                    <div class="row">

                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-body">

                                    <div class="d-flex flex-column flex-sm-row">
                                        <a href="fixed-instructor-course-edit.html" class="avatar avatar-lg avatar-4by3 mb-3 w-xs-plus-down-100 mr-sm-3">
                                            <img src="assets/images/vuejs.png" alt="Card image cap" class="avatar-img rounded">
                                        </a>
                                        <div class="flex" style="min-width: 200px;">
                                            <!-- <h5 class="card-title text-base m-0"><a href="fixed-instructor-course-edit.html"><strong>Learn Vue.js</strong></a></h5> -->
                                            <h4 class="card-title mb-1"><a href="fixed-instructor-course-edit.html">Learn Vue.js</a></h4>
                                            <p class="text-black-70">Let’s start with a quick tour of Vue’s data binding features.</p>
                                            <div class="d-flex align-items-end">
                                                <div class="d-flex flex flex-column mr-3">
                                                    <div class="d-flex align-items-center py-1 border-bottom">
                                                        <small class="text-black-70 mr-2">&dollar;1,230/mo</small>
                                                        <small class="text-black-50">34 SALES</small>
                                                    </div>
                                                    <div class="d-flex align-items-center py-1">
                                                        <small class="text-muted mr-2">GULP</small>
                                                        <small class="text-muted">INTERMEDIATE</small>
                                                    </div>
                                                </div>
                                                <div class="text-center">
                                                    <a href="fixed-instructor-course-edit.html" class="btn btn-sm btn-white">Edit</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="card__options dropdown right-0 pr-2">
                                    <a href="#" class="dropdown-toggle text-muted" data-caret="false" data-toggle="dropdown">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a class="dropdown-item" href="fixed-instructor-course-edit.html">Edit course</a>
                                        <a class="dropdown-item" href="#">Course Insights</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item text-danger" href="#">Delete course</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-body">

                                    <div class="d-flex flex-column flex-sm-row">
                                        <a href="fixed-instructor-course-edit.html" class="avatar avatar-lg avatar-4by3 mb-3 w-xs-plus-down-100 mr-sm-3">
                                            <img src="assets/images/nodejs.png" alt="Card image cap" class="avatar-img rounded">
                                        </a>
                                        <div class="flex" style="min-width: 200px;">
                                            <!-- <h5 class="card-title text-base m-0"><a href="fixed-instructor-course-edit.html"><strong>Npm &amp; Gulp Advanced Workflow</strong></a></h5> -->
                                            <h4 class="card-title mb-1"><a href="fixed-instructor-course-edit.html">Npm &amp; Gulp Advanced Workflow</a></h4>
                                            <p class="text-black-70">Learn the basics of Github and become a power Github developer.</p>
                                            <div class="d-flex align-items-end">
                                                <div class="d-flex flex flex-column mr-3">
                                                    <div class="d-flex align-items-center py-1 border-bottom">
                                                        <small class="text-black-70 mr-2">&dollar;421/mo</small>
                                                        <small class="text-black-50">12 SALES</small>
                                                    </div>
                                                    <div class="d-flex align-items-center py-1">
                                                        <small class="text-muted mr-2">GULP</small>
                                                        <small class="text-muted">INTERMEDIATE</small>
                                                    </div>
                                                </div>
                                                <div class="text-center">
                                                    <a href="fixed-instructor-course-edit.html" class="btn btn-sm btn-white">Edit</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="card__options dropdown right-0 pr-2">
                                    <a href="#" class="dropdown-toggle text-muted" data-caret="false" data-toggle="dropdown">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a class="dropdown-item" href="fixed-instructor-course-edit.html">Edit course</a>
                                        <a class="dropdown-item" href="#">Course Insights</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item text-danger" href="#">Delete course</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-body">

                                    <div class="d-flex flex-column flex-sm-row">
                                        <a href="fixed-instructor-course-edit.html" class="avatar avatar-lg avatar-4by3 mb-3 w-xs-plus-down-100 mr-sm-3">
                                            <img src="assets/images/github.png" alt="Card image cap" class="avatar-img rounded">
                                        </a>
                                        <div class="flex" style="min-width: 200px;">
                                            <!-- <h5 class="card-title text-base m-0"><a href="fixed-instructor-course-edit.html"><strong>Github Webhooks for Beginners</strong></a></h5> -->
                                            <h4 class="card-title mb-1"><a href="fixed-instructor-course-edit.html">Github Webhooks for Beginners</a></h4>
                                            <p class="text-black-70">Developing static website with fast and advanced gulp setup.</p>
                                            <div class="d-flex align-items-end">
                                                <div class="d-flex flex flex-column mr-3">
                                                    <div class="d-flex align-items-center py-1 border-bottom">
                                                        <small class="text-black-70 mr-2">&dollar;2,191/mo</small>
                                                        <small class="text-black-50">50 SALES</small>
                                                    </div>
                                                    <div class="d-flex align-items-center py-1">
                                                        <small class="text-muted mr-2">GULP</small>
                                                        <small class="text-muted">INTERMEDIATE</small>
                                                    </div>
                                                </div>
                                                <div class="text-center">
                                                    <a href="fixed-instructor-course-edit.html" class="btn btn-sm btn-white">Edit</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="card__options dropdown right-0 pr-2">
                                    <a href="#" class="dropdown-toggle text-muted" data-caret="false" data-toggle="dropdown">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a class="dropdown-item" href="fixed-instructor-course-edit.html">Edit course</a>
                                        <a class="dropdown-item" href="#">Course Insights</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item text-danger" href="#">Delete course</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-body">

                                    <div class="d-flex flex-column flex-sm-row">
                                        <a href="fixed-instructor-course-edit.html" class="avatar avatar-lg avatar-4by3 mb-3 w-xs-plus-down-100 mr-sm-3">
                                            <img src="assets/images/gulp.png" alt="Card image cap" class="avatar-img rounded">
                                        </a>
                                        <div class="flex" style="min-width: 200px;">
                                            <!-- <h5 class="card-title text-base m-0"><a href="fixed-instructor-course-edit.html"><strong>Gulp &amp; Slush Workflows</strong></a></h5> -->
                                            <h4 class="card-title mb-1"><a href="fixed-instructor-course-edit.html">Gulp &amp; Slush Workflows</a></h4>
                                            <p class="text-black-70">Let’s start with a quick tour of Vue’s data binding features.</p>
                                            <div class="d-flex align-items-end">
                                                <div class="d-flex flex flex-column mr-3">
                                                    <div class="d-flex align-items-center py-1 border-bottom">
                                                        <small class="text-black-70 mr-2">&dollar;300/mo</small>
                                                        <small class="text-black-50">5 SALES</small>
                                                    </div>
                                                    <div class="d-flex align-items-center py-1">
                                                        <small class="text-muted mr-2">GULP</small>
                                                        <small class="text-muted">INTERMEDIATE</small>
                                                    </div>
                                                </div>
                                                <div class="text-center">
                                                    <a href="fixed-instructor-course-edit.html" class="btn btn-sm btn-white">Edit</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="card__options dropdown right-0 pr-2">
                                    <a href="#" class="dropdown-toggle text-muted" data-caret="false" data-toggle="dropdown">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <a class="dropdown-item" href="fixed-instructor-course-edit.html">Edit course</a>
                                        <a class="dropdown-item" href="#">Course Insights</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item text-danger" href="#">Delete course</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- Pagination -->
                    <ul class="pagination justify-content-center pagination-sm">
                        <li class="page-item disabled">
                            <a class="page-link" href="#" aria-label="Previous">
                                <span aria-hidden="true" class="material-icons">chevron_left</span>
                                <span>Prev</span>
                            </a>
                        </li>
                        <li class="page-item active">
                            <a class="page-link" href="#" aria-label="1">
                                <span>1</span>
                            </a>
                        </li>
                        <li class="page-item">
                            <a class="page-link" href="#" aria-label="1">
                                <span>2</span>
                            </a>
                        </li>
                        <li class="page-item">
                            <a class="page-link" href="#" aria-label="Next">
                                <span>Next</span>
                                <span aria-hidden="true" class="material-icons">chevron_right</span>
                            </a>
                        </li>
                    </ul>
                </div>

                <div class="container page__container">
                    <div class="footer">
                        Copyright &copy; 2016 - <a href="http://themeforest.net/item/learnplus-learning-management-application/15287372?ref=mosaicpro">Purchase LearnPlus</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- // END Header Layout Content -->

    </div>
    <!-- // END Header Layout -->

 <?php include ('sidebar.php');?>


    <!-- App Settings FAB -->
    <div id="app-settings">
        <app layout-active="fixed" :layout-location="{
      'fixed': 'fixed-instructor-courses.html',
      'default': 'instructor-courses.html'
    }" sidebar-variant="bg-transparent border-0"></app>
    </div>
    <!-- jQuery -->
    <script src="assets/vendor/jquery.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/vendor/popper.min.js"></script>
    <script src="assets/vendor/bootstrap.min.js"></script>

    <!-- Perfect Scrollbar -->
    <script src="assets/vendor/perfect-scrollbar.min.js"></script>

    <!-- MDK -->
    <script src="assets/vendor/dom-factory.js"></script>
    <script src="assets/vendor/material-design-kit.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Highlight.js -->
    <script src="assets/js/hljs.js"></script>

    <!-- App Settings (safe to remove) -->
    <script src="assets/js/app-settings.js"></script>








</body>


<!-- Mirrored from learnplus-bootstrap.frontendmatter.com/fixed-instructor-courses.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 07 Dec 2018 07:15:11 GMT -->
</html>