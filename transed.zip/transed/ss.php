<html>
<body>
<script>
 
window.open ('../Admin/AdminChat/AdminInfo.aspx?id='+id+ ,,'width=630,height=400,left=395,dialog=no,maximize=no,alwaystop=yes,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no');

</script>
</body>
</html>
