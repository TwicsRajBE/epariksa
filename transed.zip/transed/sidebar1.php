


                <div class="mdk-drawer js-mdk-drawer" id="default-drawer">
                    <div class="mdk-drawer__content ">
                        <div class="sidebar sidebar-left sidebar-dark bg-dark o-hidden" data-perfect-scrollbar>
                            <div class="sidebar-p-y">
                                <div class="sidebar-heading">NAVIGATION</div>
                               
                            
                                <ul class="sidebar-menu sm-active-button-bg">
                                   
                                 <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" data-toggle="collapse" href="#question_menu">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">import_contacts</i> Questions
                                            <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                        </a>
                                        <ul class="sidebar-submenu sm-indent collapse" id="question_menu">
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="">
                                                    <span class="sidebar-menu-text">Category</span>
                                                    
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="">
                                                    <span class="sidebar-menu-text">Subject</span>
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="">
                                                    <span class="sidebar-menu-text">Topics</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>

                                     <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" data-toggle="collapse" href="#student_menu">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">account_box</i> Student
                                            <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                        </a>
                                        <ul class="sidebar-submenu sm-indent collapse" id="student_menu">
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="add-student.php">
                                                    <span class="sidebar-menu-text">Add Student</span>
                                                   
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="student-view.php">
                                                    <span class="sidebar-menu-text">View Student</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>

                                      <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" data-toggle="collapse" href="#Tutors_menu">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">account_box</i> Tutors
                                            <span class="ml-auto sidebar-menu-toggle-icon"></span>
                                        </a>
                                        <ul class="sidebar-submenu sm-indent collapse" id="Tutors_menu">
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="add-tutor.php">
                                                    <span class="sidebar-menu-text">Add Tutors</span>
                                                   
                                                </a>
                                            </li>
                                            <li class="sidebar-menu-item">
                                                <a class="sidebar-menu-button" href="tutor-view.php">
                                                    <span class="sidebar-menu-text">View Tutors</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="add-random-test.php">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">dvr</i> Add Random test
                                        </a>
                                    </li>
                                     <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="add-manual-test.php">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">dvr</i> Add Manual test
                                        </a>
                                    </li>
                                    <li class="sidebar-menu-item">
                                        <a class="sidebar-menu-button" href="">
                                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">tune</i> Report
                                        </a>
                                    </li>
                                  


                                    
                                </ul>
                                
                            </div>
                        </div>
                    </div>
                </div>