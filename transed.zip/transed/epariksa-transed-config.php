<?php
session_start();
ini_set('display_errors','On');
 ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_WARNING & ~E_STRICT & ~E_DEPRECATED);
date_default_timezone_set('Asia/Kolkata');
mysqli_set_charset($mysqli,'utf8');
mysqli_character_set_name($mysqli,'utf8_general_ci');

		if(!isset($_SESSION['role_id']))
			{
			echo "<script> alert('No Direct Access, Please login');
			document.location.href='login.php';
			</script>";
			}

			$mysqli = new mysqli('localhost', 'root', '', 'epariksa_transed');
			if ($mysqli->connect_error) {
			 die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
			}
			mysqli_query($mysqli, "SET SESSION sql_mode = ''");
			


			 $session_role_id             = $_SESSION['role_id'];
			 $session_login_id           = $_SESSION['login_id'];

			define( 'PRODUCT_NAME', 'TransEd');
			define('PRODUCT_FAVICON','images/favicon.png');
			define('PRODUCT_BG_IMAGE','');
			define('FOOTER','<p class ="copyright pull-right"> &copy; 2018 <a href="http://www.testwareinformatics.com/testware/">Testware Informatics.com</a> </p>');
			define('SUBJECTS','Subjects');
			define('TOPICS','Topics');
			define('CATEGORY','Category');
			define('QUESTION','Question');


			function getdate_formated($date){
				$date=date_create($date);
				$date_formate = date_format($date,"M d ,Y");
			
			return $date_formate;
			}
		function get_description($description){
				$news = strip_tags($description);
				$snews = substr($news,0,10);
				$description =  substr($news, 0, 35) .((strlen($news) > 25) ? '...' : '');
				return $description;
			}







?>